-- Melodiespark Command Center reference schema for PostgreSQL 16+.
-- This schema stores secret references, never raw API keys or private keys.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS schema_metadata (
  key text PRIMARY KEY,
  value text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'analyst', 'operator', 'viewer')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'locked', 'disabled')),
  mfa_enabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_login_at timestamptz
);

CREATE TABLE IF NOT EXISTS sessions (
  id_hash text PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf_hash text NOT NULL,
  ip_hash text,
  user_agent_hash text,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions (expires_at);

CREATE TABLE IF NOT EXISTS secret_references (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL,
  environment text NOT NULL,
  secret_manager_path text NOT NULL,
  key_version text,
  created_at timestamptz NOT NULL DEFAULT now(),
  rotated_at timestamptz,
  UNIQUE(provider, environment, secret_manager_path)
);

CREATE TABLE IF NOT EXISTS revenue_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source text NOT NULL,
  external_id text NOT NULL,
  amount_minor bigint NOT NULL CHECK (amount_minor >= 0),
  currency char(3) NOT NULL,
  gross_minor bigint NOT NULL CHECK (gross_minor >= 0),
  discount_minor bigint NOT NULL DEFAULT 0 CHECK (discount_minor >= 0),
  tax_minor bigint NOT NULL DEFAULT 0 CHECK (tax_minor >= 0),
  status text NOT NULL,
  occurred_at timestamptz NOT NULL,
  is_demo boolean NOT NULL DEFAULT false,
  raw_json jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(source, external_id)
);
CREATE INDEX IF NOT EXISTS revenue_occurred_idx ON revenue_events (occurred_at DESC);
CREATE INDEX IF NOT EXISTS revenue_currency_status_idx ON revenue_events (currency, status, occurred_at DESC);

CREATE TABLE IF NOT EXISTS integration_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL,
  operation text NOT NULL,
  status text NOT NULL,
  records_processed integer NOT NULL DEFAULT 0,
  error_code text,
  details_json jsonb,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);
CREATE INDEX IF NOT EXISTS integration_provider_idx ON integration_runs (provider, started_at DESC);

CREATE TABLE IF NOT EXISTS guardians (
  id text PRIMARY KEY,
  name text NOT NULL UNIQUE,
  tier text NOT NULL CHECK (tier IN ('arc_angel', 'guardian', 'sub_guardian')),
  domain text NOT NULL,
  soul_core text NOT NULL,
  role text NOT NULL,
  enabled boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'configured',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS guardian_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cycle_id text NOT NULL,
  guardian_id text NOT NULL REFERENCES guardians(id),
  status text NOT NULL,
  latency_ms integer,
  details_json jsonb,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);
CREATE INDEX IF NOT EXISTS guardian_runs_cycle_idx ON guardian_runs (cycle_id);
CREATE INDEX IF NOT EXISTS guardian_runs_guardian_idx ON guardian_runs (guardian_id, started_at DESC);

CREATE TABLE IF NOT EXISTS workflow_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cycle_id text NOT NULL,
  status text NOT NULL,
  tasks_total integer NOT NULL,
  tasks_succeeded integer NOT NULL,
  tasks_failed integer NOT NULL,
  details_json jsonb,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);
CREATE INDEX IF NOT EXISTS workflow_runs_started_idx ON workflow_runs (started_at DESC);

CREATE TABLE IF NOT EXISTS wallet_challenges (
  id uuid PRIMARY KEY,
  address text NOT NULL,
  chain_id integer NOT NULL,
  nonce text NOT NULL,
  message text NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS wallet_challenges_address_idx ON wallet_challenges (address, created_at DESC);

CREATE TABLE IF NOT EXISTS wallet_bindings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  address text NOT NULL,
  chain_id integer NOT NULL,
  verified_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, address, chain_id)
);

CREATE TABLE IF NOT EXISTS withdrawal_intents (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id),
  wallet_binding_id uuid NOT NULL REFERENCES wallet_bindings(id),
  chain_id integer NOT NULL,
  asset text NOT NULL,
  amount_atomic numeric(78,0) NOT NULL CHECK (amount_atomic > 0),
  amount_display text NOT NULL,
  destination text NOT NULL,
  message text NOT NULL,
  nonce text NOT NULL,
  expires_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'awaiting_signature',
  signature text,
  provider text NOT NULL DEFAULT 'manual_review',
  created_at timestamptz NOT NULL DEFAULT now(),
  signed_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS withdrawal_status_idx ON withdrawal_intents (status, created_at DESC);

CREATE TABLE IF NOT EXISTS karma_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  event_key text NOT NULL,
  points integer NOT NULL,
  reason text NOT NULL,
  transferable boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, event_key)
);

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sku text NOT NULL UNIQUE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  product_type text NOT NULL,
  price_minor bigint NOT NULL CHECK (price_minor >= 0),
  currency char(3) NOT NULL DEFAULT 'CAD',
  status text NOT NULL DEFAULT 'draft',
  source text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id text,
  actor_user_id uuid REFERENCES users(id),
  actor_type text NOT NULL,
  action text NOT NULL,
  resource_type text,
  resource_id text,
  outcome text NOT NULL,
  ip_hash text,
  details_json jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_created_idx ON audit_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS audit_action_idx ON audit_logs (action, created_at DESC);

-- Recommended production controls:
-- 1. Put the API behind an identity-aware proxy and enforce MFA upstream.
-- 2. Use a separate append-only audit sink or WORM archive.
-- 3. Use row-level security or separate database roles for workers and analysts.
-- 4. Encrypt backups and test restoration.
-- 5. Store only secret-manager references in secret_references.
