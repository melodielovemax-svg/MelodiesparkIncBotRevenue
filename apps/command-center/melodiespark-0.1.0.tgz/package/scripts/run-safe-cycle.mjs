import { loadConfig } from '../src/config.mjs';
import { Repository } from '../src/db.mjs';
import { IntegrationManager } from '../src/integrations.mjs';
import { SafeWorkflowEngine } from '../src/workflows.mjs';

const cyclesArg = Number.parseInt(process.argv[2] || '1', 10);
const continuous = process.argv.includes('--continuous');
const intervalArg = Number.parseInt(process.argv.find((value) => value.startsWith('--interval='))?.split('=')[1] || '300', 10);
const cycles = Number.isFinite(cyclesArg) ? Math.max(1, Math.min(10_000, cyclesArg)) : 1;
const interval = Math.max(30, Math.min(86_400, Number.isFinite(intervalArg) ? intervalArg : 300));
const config = loadConfig();
const db = new Repository({ databasePath: config.databasePath, schemaPath: config.schemaPath, config });
const integrations = new IntegrationManager({ db, config });
const workflows = new SafeWorkflowEngine({ db, config, integrations, root: config.root });

let stopping = false;
process.on('SIGINT', () => { stopping = true; });
try {
  let index = 0;
  do {
    const result = await workflows.runCycle({ trigger: 'powershell_safe_cycle' });
    console.log(JSON.stringify(result));
    index += 1;
    if ((continuous || index < cycles) && !stopping) await new Promise((resolve) => setTimeout(resolve, interval * 1000));
  } while (!stopping && (continuous || index < cycles));
} finally {
  db.close();
}
