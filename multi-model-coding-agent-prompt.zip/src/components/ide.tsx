"use client";

import { useState, useEffect, useRef, useCallback } from "react";

// ─── Types ────────────────────────────────────────────────

interface FileEntry {
  name: string;
  path: string;
  type: "file" | "directory";
}

interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
}

interface AgentStatus {
  agent: string;
  model: string;
  provider: string;
  task: string;
  currentFile: string;
  currentTool: string;
  tokens: number;
  cost: number;
  elapsed: number;
  status: string;
}

// ─── Icons ────────────────────────────────────────────────

function FolderIcon() {
  return <span className="text-amber-400 mr-1.5">📁</span>;
}
function FileIcon() {
  return <span className="text-blue-400 mr-1.5">📄</span>;
}
function SendIcon() {
  return <span>➤</span>;
}
function PlayIcon() {
  return <span>▶</span>;
}

// ─── File Explorer ────────────────────────────────────────

function FileExplorer({
  onFileSelect,
  selectedPath,
}: {
  onFileSelect: (path: string) => void;
  selectedPath: string | null;
}) {
  const [entries, setEntries] = useState<FileEntry[]>([]);
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(new Set([""]));
  const [loading, setLoading] = useState(false);

  const loadDir = useCallback(async (dirPath: string) => {
    setLoading(true);
    try {
      const res = await fetch("/api/ide", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "files.list", path: dirPath }),
      });
      const data = await res.json() as { entries?: FileEntry[] };
      if (data.entries) setEntries(data.entries);
    } catch (err) {
      console.error("Failed to load directory:", err);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadDir("");
  }, [loadDir]);

  const toggleDir = async (path: string) => {
    const next = new Set(expandedDirs);
    if (next.has(path)) next.delete(path);
    else next.add(path);
    setExpandedDirs(next);
    if (!expandedDirs.has(path)) await loadDir(path);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="px-3 py-2 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-700">
        Explorer
      </div>
      <div className="flex-1 overflow-y-auto p-1 text-sm">
        {loading && entries.length === 0 && (
          <div className="px-2 py-1 text-slate-500 text-xs">Loading...</div>
        )}
        {entries.map((entry) => (
          <button
            key={entry.path}
            onClick={() => entry.type === "directory" ? toggleDir(entry.path) : onFileSelect(entry.path)}
            className={`w-full text-left px-2 py-1 rounded flex items-center hover:bg-slate-700/50 transition-colors ${
              selectedPath === entry.path ? "bg-slate-700 text-white" : "text-slate-300"
            }`}
          >
            {entry.type === "directory" ? <FolderIcon /> : <FileIcon />}
            <span className="truncate">{entry.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Code Editor ──────────────────────────────────────────

function CodeEditor({
  filePath,
  onSave,
}: {
  filePath: string | null;
  onSave: (path: string, content: string) => Promise<void>;
}) {
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const lineCount = content.split("\n").length;

  useEffect(() => {
    if (!filePath) return;
    setLoading(true);
    fetch("/api/ide", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "files.read", path: filePath }),
    })
      .then((r) => r.json())
      .then((data: { content?: string }) => {
        if (data.content) { setContent(data.content); setDirty(false); }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [filePath]);

  const handleSave = async () => {
    if (!filePath || !dirty) return;
    setSaveStatus("Saving...");
    await onSave(filePath, content);
    setDirty(false);
    setSaveStatus("Saved!");
    setTimeout(() => setSaveStatus(null), 2000);
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "s") {
        e.preventDefault();
        handleSave();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  });

  if (!filePath) {
    return (
      <div className="h-full flex items-center justify-center text-slate-500">
        <div className="text-center">
          <div className="text-4xl mb-3">⚡</div>
          <p className="text-sm">Select a file to edit</p>
          <p className="text-xs mt-1 text-slate-600">Or start an agent task</p>
        </div>
      </div>
    );
  }

  if (loading) return <div className="h-full flex items-center justify-center text-slate-500 text-sm">Loading...</div>;

  return (
    <div className="h-full flex flex-col">
      <div className="px-3 py-1.5 text-xs text-slate-400 border-b border-slate-700 flex items-center justify-between">
        <span className="font-mono">{filePath} {dirty && <span className="text-amber-400">●</span>}</span>
        <span>{saveStatus}</span>
      </div>
      <div className="flex-1 overflow-hidden flex">
        <div className="py-2 px-2 text-right text-xs text-slate-600 select-none border-r border-slate-800 overflow-y-auto leading-[1.6rem] font-mono">
          {Array.from({ length: lineCount }, (_, i) => (
            <div key={i}>{i + 1}</div>
          ))}
        </div>
        <textarea
          value={content}
          onChange={(e) => { setContent(e.target.value); setDirty(true); }}
          className="flex-1 bg-transparent text-slate-200 p-2 font-mono text-sm leading-[1.6rem] resize-none outline-none overflow-y-auto"
          spellCheck={false}
        />
      </div>
    </div>
  );
}

// ─── Agent Chat Panel ─────────────────────────────────────

function AgentChat({
  onRunTask,
  agentStatus,
}: {
  onRunTask: (task: string, model: string, type: "chat" | "code") => void;
  agentStatus: AgentStatus | null;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [model, setModel] = useState("gpt-4-turbo");
  const [mode, setMode] = useState<"chat" | "code">("code");
  const [streaming, setStreaming] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleSend = async () => {
    if (!input.trim() || streaming) return;
    const userMsg: ChatMessage = { role: "user", content: input, timestamp: new Date() };
    setMessages((prev) => [...prev, userMsg]);
    const taskText = input;
    onRunTask(taskText, model, mode);
    setInput("");
    setStreaming(true);

    // Use fetch with streaming for POST-based SSE
    try {
      const response = await fetch("/api/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task: taskText, model, type: mode }),
      });

      if (!response.ok || !response.body) {
        setStreaming(false);
        return;
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;

          if (trimmed.startsWith("event: ")) {
            const eventType = trimmed.slice(7);
            continue;
          }

          if (trimmed.startsWith("data: ")) {
            const payload = trimmed.slice(6);
            try {
              const data = JSON.parse(payload) as { content?: string; message?: string };
              if (data.content) {
                setMessages((prev) => {
                  const token = data.content ?? "";
                  const last = prev[prev.length - 1];
                  if (last?.role === "assistant") {
                    return [...prev.slice(0, -1), { ...last, content: last.content + token }];
                  }
                  return [...prev, { role: "assistant", content: token, timestamp: new Date() }];
                });
              }
            } catch { /* skip malformed data */ }
          }
        }
      }
    } catch (err) {
      console.error("Stream error:", err);
    }
    setStreaming(false);
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="h-full flex flex-col">
      <div className="px-3 py-2 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-700 flex items-center justify-between">
        <span>Agent Chat</span>
        <div className="flex gap-2 items-center">
          <select
            value={mode}
            onChange={(e) => setMode(e.target.value as "chat" | "code")}
            className="bg-slate-700 text-slate-300 text-xs rounded px-1.5 py-0.5 border border-slate-600"
          >
            <option value="chat">Chat</option>
            <option value="code">Code</option>
          </select>
          <select
            value={model}
            onChange={(e) => setModel(e.target.value)}
            className="bg-slate-700 text-slate-300 text-xs rounded px-1.5 py-0.5 border border-slate-600"
          >
            <option value="gpt-4-turbo">GPT-4 Turbo</option>
            <option value="gpt-3.5-turbo">GPT-3.5</option>
            <option value="mistral-large-latest">Mistral Large</option>
            <option value="openrouter/auto">OpenRouter Auto</option>
          </select>
        </div>
      </div>

      {agentStatus && (
        <div className="px-3 py-1.5 text-xs border-b border-slate-700 bg-slate-800/50 flex flex-wrap gap-x-3 gap-y-1">
          <span className="text-emerald-400">● {agentStatus.status}</span>
          <span className="text-slate-400">Model: {agentStatus.model}</span>
          {agentStatus.currentTool && <span className="text-amber-400">Tool: {agentStatus.currentTool}</span>}
          {agentStatus.currentFile && <span className="text-blue-400">File: {agentStatus.currentFile}</span>}
          {agentStatus.tokens > 0 && <span className="text-slate-400">Tokens: {agentStatus.tokens}</span>}
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {messages.length === 0 && (
          <div className="text-slate-500 text-sm text-center py-8">
            <div className="text-2xl mb-2">🤖</div>
            <p>Start a conversation or give a coding task</p>
            <p className="text-xs mt-1 text-slate-600">Try: &ldquo;Fix the failing tests&rdquo; or &ldquo;Add error handling&rdquo;</p>
          </div>
        )}
        {messages.map((msg, i) => (
          <div key={i} className={`${msg.role === "user" ? "text-right" : "text-left"}`}>
            <div
              className={`inline-block max-w-[85%] rounded-lg px-3 py-2 text-sm ${
                msg.role === "user"
                  ? "bg-blue-600 text-white"
                  : "bg-slate-700 text-slate-200"
              }`}
            >
              <pre className="whitespace-pre-wrap font-mono text-xs">{msg.content}</pre>
            </div>
          </div>
        ))}
        {streaming && (
          <div className="text-left">
            <div className="inline-block bg-slate-700 text-slate-400 rounded-lg px-3 py-2 text-sm">
              <span className="animate-pulse">Thinking...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-2 border-t border-slate-700">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
            placeholder={mode === "code" ? "Describe a coding task..." : "Send a message..."}
            className="flex-1 bg-slate-700 text-slate-200 rounded-lg px-3 py-2 text-sm border border-slate-600 outline-none focus:border-blue-500 placeholder:text-slate-500"
          />
          <button
            onClick={handleSend}
            disabled={streaming || !input.trim()}
            className="bg-blue-600 text-white rounded-lg px-3 py-2 text-sm hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <SendIcon />
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Terminal Panel ───────────────────────────────────────

function TerminalPanel() {
  const [history, setHistory] = useState<Array<{ command: string; output: string; exitCode: number }>>([]);
  const [input, setInput] = useState("");
  const [running, setRunning] = useState(false);

  const execute = async () => {
    if (!input.trim() || running) return;
    const command = input;
    setInput("");
    setRunning(true);

    try {
      const res = await fetch("/api/ide", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "terminal.execute", command }),
      });
      const data = await res.json() as { stdout?: string; stderr?: string; exitCode?: number };
      setHistory((prev) => [...prev, {
        command,
        output: (data.stdout || "") + (data.stderr ? `\n--- stderr ---\n${data.stderr}` : ""),
        exitCode: data.exitCode ?? 1,
      }]);
    } catch (err) {
      setHistory((prev) => [...prev, { command, output: String(err), exitCode: 1 }]);
    }
    setRunning(false);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="px-3 py-1.5 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-700">
        Terminal
      </div>
      <div className="flex-1 overflow-y-auto p-2 font-mono text-xs space-y-2">
        {history.map((entry, i) => (
          <div key={i}>
            <div className="text-emerald-400">${entry.command}</div>
            <pre className={`whitespace-pre-wrap ${entry.exitCode === 0 ? "text-slate-300" : "text-red-400"}`}>
              {entry.output}
            </pre>
          </div>
        ))}
        {running && <div className="text-amber-400 animate-pulse">Running...</div>}
      </div>
      <div className="p-2 border-t border-slate-700 flex gap-2 items-center">
        <span className="text-emerald-400 text-sm">$</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && execute()}
          placeholder="Enter command..."
          className="flex-1 bg-slate-700 text-slate-200 rounded px-2 py-1 text-xs font-mono border border-slate-600 outline-none focus:border-blue-500 placeholder:text-slate-500"
        />
        <button
          onClick={execute}
          disabled={running || !input.trim()}
          className="text-emerald-400 disabled:opacity-50"
        >
          <PlayIcon />
        </button>
      </div>
    </div>
  );
}

// ─── Git Panel ────────────────────────────────────────────

function GitPanel() {
  const [status, setStatus] = useState<string>("");
  const [branch, setBranch] = useState<string>("");
  const [diff, setDiff] = useState<string>("");
  const [log, setLog] = useState<string>("");
  const [loading, setLoading] = useState(false);

  const refresh = async () => {
    setLoading(true);
    try {
      const [statusRes, logRes] = await Promise.all([
        fetch("/api/ide", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "git.status" }) }),
        fetch("/api/ide", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "git.log" }) }),
      ]);
      const statusData = await statusRes.json() as { status?: string; branch?: string };
      const logData = await logRes.json() as { log?: string };
      setStatus(statusData.status ?? "");
      setBranch(statusData.branch ?? "");
      setLog(logData.log ?? "");
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  const showDiff = async () => {
    try {
      const res = await fetch("/api/ide", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "git.diff" }) });
      const data = await res.json() as { diff?: string };
      setDiff(data.diff ?? "");
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => { refresh(); }, []);

  return (
    <div className="h-full flex flex-col">
      <div className="px-3 py-1.5 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-700 flex items-center justify-between">
        <span>Git</span>
        <button onClick={refresh} className="text-blue-400 hover:text-blue-300" title="Refresh">
          ↻
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-2 text-xs space-y-3">
        {branch && (
          <div>
            <span className="text-slate-400">Branch: </span>
            <span className="text-emerald-400 font-mono">{branch}</span>
          </div>
        )}
        <div>
          <div className="text-slate-400 mb-1">Status:</div>
          <pre className="text-slate-300 font-mono whitespace-pre-wrap">{status || "Clean"}</pre>
        </div>
        <div className="flex gap-2">
          <button onClick={showDiff} className="bg-slate-700 text-slate-300 rounded px-2 py-1 hover:bg-slate-600 text-xs">
            Show Diff
          </button>
        </div>
        {diff && (
          <div>
            <div className="text-slate-400 mb-1">Diff:</div>
            <pre className="text-slate-300 font-mono whitespace-pre-wrap overflow-x-auto">{diff}</pre>
          </div>
        )}
        {log && (
          <div>
            <div className="text-slate-400 mb-1">Recent Commits:</div>
            <pre className="text-slate-300 font-mono whitespace-pre-wrap">{log}</pre>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Status Bar ───────────────────────────────────────────

function StatusBar({ agentStatus }: { agentStatus: AgentStatus | null }) {
  return (
    <div className="h-6 bg-slate-800 border-t border-slate-700 flex items-center px-3 text-xs text-slate-400 gap-4">
      <span className="text-emerald-400">● Ready</span>
      {agentStatus && (
        <>
          <span>Agent: {agentStatus.agent}</span>
          <span>Model: {agentStatus.model}</span>
          <span>Provider: {agentStatus.provider}</span>
          {agentStatus.tokens > 0 && <span>Tokens: {agentStatus.tokens}</span>}
          {agentStatus.cost > 0 && <span>Cost: ${agentStatus.cost.toFixed(4)}</span>}
        </>
      )}
      <span className="ml-auto">Multi-Model Coding Agent Platform</span>
    </div>
  );
}

// ─── Main IDE Layout ──────────────────────────────────────

export default function IDEPage() {
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"chat" | "terminal" | "git">("chat");
  const [agentStatus, setAgentStatus] = useState<AgentStatus | null>(null);

  const handleFileSave = async (path: string, content: string) => {
    await fetch("/api/ide", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "files.write", path, content }),
    });
  };

  const handleRunTask = (task: string, model: string, type: "chat" | "code") => {
    setAgentStatus({
      agent: type === "code" ? "Coder" : "Chat",
      model,
      provider: model.includes("mistral") ? "mistral" : model.includes("openrouter") ? "openrouter" : "openai",
      task,
      currentFile: "",
      currentTool: "",
      tokens: 0,
      cost: 0,
      elapsed: 0,
      status: "running",
    });

    // Execute via API and update status
    fetch("/api/agent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ command: type, args: { [type === "code" ? "task" : "message"]: task, model } }),
    })
      .then((r) => r.json())
      .then(() => {
        setAgentStatus((prev) => prev ? { ...prev, status: "completed" } : null);
      })
      .catch(() => {
        setAgentStatus((prev) => prev ? { ...prev, status: "error" } : null);
      });
  };

  return (
    <div className="h-screen flex flex-col bg-slate-900 text-slate-100">
      {/* Top Bar */}
      <div className="h-10 bg-slate-800 border-b border-slate-700 flex items-center px-4 gap-3">
        <div className="font-bold text-sm bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
          ⚡ Agent Platform
        </div>
        <div className="flex gap-1 ml-4">
          {(["chat", "terminal", "git"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                activeTab === tab
                  ? "bg-slate-700 text-white"
                  : "text-slate-400 hover:text-white hover:bg-slate-700/50"
              }`}
            >
              {tab === "chat" ? "🤖 Chat" : tab === "terminal" ? "⬛ Terminal" : "🌿 Git"}
            </button>
          ))}
        </div>
        <div className="ml-auto flex gap-2 text-xs text-slate-500">
          <button
            onClick={() => fetch("/api/agent", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ command: "doctor" }) })}
            className="hover:text-slate-300 transition-colors"
          >
            Doctor
          </button>
          <button
            onClick={() => fetch("/api/agent", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ command: "status" }) }).then(r => r.json()).then(console.log)}
            className="hover:text-slate-300 transition-colors"
          >
            Status
          </button>
          <a href="/dashboard" className="hover:text-slate-300 transition-colors">
            Dashboard
          </a>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* File Explorer */}
        <div className="w-56 border-r border-slate-700 overflow-hidden">
          <FileExplorer onFileSelect={setSelectedFile} selectedPath={selectedFile} />
        </div>

        {/* Editor */}
        <div className="flex-1 overflow-hidden">
          <CodeEditor filePath={selectedFile} onSave={handleFileSave} />
        </div>

        {/* Right Panel */}
        <div className="w-96 border-l border-slate-700 overflow-hidden">
          {activeTab === "chat" && <AgentChat onRunTask={handleRunTask} agentStatus={agentStatus} />}
          {activeTab === "terminal" && <TerminalPanel />}
          {activeTab === "git" && <GitPanel />}
        </div>
      </div>

      {/* Status Bar */}
      <StatusBar agentStatus={agentStatus} />
    </div>
  );
}
