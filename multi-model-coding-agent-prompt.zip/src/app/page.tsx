import IDEPage from "@/components/ide";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <IDEPage />;
}
