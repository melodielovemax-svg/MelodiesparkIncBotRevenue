import { NextRequest } from "next/server";
import { AgentEngine } from "@/lib/agent";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const body = await request.json() as { task?: string; message?: string; model?: string; type?: "code" | "chat" };
  const task = body.task ?? body.message ?? "";
  const model = body.model ?? "gpt-4-turbo";
  const type = body.type ?? "chat";

  if (!task) {
    return new Response(JSON.stringify({ error: "Task or message is required" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      const send = (event: string, data: unknown) => {
        controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
      };

      try {
        const engine = new AgentEngine(process.cwd());

        if (type === "chat") {
          send("status", { message: "Starting chat..." });
          for await (const event of engine.stream([{ role: "user", content: task }], model)) {
            if (event.type === "token") send("token", { content: event.data });
            else if (event.type === "error") send("error", { message: event.data });
            else if (event.type === "done") send("done", { message: "Complete" });
          }
        } else {
          for await (const event of engine.run(task, model)) {
            send(event.type, event.data);
          }
        }
      } catch (err) {
        send("error", { message: String(err) });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
