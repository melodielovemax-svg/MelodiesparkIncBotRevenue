import { NextRequest, NextResponse } from "next/server";
import { readFile, writeFile, readdir, stat, unlink, mkdir } from "fs/promises";
import { join, dirname, relative } from "path";
import { existsSync } from "fs";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

const WORKSPACE_ROOT = process.cwd();

export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as { action: string; path?: string; content?: string; command?: string; pattern?: string };
    const { action } = body;

    switch (action) {
      case "files.list": {
        const dirPath = body.path ? join(WORKSPACE_ROOT, body.path) : WORKSPACE_ROOT;
        const entries = await readdir(dirPath, { withFileTypes: true });
        const result = entries
          .filter((e) => !e.name.startsWith(".") && e.name !== "node_modules")
          .map((e) => ({
            name: e.name,
            path: relative(WORKSPACE_ROOT, join(dirPath, e.name)),
            type: e.isDirectory() ? "directory" : "file",
          }))
          .sort((a, b) => {
            if (a.type !== b.type) return a.type === "directory" ? -1 : 1;
            return a.name.localeCompare(b.name);
          });
        return NextResponse.json({ entries: result });
      }

      case "files.read": {
        if (!body.path) return NextResponse.json({ error: "Path required" }, { status: 400 });
        const filePath = join(WORKSPACE_ROOT, body.path);
        const content = await readFile(filePath, "utf-8");
        const s = await stat(filePath);
        return NextResponse.json({ content, path: body.path, size: s.size, modified: s.mtime.toISOString() });
      }

      case "files.write": {
        if (!body.path || body.content === undefined) return NextResponse.json({ error: "Path and content required" }, { status: 400 });
        const filePath = join(WORKSPACE_ROOT, body.path);
        const dir = dirname(filePath);
        if (!existsSync(dir)) await mkdir(dir, { recursive: true });
        await writeFile(filePath, body.content, "utf-8");
        return NextResponse.json({ success: true, path: body.path });
      }

      case "files.delete": {
        if (!body.path) return NextResponse.json({ error: "Path required" }, { status: 400 });
        const filePath = join(WORKSPACE_ROOT, body.path);
        await unlink(filePath);
        return NextResponse.json({ success: true, path: body.path });
      }

      case "files.stat": {
        if (!body.path) return NextResponse.json({ error: "Path required" }, { status: 400 });
        const filePath = join(WORKSPACE_ROOT, body.path);
        const s = await stat(filePath);
        return NextResponse.json({
          path: body.path,
          isDirectory: s.isDirectory(),
          size: s.size,
          modified: s.mtime.toISOString(),
          created: s.birthtime.toISOString(),
        });
      }

      case "files.search": {
        const pattern = body.pattern ?? "*.ts";
        const basePath = body.path ? join(WORKSPACE_ROOT, body.path) : WORKSPACE_ROOT;
        try {
          const { stdout } = await execAsync(`find "${basePath}" -name "${pattern}" -type f -not -path "*/node_modules/*" -not -path "*/.git/*" -not -path "*/.next/*" 2>/dev/null | head -50`, { timeout: 5000 });
          const files = stdout.trim().split("\n").filter(Boolean).map((f) => relative(WORKSPACE_ROOT, f));
          return NextResponse.json({ files });
        } catch {
          return NextResponse.json({ files: [] });
        }
      }

      case "terminal.execute": {
        if (!body.command) return NextResponse.json({ error: "Command required" }, { status: 400 });
        try {
          const { stdout, stderr } = await execAsync(body.command, {
            cwd: WORKSPACE_ROOT,
            timeout: 30000,
            maxBuffer: 1024 * 1024,
          });
          return NextResponse.json({ stdout, stderr, exitCode: 0, success: true });
        } catch (err: unknown) {
          const e = err as { stdout?: string; stderr?: string; code?: number };
          return NextResponse.json({
            stdout: e.stdout ?? "",
            stderr: e.stderr ?? "",
            exitCode: e.code ?? 1,
            success: false,
          });
        }
      }

      case "git.status": {
        try {
          const { stdout } = await execAsync("git status --porcelain", { cwd: WORKSPACE_ROOT });
          const { stdout: branch } = await execAsync("git branch --show-current", { cwd: WORKSPACE_ROOT });
          return NextResponse.json({ branch: branch.trim(), status: stdout, files: stdout.trim().split("\n").filter(Boolean) });
        } catch (err) {
          return NextResponse.json({ error: String(err) });
        }
      }

      case "git.diff": {
        try {
          const path = body.path ? ` -- "${body.path}"` : "";
          const { stdout } = await execAsync(`git diff${path}`, { cwd: WORKSPACE_ROOT });
          return NextResponse.json({ diff: stdout });
        } catch (err) {
          return NextResponse.json({ error: String(err) });
        }
      }

      case "git.log": {
        try {
          const { stdout } = await execAsync("git log --oneline -20", { cwd: WORKSPACE_ROOT });
          return NextResponse.json({ log: stdout });
        } catch (err) {
          return NextResponse.json({ error: String(err) });
        }
      }

      default:
        return NextResponse.json({ error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
