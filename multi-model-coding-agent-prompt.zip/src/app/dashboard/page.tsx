"use client";

import { useState, useEffect } from "react";

interface MatrixEntry {
  capability: string;
  status: string;
  implementation: string;
  runtimeEvidence: string;
  tests: string;
  notes: string;
}

interface ModelEntry {
  model: string;
  provider: string;
  configured: boolean;
  status: string;
  reason?: string;
  runtimeEvidence?: string;
}

interface DashboardData {
  platform: string;
  version: string;
  timestamp: string;
  capabilityMatrix: MatrixEntry[];
  modelCapabilities: ModelEntry[];
  specializedAgents: Array<{ type: string; description: string; modelPreference: string; tools: string[] }>;
  availableTools: string[];
  databaseTables: string[];
}

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    OPERATIONAL: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
    CONFIGURED: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    BLOCKED: "bg-red-500/20 text-red-400 border-red-500/30",
    UNVERIFIED: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    SCAFFOLD: "bg-slate-500/20 text-slate-400 border-slate-500/30",
  };
  return (
    <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium border ${colors[status] || colors.SCAFFOLD}`}>
      {status}
    </span>
  );
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"capabilities" | "models" | "agents" | "tools" | "database">("capabilities");

  useEffect(() => {
    fetch("/api/matrix")
      .then((r) => r.json())
      .then((d: DashboardData) => setData(d))
      .catch((e) => setError(String(e)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-slate-400 text-lg animate-pulse">Loading platform status...</div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-red-400">Error: {error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-2">
          <div className="text-3xl">⚡</div>
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              {data.platform}
            </h1>
            <p className="text-slate-400 text-sm">Version {data.version} • Last updated: {new Date(data.timestamp).toLocaleString()}</p>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <div className="bg-slate-800 rounded-lg p-3 border border-slate-700">
            <div className="text-xs text-slate-400 mb-1">Capabilities</div>
            <div className="text-lg font-bold text-emerald-400">{data.capabilityMatrix.filter((c) => c.status === "OPERATIONAL").length}/{data.capabilityMatrix.length}</div>
            <div className="text-xs text-slate-500">Operational</div>
          </div>
          <div className="bg-slate-800 rounded-lg p-3 border border-slate-700">
            <div className="text-xs text-slate-400 mb-1">Models</div>
            <div className="text-lg font-bold text-blue-400">{data.modelCapabilities.length}</div>
            <div className="text-xs text-slate-500">Registered</div>
          </div>
          <div className="bg-slate-800 rounded-lg p-3 border border-slate-700">
            <div className="text-xs text-slate-400 mb-1">Tools</div>
            <div className="text-lg font-bold text-purple-400">{data.availableTools.length}</div>
            <div className="text-xs text-slate-500">Available</div>
          </div>
          <div className="bg-slate-800 rounded-lg p-3 border border-slate-700">
            <div className="text-xs text-slate-400 mb-1">DB Tables</div>
            <div className="text-lg font-bold text-amber-400">{data.databaseTables.length}</div>
            <div className="text-xs text-slate-500">Persisted</div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-1 mb-4 bg-slate-800/50 p-1 rounded-lg w-fit">
          {(["capabilities", "models", "agents", "tools", "database"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === tab
                  ? "bg-slate-700 text-white shadow-sm"
                  : "text-slate-400 hover:text-white hover:bg-slate-700/50"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === "capabilities" && (
          <div className="bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700 bg-slate-800/50">
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Capability</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Status</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Implementation</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Evidence</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Notes</th>
                </tr>
              </thead>
              <tbody>
                {data.capabilityMatrix.map((entry, i) => (
                  <tr key={i} className="border-b border-slate-700/50 hover:bg-slate-700/20">
                    <td className="px-4 py-3 font-medium">{entry.capability}</td>
                    <td className="px-4 py-3"><StatusBadge status={entry.status} /></td>
                    <td className="px-4 py-3 text-xs text-slate-400 max-w-xs truncate">{entry.implementation}</td>
                    <td className="px-4 py-3 text-xs text-slate-400">{entry.runtimeEvidence}</td>
                    <td className="px-4 py-3 text-xs text-slate-500">{entry.notes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === "models" && (
          <div className="bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700 bg-slate-800/50">
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Model</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Provider</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Configured</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Status</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Evidence</th>
                </tr>
              </thead>
              <tbody>
                {data.modelCapabilities.map((entry, i) => (
                  <tr key={i} className="border-b border-slate-700/50 hover:bg-slate-700/20">
                    <td className="px-4 py-3 font-medium">{entry.model}</td>
                    <td className="px-4 py-3 text-slate-400">{entry.provider}</td>
                    <td className="px-4 py-3">{entry.configured ? "✅" : "❌"}</td>
                    <td className="px-4 py-3"><StatusBadge status={entry.status} /></td>
                    <td className="px-4 py-3 text-xs text-slate-500">{entry.runtimeEvidence || entry.reason || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === "agents" && (
          <div className="bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700 bg-slate-800/50">
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Agent Type</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Description</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Model Preference</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Tools</th>
                </tr>
              </thead>
              <tbody>
                {data.specializedAgents.map((agent, i) => (
                  <tr key={i} className="border-b border-slate-700/50 hover:bg-slate-700/20">
                    <td className="px-4 py-3 font-medium capitalize">{agent.type}</td>
                    <td className="px-4 py-3 text-slate-400 text-xs">{agent.description}</td>
                    <td className="px-4 py-3 text-slate-400 font-mono text-xs">{agent.modelPreference}</td>
                    <td className="px-4 py-3 text-slate-500 text-xs">{agent.tools.length} tools</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === "tools" && (
          <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
            <h3 className="text-sm font-medium mb-3">Available Tools ({data.availableTools.length})</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {data.availableTools.map((tool) => (
                <div key={tool} className="bg-slate-700/50 rounded px-3 py-2 text-xs font-mono text-slate-300">
                  {tool}
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "database" && (
          <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
            <h3 className="text-sm font-medium mb-3">Database Tables ({data.databaseTables.length})</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {data.databaseTables.map((table) => (
                <div key={table} className="bg-slate-700/50 rounded px-3 py-2 text-xs font-mono text-slate-300">
                  {table}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-8 text-center text-xs text-slate-600">
          <p>Multi-Model CLI + IDE Coding Agent Platform • Runtime Verification Required for Model Availability</p>
          <p className="mt-1">REQUESTED ≠ CONFIGURED ≠ IMPLEMENTED ≠ AVAILABLE ≠ OPERATIONAL</p>
        </div>
      </div>
    </div>
  );
}
