// ═══════════════════════════════════════════════════════════
// AGENT ENGINE — Agent loop, tools, context, planner, sessions
// ═══════════════════════════════════════════════════════════

import { readFile, writeFile, readdir, stat, unlink, mkdir } from "fs/promises";
import { exec } from "child_process";
import { promisify } from "util";
import { join, relative, dirname } from "path";
import { existsSync } from "fs";
import type { ChatMessage, ChatRequest, ChatResponse, ToolDefinition, ToolCallResult, ModelProvider } from "./models";
import { createModelGatewaySafe } from "./models";
import type { RoutingStrategy } from "./models";

const execAsync = promisify(exec);

// ─── Security Policies ────────────────────────────────────

export type CommandClassification = "ALLOW" | "CONFIRM" | "DENY";

export interface SecurityPolicy {
  classifyCommand(command: string): CommandClassification;
  classifyFileWrite(path: string): CommandClassification;
  isPathAllowed(path: string): boolean;
  maxExecutionTimeMs: number;
  maxOutputBytes: number;
}

export class DefaultSecurityPolicy implements SecurityPolicy {
  maxExecutionTimeMs = 30_000;
  maxOutputBytes = 1_000_000;
  private workspaceRoot: string;

  constructor(workspaceRoot: string) {
    this.workspaceRoot = workspaceRoot;
  }

  classifyCommand(command: string): CommandClassification {
    const cmd = command.trim().toLowerCase();
    const denyPatterns = ["rm -rf /", "mkfs", "dd if=", "format", "del /f /s /q c:", ":(){ :|:& };:", "shutdown", "reboot", "halt", "poweroff"];
    for (const p of denyPatterns) { if (cmd.includes(p)) return "DENY"; }

    const confirmPatterns = ["git push", "git commit", "npm publish", "docker push", "rm -rf", "rmdir /s"];
    for (const p of confirmPatterns) { if (cmd.startsWith(p) || cmd.includes(` ${p}`)) return "CONFIRM"; }

    return "ALLOW";
  }

  classifyFileWrite(path: string): CommandClassification {
    const normalized = path.toLowerCase();
    const denyPaths = ["/etc/", "/sys/", "/proc/", "c:\\windows\\", "c:\\system32\\"];
    for (const dp of denyPaths) { if (normalized.startsWith(dp)) return "DENY"; }
    return "ALLOW";
  }

  isPathAllowed(path: string): boolean {
    if (!this.workspaceRoot) return true;
    const rel = relative(this.workspaceRoot, path);
    return !rel.startsWith("..") && !rel.startsWith("/");
  }
}

// ─── Tool Definitions ─────────────────────────────────────

export interface ToolSchema {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

export interface ToolResult {
  success: boolean;
  output: string;
  error?: string;
  exitCode?: number;
  durationMs?: number;
}

export const TOOL_DEFINITIONS: ToolDefinition[] = [
  {
    type: "function",
    function: {
      name: "filesystem.read",
      description: "Read the contents of a file at the given path",
      parameters: {
        type: "object",
        properties: { path: { type: "string", description: "File path relative to workspace" } },
        required: ["path"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "filesystem.write",
      description: "Write content to a file, creating it if it doesn't exist",
      parameters: {
        type: "object",
        properties: {
          path: { type: "string", description: "File path relative to workspace" },
          content: { type: "string", description: "Content to write" },
        },
        required: ["path", "content"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "filesystem.list",
      description: "List files and directories at the given path",
      parameters: {
        type: "object",
        properties: { path: { type: "string", description: "Directory path relative to workspace" } },
        required: ["path"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "filesystem.delete",
      description: "Delete a file at the given path",
      parameters: {
        type: "object",
        properties: { path: { type: "string", description: "File path relative to workspace" } },
        required: ["path"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "filesystem.search",
      description: "Search for files matching a glob pattern",
      parameters: {
        type: "object",
        properties: {
          pattern: { type: "string", description: "Glob pattern to match" },
          path: { type: "string", description: "Base directory to search" },
        },
        required: ["pattern"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "filesystem.patch",
      description: "Apply a patch/diff to a file",
      parameters: {
        type: "object",
        properties: {
          path: { type: "string", description: "File path relative to workspace" },
          search: { type: "string", description: "Text to search for" },
          replace: { type: "string", description: "Text to replace with" },
        },
        required: ["path", "search", "replace"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "shell.execute",
      description: "Execute a shell command and return output",
      parameters: {
        type: "object",
        properties: {
          command: { type: "string", description: "Shell command to execute" },
          timeout: { type: "number", description: "Timeout in milliseconds" },
        },
        required: ["command"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "git.status",
      description: "Get git repository status",
      parameters: { type: "object", properties: {} },
    },
  },
  {
    type: "function",
    function: {
      name: "git.diff",
      description: "Get git diff output",
      parameters: {
        type: "object",
        properties: { path: { type: "string", description: "Specific file path" } },
      },
    },
  },
  {
    type: "function",
    function: {
      name: "git.log",
      description: "Get git log",
      parameters: {
        type: "object",
        properties: { count: { type: "number", description: "Number of commits" } },
      },
    },
  },
  {
    type: "function",
    function: {
      name: "code.search",
      description: "Search code content using regex pattern",
      parameters: {
        type: "object",
        properties: {
          pattern: { type: "string", description: "Regex pattern to search" },
          path: { type: "string", description: "Directory to search in" },
        },
        required: ["pattern"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "test.run",
      description: "Run tests and return results",
      parameters: {
        type: "object",
        properties: {
          command: { type: "string", description: "Test command to run" },
          path: { type: "string", description: "Directory to run tests in" },
        },
      },
    },
  },
];

// ─── Tool Executor ────────────────────────────────────────

export class ToolExecutor {
  constructor(
    private workspaceRoot: string,
    private securityPolicy: SecurityPolicy,
  ) {}

  async execute(toolName: string, input: Record<string, unknown>): Promise<ToolResult> {
    const start = Date.now();
    try {
      switch (toolName) {
        case "filesystem.read": return await this.fsRead(input);
        case "filesystem.write": return await this.fsWrite(input);
        case "filesystem.list": return await this.fsList(input);
        case "filesystem.delete": return await this.fsDelete(input);
        case "filesystem.search": return await this.fsSearch(input);
        case "filesystem.patch": return await this.fsPatch(input);
        case "shell.execute": return await this.shellExecute(input);
        case "git.status": return await this.gitStatus();
        case "git.diff": return await this.gitDiff(input);
        case "git.log": return await this.gitLog(input);
        case "code.search": return await this.codeSearch(input);
        case "test.run": return await this.testRun(input);
        default: return { success: false, output: "", error: `Unknown tool: ${toolName}`, durationMs: Date.now() - start };
      }
    } catch (err) {
      return { success: false, output: "", error: String(err), durationMs: Date.now() - start };
    }
  }

  private resolvePath(p: string): string {
    return join(this.workspaceRoot, p);
  }

  private async fsRead(input: Record<string, unknown>): Promise<ToolResult> {
    const filePath = this.resolvePath(String(input.path));
    const content = await readFile(filePath, "utf-8");
    return { success: true, output: content, durationMs: 0 };
  }

  private async fsWrite(input: Record<string, unknown>): Promise<ToolResult> {
    const filePath = this.resolvePath(String(input.path));
    const classification = this.securityPolicy.classifyFileWrite(filePath);
    if (classification === "DENY") return { success: false, output: "", error: "Write denied by security policy" };
    const dir = dirname(filePath);
    if (!existsSync(dir)) await mkdir(dir, { recursive: true });
    await writeFile(filePath, String(input.content), "utf-8");
    return { success: true, output: `Wrote ${String(input.path)}`, durationMs: 0 };
  }

  private async fsList(input: Record<string, unknown>): Promise<ToolResult> {
    const dirPath = this.resolvePath(String(input.path ?? "."));
    const entries = await readdir(dirPath, { withFileTypes: true });
    const result = entries.map((e) => `${e.isDirectory() ? "📁" : "📄"} ${e.name}`).join("\n");
    return { success: true, output: result, durationMs: 0 };
  }

  private async fsDelete(input: Record<string, unknown>): Promise<ToolResult> {
    const filePath = this.resolvePath(String(input.path));
    const classification = this.securityPolicy.classifyFileWrite(filePath);
    if (classification !== "ALLOW") return { success: false, output: "", error: "Delete denied by security policy" };
    await unlink(filePath);
    return { success: true, output: `Deleted ${String(input.path)}`, durationMs: 0 };
  }

  private async fsSearch(input: Record<string, unknown>): Promise<ToolResult> {
    const pattern = String(input.pattern);
    const basePath = this.resolvePath(String(input.path ?? "."));
    const { stdout } = await execAsync(`find "${basePath}" -name "${pattern}" -type f 2>/dev/null | head -50`, { timeout: 10000 });
    return { success: true, output: stdout || "No files found", durationMs: 0 };
  }

  private async fsPatch(input: Record<string, unknown>): Promise<ToolResult> {
    const filePath = this.resolvePath(String(input.path));
    const search = String(input.search);
    const replace = String(input.replace);
    const content = await readFile(filePath, "utf-8");
    if (!content.includes(search)) return { success: false, output: "", error: "Search text not found in file" };
    const newContent = content.replace(search, replace);
    await writeFile(filePath, newContent, "utf-8");
    return { success: true, output: `Patched ${String(input.path)}`, durationMs: 0 };
  }

  private async shellExecute(input: Record<string, unknown>): Promise<ToolResult> {
    const command = String(input.command);
    const classification = this.securityPolicy.classifyCommand(command);
    if (classification === "DENY") return { success: false, output: "", error: `Command denied by security policy: ${command}` };
    if (classification === "CONFIRM") return { success: false, output: "", error: `Command requires confirmation: ${command}` };

    const timeout = Number(input.timeout) || this.securityPolicy.maxExecutionTimeMs;
    const start = Date.now();
    try {
      const { stdout, stderr } = await execAsync(command, {
        cwd: this.workspaceRoot,
        timeout,
        maxBuffer: this.securityPolicy.maxOutputBytes,
      });
      return { success: true, output: stdout + (stderr ? `\n--- stderr ---\n${stderr}` : ""), durationMs: Date.now() - start };
    } catch (err: unknown) {
      const e = err as { stdout?: string; stderr?: string; code?: number };
      return {
        success: false,
        output: (e.stdout || "") + (e.stderr ? `\n--- stderr ---\n${e.stderr}` : ""),
        error: `Command failed with exit code ${e.code}`,
        exitCode: e.code,
        durationMs: Date.now() - start,
      };
    }
  }

  private async gitStatus(): Promise<ToolResult> {
    return this.shellExecute({ command: "git status --porcelain" });
  }

  private async gitDiff(input: Record<string, unknown>): Promise<ToolResult> {
    const path = input.path ? ` -- "${String(input.path)}"` : "";
    return this.shellExecute({ command: `git diff${path}` });
  }

  private async gitLog(input: Record<string, unknown>): Promise<ToolResult> {
    const count = Number(input.count) || 10;
    return this.shellExecute({ command: `git log --oneline -${count}` });
  }

  private async codeSearch(input: Record<string, unknown>): Promise<ToolResult> {
    const pattern = String(input.pattern);
    const path = String(input.path ?? ".");
    return this.shellExecute({ command: `grep -r --include="*.{ts,tsx,js,jsx,py,rs,go,java}" -n "${pattern}" "${path}" 2>/dev/null | head -50` });
  }

  private async testRun(input: Record<string, unknown>): Promise<ToolResult> {
    const command = String(input.command ?? "npm test");
    const path = input.path ? String(input.path) : undefined;
    const result = await this.shellExecute({ command, timeout: 60000 });
    return { ...result, exitCode: result.exitCode };
  }
}

// ─── Context Builder ──────────────────────────────────────

export class ContextBuilder {
  constructor(private workspaceRoot: string) {}

  async buildContext(task: string, model: string, contextWindow: number): Promise<ChatMessage[]> {
    const messages: ChatMessage[] = [];

    // System prompt
    messages.push({
      role: "system",
      content: `You are an expert coding agent. You have access to tools for reading, writing, and searching files, executing commands, and working with git.

Working directory: ${this.workspaceRoot}

When modifying files, use filesystem.write or filesystem.patch.
When running commands, use shell.execute.
Always verify your changes by reading the file after writing.
Run tests after making changes to verify correctness.

Be precise and thorough. Explain your reasoning before taking actions.`,
    });

    // Add task context
    messages.push({
      role: "user",
      content: task,
    });

    return messages;
  }

  async getRelevantContext(query: string, budget: number): Promise<string> {
    try {
      const { stdout } = await execAsync(`grep -rl --include="*.{ts,tsx,js,jsx}" "${query}" . 2>/dev/null | head -10`, {
        cwd: this.workspaceRoot,
        timeout: 5000,
      });
      if (!stdout.trim()) return "";
      const files = stdout.trim().split("\n").slice(0, 5);
      let context = "";
      for (const file of files) {
        try {
          const content = await readFile(join(this.workspaceRoot, file), "utf-8");
          const excerpt = content.slice(0, Math.min(2000, budget - context.length));
          context += `\n--- ${file} ---\n${excerpt}\n`;
          if (context.length >= budget) break;
        } catch { /* skip unreadable files */ }
      }
      return context;
    } catch {
      return "";
    }
  }
}

// ─── Agent Session ────────────────────────────────────────

export interface AgentSession {
  id: string;
  workspaceRoot: string;
  modelId: string;
  providerId: string;
  messages: ChatMessage[];
  toolResults: Map<string, ToolResult>;
  status: "idle" | "running" | "waiting" | "error" | "completed";
  createdAt: Date;
  updatedAt: Date;
}

// ─── Agent Engine ─────────────────────────────────────────

export interface AgentEvent {
  type: "thinking" | "tool_call" | "tool_result" | "token" | "done" | "error" | "status";
  data: unknown;
}

export class AgentEngine {
  private toolExecutor: ToolExecutor;
  private contextBuilder: ContextBuilder;
  private securityPolicy: SecurityPolicy;
  private providerRegistry: ReturnType<typeof createModelGatewaySafe>["providerRegistry"];
  private modelRegistry: ReturnType<typeof createModelGatewaySafe>["modelRegistry"];
  private modelRouter: ReturnType<typeof createModelGatewaySafe>["modelRouter"];

  constructor(workspaceRoot: string) {
    this.securityPolicy = new DefaultSecurityPolicy(workspaceRoot);
    this.toolExecutor = new ToolExecutor(workspaceRoot, this.securityPolicy);
    this.contextBuilder = new ContextBuilder(workspaceRoot);
    const gateway = createModelGatewaySafe();
    this.providerRegistry = gateway.providerRegistry;
    this.modelRegistry = gateway.modelRegistry;
    this.modelRouter = gateway.modelRouter;
  }

  async *run(
    task: string,
    modelId: string = "gpt-4-turbo",
    strategy: RoutingStrategy = "fixed",
    maxIterations: number = 20,
  ): AsyncGenerator<AgentEvent> {
    yield { type: "status", data: `Starting agent with model ${modelId}` };

    // Resolve model
    const resolved = this.modelRouter.resolve(modelId, strategy, "coding");
    if (!resolved) {
      yield { type: "error", data: `Model ${modelId} not found in registry` };
      return;
    }

    const { model, provider } = resolved;

    // Check capabilities
    if (model.availability === "blocked") {
      yield { type: "error", data: `Model ${modelId} is blocked: ${model.availabilityReason}` };
      return;
    }

    if (!provider.isConfigured) {
      yield { type: "error", data: `Provider ${provider.id} is not configured (API key missing)` };
      return;
    }

    // Build context
    yield { type: "thinking", data: "Building context..." };
    let messages = await this.contextBuilder.buildContext(task, modelId, model.capabilities.contextWindow);

    // Agent loop
    for (let iteration = 0; iteration < maxIterations; iteration++) {
      yield { type: "status", data: `Iteration ${iteration + 1}/${maxIterations}` };

      try {
        // Call model
        const request: ChatRequest = {
          messages,
          model: model.id,
          tools: model.capabilities.supportsTools ? TOOL_DEFINITIONS : undefined,
          temperature: 0.3,
          maxTokens: model.capabilities.maxTokensOut,
        };

        const response = await provider.chat(request);

        // Add assistant message
        messages.push({
          role: "assistant",
          content: response.content,
          toolCalls: response.toolCalls,
        });

        yield { type: "token", data: response.content };

        // Process tool calls
        if (response.toolCalls && response.toolCalls.length > 0) {
          for (const tc of response.toolCalls) {
            yield { type: "tool_call", data: tc };

            let toolInput: Record<string, unknown>;
            try {
              toolInput = JSON.parse(tc.function.arguments);
            } catch {
              toolInput = {};
            }

            const result = await this.toolExecutor.execute(tc.function.name, toolInput);
            yield { type: "tool_result", data: { toolCall: tc, result } };

            // Add tool result to messages
            messages.push({
              role: "tool",
              content: result.success ? result.output : `Error: ${result.error}\n${result.output}`,
              toolCallId: tc.id,
              name: tc.function.name,
            });
          }
        } else {
          // No tool calls - agent is done
          yield { type: "done", data: response.content };
          return;
        }

        // Check if the model indicates completion
        if (response.content && !response.toolCalls?.length) {
          yield { type: "done", data: response.content };
          return;
        }
      } catch (err) {
        yield { type: "error", data: `Model error: ${String(err)}` };

        // Try fallback
        try {
          const fallback = await this.modelRouter.resolveWithFallback(modelId, "fallback", "coding");
          if (fallback.isFallback) {
            yield { type: "status", data: `Falling back to ${fallback.model.id} from ${fallback.fallbackFrom}` };
            // Re-run with fallback model (simplified - just notify, don't recurse)
          }
        } catch {
          yield { type: "error", data: "No fallback model available" };
          return;
        }
        return;
      }
    }

    yield { type: "status", data: "Max iterations reached" };
    yield { type: "done", data: "Agent completed (max iterations)" };
  }

  async chat(
    messages: ChatMessage[],
    modelId: string = "gpt-4-turbo",
  ): Promise<ChatResponse> {
    const resolved = this.modelRouter.resolve(modelId, "fixed");
    if (!resolved) throw new Error(`Model ${modelId} not found`);
    if (!resolved.provider.isConfigured) throw new Error(`Provider ${resolved.provider.id} not configured`);
    return resolved.provider.chat({ messages, model: resolved.model.id, temperature: 0.7 });
  }

  async *stream(
    messages: ChatMessage[],
    modelId: string = "gpt-4-turbo",
  ): AsyncGenerator<AgentEvent> {
    const resolved = this.modelRouter.resolve(modelId, "fixed");
    if (!resolved) { yield { type: "error", data: `Model ${modelId} not found` }; return; }
    if (!resolved.provider.isConfigured) { yield { type: "error", data: `Provider ${resolved.provider.id} not configured` }; return; }

    for await (const chunk of resolved.provider.stream({ messages, model: resolved.model.id, temperature: 0.7 })) {
      if (chunk.type === "token") yield { type: "token", data: chunk.data };
      else if (chunk.type === "error") yield { type: "error", data: chunk.data };
      else if (chunk.type === "done") yield { type: "done", data: null };
    }
  }

  getProviderRegistry() { return this.providerRegistry; }
  getModelRegistry() { return this.modelRegistry; }
  getModelRouter() { return this.modelRouter; }
  getSecurityPolicy() { return this.securityPolicy; }
  getToolExecutor() { return this.toolExecutor; }
}

// ─── Checkpoint System ────────────────────────────────────

export interface Checkpoint {
  id: string;
  label: string;
  gitCommitHash?: string;
  filesChanged: string[];
  diff?: string;
  timestamp: Date;
}

export class CheckpointManager {
  constructor(private workspaceRoot: string) {}

  async create(label: string): Promise<Checkpoint> {
    const id = `cp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    let gitCommitHash: string | undefined;
    let diff: string | undefined;
    const filesChanged: string[] = [];

    try {
      // Check if we're in a git repo
      await execAsync("git rev-parse --git-dir", { cwd: this.workspaceRoot });

      // Stage all changes
      await execAsync("git add -A", { cwd: this.workspaceRoot });

      // Get diff before committing
      try {
        const { stdout } = await execAsync("git diff --cached", { cwd: this.workspaceRoot });
        diff = stdout;
      } catch { /* no diff */ }

      // Create commit
      const { stdout: commitHash } = await execAsync(`git commit -m "checkpoint: ${label}" --allow-empty`, { cwd: this.workspaceRoot });
      gitCommitHash = commitHash.trim().split("\n")[0]?.replace(/\[.*\]/, "").trim();

      // Get changed files
      try {
        const { stdout } = await execAsync("git diff --name-only HEAD~1 HEAD", { cwd: this.workspaceRoot });
        filesChanged.push(...stdout.trim().split("\n").filter(Boolean));
      } catch { /* no changes */ }
    } catch {
      // Not a git repo or git not available
    }

    return { id, label, gitCommitHash, filesChanged, diff, timestamp: new Date() };
  }

  async restore(checkpoint: Checkpoint): Promise<boolean> {
    if (!checkpoint.gitCommitHash) return false;
    try {
      await execAsync(`git checkout ${checkpoint.gitCommitHash}`, { cwd: this.workspaceRoot });
      return true;
    } catch {
      return false;
    }
  }

  async list(): Promise<Checkpoint[]> {
    try {
      const { stdout } = await execAsync('git log --oneline --grep="checkpoint:" -20', { cwd: this.workspaceRoot });
      return stdout.trim().split("\n").filter(Boolean).map((line) => {
        const [hash, ...msgParts] = line.split(" ");
        return {
          id: hash,
          label: msgParts.join(" ").replace("checkpoint: ", ""),
          gitCommitHash: hash,
          filesChanged: [],
          timestamp: new Date(),
        };
      });
    } catch {
      return [];
    }
  }
}

// ─── Repository Indexer ───────────────────────────────────

export interface RepoIndex {
  files: Array<{
    path: string;
    name: string;
    extension: string;
    directory: string;
    size: number;
  }>;
  totalFiles: number;
  totalDirectories: number;
  languages: Record<string, number>;
}

export class RepositoryIndexer {
  constructor(private workspaceRoot: string) {}

  async index(): Promise<RepoIndex> {
    const files: RepoIndex["files"] = [];
    const languages: Record<string, number> = {};
    let totalDirectories = 0;

    const extToLang: Record<string, string> = {
      ".ts": "TypeScript", ".tsx": "TypeScript", ".js": "JavaScript", ".jsx": "JavaScript",
      ".py": "Python", ".rs": "Rust", ".go": "Go", ".java": "Java",
      ".css": "CSS", ".html": "HTML", ".json": "JSON", ".md": "Markdown",
      ".sql": "SQL", ".sh": "Shell", ".yaml": "YAML", ".yml": "YAML",
    };

    const walkDir = async (dir: string, relDir: string) => {
      try {
        const entries = await readdir(dir, { withFileTypes: true });
        for (const entry of entries) {
          if (entry.name.startsWith(".") || entry.name === "node_modules" || entry.name === ".git") continue;
          const fullPath = join(dir, entry.name);
          const relPath = join(relDir, entry.name);
          if (entry.isDirectory()) {
            totalDirectories++;
            await walkDir(fullPath, relPath);
          } else {
            const ext = entry.name.includes(".") ? `.${entry.name.split(".").pop()}` : "";
            const lang = extToLang[ext] || "Other";
            languages[lang] = (languages[lang] || 0) + 1;
            try {
              const s = await stat(fullPath);
              files.push({ path: relPath, name: entry.name, extension: ext, directory: relDir, size: s.size });
            } catch { /* skip */ }
          }
        }
      } catch { /* skip unreadable dirs */ }
    };

    await walkDir(this.workspaceRoot, "");
    return { files, totalFiles: files.length, totalDirectories, languages };
  }
}

// ─── Multi-Agent Orchestration ────────────────────────────

export type AgentType = "planner" | "researcher" | "coder" | "reviewer" | "tester" | "debugger" | "security" | "documentation";

export interface SpecializedAgent {
  type: AgentType;
  description: string;
  systemPrompt: string;
  modelPreference: string;
  tools: string[];
  maxIterations: number;
}

export const SPECIALIZED_AGENTS: Record<AgentType, SpecializedAgent> = {
  planner: {
    type: "planner",
    description: "Creates execution plans for tasks",
    systemPrompt: "You are a planning agent. Break down tasks into clear, ordered steps. Do not execute changes, only plan.",
    modelPreference: "gpt-4-turbo",
    tools: ["filesystem.read", "filesystem.list", "code.search"],
    maxIterations: 5,
  },
  researcher: {
    type: "researcher",
    description: "Researches codebase and gathers context",
    systemPrompt: "You are a research agent. Investigate the codebase, find relevant files, patterns, and context. Do not modify anything.",
    modelPreference: "gpt-4-turbo",
    tools: ["filesystem.read", "filesystem.list", "filesystem.search", "code.search"],
    maxIterations: 10,
  },
  coder: {
    type: "coder",
    description: "Implements code changes",
    systemPrompt: "You are a coding agent. Implement the specified changes precisely and correctly. Verify your work by reading files after writing.",
    modelPreference: "gpt-4-turbo",
    tools: ["filesystem.read", "filesystem.write", "filesystem.patch", "filesystem.list", "shell.execute"],
    maxIterations: 20,
  },
  reviewer: {
    type: "reviewer",
    description: "Reviews code for quality and correctness",
    systemPrompt: "You are a code review agent. Analyze changes for bugs, style issues, security concerns, and best practices. Provide specific feedback.",
    modelPreference: "gpt-4-turbo",
    tools: ["filesystem.read", "code.search", "git.diff"],
    maxIterations: 10,
  },
  tester: {
    type: "tester",
    description: "Runs tests and fixes failures",
    systemPrompt: "You are a testing agent. Run tests, analyze failures, and fix broken tests. Verify all tests pass.",
    modelPreference: "gpt-4-turbo",
    tools: ["filesystem.read", "filesystem.write", "filesystem.patch", "shell.execute", "test.run"],
    maxIterations: 15,
  },
  debugger: {
    type: "debugger",
    description: "Debugs issues and traces errors",
    systemPrompt: "You are a debugging agent. Trace errors to their source, identify root causes, and propose or implement fixes.",
    modelPreference: "gpt-4-turbo",
    tools: ["filesystem.read", "filesystem.search", "code.search", "shell.execute", "test.run"],
    maxIterations: 15,
  },
  security: {
    type: "security",
    description: "Analyzes security concerns",
    systemPrompt: "You are a security agent. Review code for vulnerabilities, injection risks, and security best practices.",
    modelPreference: "gpt-4-turbo",
    tools: ["filesystem.read", "code.search"],
    maxIterations: 10,
  },
  documentation: {
    type: "documentation",
    description: "Generates documentation",
    systemPrompt: "You are a documentation agent. Generate clear, accurate documentation for code. Include examples and type information.",
    modelPreference: "gpt-4-turbo",
    tools: ["filesystem.read", "filesystem.write", "code.search"],
    maxIterations: 10,
  },
};

// ─── Cost Tracker ─────────────────────────────────────────

export interface CostEntry {
  provider: string;
  model: string;
  tokensIn: number;
  tokensOut: number;
  tokensCached: number;
  estimatedCost: number;
  durationMs: number;
  timestamp: Date;
  sessionId?: string;
  taskId?: string;
}

export class CostTracker {
  private entries: CostEntry[] = [];

  record(entry: Omit<CostEntry, "timestamp">): void {
    this.entries.push({ ...entry, timestamp: new Date() });
  }

  getTotalCost(): number {
    return this.entries.reduce((sum, e) => sum + e.estimatedCost, 0);
  }

  getCostByModel(): Record<string, number> {
    const result: Record<string, number> = {};
    for (const e of this.entries) {
      result[e.model] = (result[e.model] || 0) + e.estimatedCost;
    }
    return result;
  }

  getCostByProvider(): Record<string, number> {
    const result: Record<string, number> = {};
    for (const e of this.entries) {
      result[e.provider] = (result[e.provider] || 0) + e.estimatedCost;
    }
    return result;
  }

  getEntries(): CostEntry[] {
    return [...this.entries];
  }

  getEntriesForSession(sessionId: string): CostEntry[] {
    return this.entries.filter((e) => e.sessionId === sessionId);
  }
}

// ─── Audit Logger ─────────────────────────────────────────

export interface AuditEntry {
  eventType: string;
  action: string;
  resource?: string;
  details?: Record<string, unknown>;
  severity: "info" | "warn" | "error" | "critical";
  timestamp: Date;
  sessionId?: string;
  taskId?: string;
}

export class AuditLogger {
  private entries: AuditEntry[] = [];

  log(entry: Omit<AuditEntry, "timestamp">): void {
    this.entries.push({ ...entry, timestamp: new Date() });
  }

  getEntries(filter?: { eventType?: string; severity?: string; sessionId?: string }): AuditEntry[] {
    return this.entries.filter((e) => {
      if (filter?.eventType && e.eventType !== filter.eventType) return false;
      if (filter?.severity && e.severity !== filter.severity) return false;
      if (filter?.sessionId && e.sessionId !== filter.sessionId) return false;
      return true;
    });
  }

  info(action: string, resource?: string, details?: Record<string, unknown>): void {
    this.log({ eventType: "general", action, resource, details, severity: "info" });
  }

  warn(action: string, resource?: string, details?: Record<string, unknown>): void {
    this.log({ eventType: "general", action, resource, details, severity: "warn" });
  }

  error(action: string, resource?: string, details?: Record<string, unknown>): void {
    this.log({ eventType: "general", action, resource, details, severity: "error" });
  }
}
