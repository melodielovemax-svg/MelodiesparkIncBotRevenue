// ═══════════════════════════════════════════════════════════
// MODEL GATEWAY — Provider abstraction, registry, router, adapters
// ═══════════════════════════════════════════════════════════

import { z } from "zod";

// ─── Core Types ───────────────────────────────────────────

export interface ModelCapabilities {
  contextWindow: number;
  supportsStreaming: boolean;
  supportsTools: boolean;
  supportsVision: boolean;
  supportsJson: boolean;
  supportsCode: boolean;
  maxTokensOut?: number;
  supportsBatch?: boolean;
  supportsSystemPrompt?: boolean;
}

export interface ModelInfo {
  id: string;
  providerId: string;
  displayName: string;
  canonicalProviderId: string;
  legacyAliases: string[];
  capabilities: ModelCapabilities;
  costPerTokenIn: number;  // USD
  costPerTokenOut: number; // USD
  availability: "available" | "unavailable" | "unknown" | "blocked";
  availabilityReason?: string;
}

export interface ChatMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  toolCalls?: ToolCallResult[];
  toolCallId?: string;
  name?: string;
}

export interface ToolDefinition {
  type: "function";
  function: {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
  };
}

export interface ToolCallResult {
  id: string;
  type: "function";
  function: { name: string; arguments: string };
}

export interface ChatRequest {
  messages: ChatMessage[];
  model: string;
  tools?: ToolDefinition[];
  temperature?: number;
  maxTokens?: number;
  stream?: boolean;
  requestId?: string;
  sessionId?: string;
  taskId?: string;
}

export interface ChatResponse {
  content: string;
  toolCalls?: ToolCallResult[];
  usage: {
    tokensIn: number;
    tokensOut: number;
    tokensCached: number;
  };
  model: string;
  provider: string;
  durationMs: number;
  isFallback: boolean;
  fallbackFromModel?: string;
}

export interface StreamChunk {
  type: "token" | "tool_call" | "status" | "error" | "done" | "usage";
  data: unknown;
}

export interface ProviderHealthResult {
  provider: string;
  configured: boolean;
  reachable: boolean;
  error?: string;
  responseTimeMs?: number;
}

export interface ModelVerifyResult {
  model: string;
  provider: string;
  configured: boolean;
  reachable: boolean;
  available: boolean;
  supportsTools: boolean;
  supportsStreaming: boolean;
  contextWindow: number;
  status: "OPERATIONAL" | "BLOCKED" | "UNVERIFIED" | "SCAFFOLD";
  reason?: string;
  evidence?: string;
}

// ─── Base Provider ────────────────────────────────────────

export abstract class ModelProvider {
  abstract readonly id: string;
  abstract readonly name: string;
  protected apiKey: string | undefined;

  constructor(apiKey?: string) {
    this.apiKey = apiKey;
  }

  get isConfigured(): boolean {
    return !!this.apiKey && this.apiKey.length > 0;
  }

  abstract listModels(): ModelInfo[];
  abstract chat(request: ChatRequest): Promise<ChatResponse>;
  abstract stream(request: ChatRequest): AsyncIterable<StreamChunk>;
  abstract healthCheck(): Promise<ProviderHealthResult>;
  abstract estimateCost(modelId: string, tokensIn: number, tokensOut: number): number;

  getModel(modelId: string): ModelInfo | undefined {
    return this.listModels().find((m) => m.id === modelId || m.legacyAliases.includes(modelId));
  }

  getCapabilities(modelId: string): ModelCapabilities | undefined {
    return this.getModel(modelId)?.capabilities;
  }
}

// ─── OpenAI Provider ──────────────────────────────────────

export class OpenAIProvider extends ModelProvider {
  readonly id = "openai";
  readonly name = "OpenAI";
  private baseUrl: string;

  constructor(apiKey?: string, baseUrl?: string) {
    super(apiKey);
    this.baseUrl = baseUrl || "https://api.openai.com/v1";
  }

  listModels(): ModelInfo[] {
    return [
      {
        id: "gpt-4-turbo",
        providerId: "openai",
        displayName: "GPT-4 Turbo",
        canonicalProviderId: "gpt-4-turbo",
        legacyAliases: ["openai/gpt-4-turbo", "gpt-4-1106-preview", "gpt-4-0125-preview"],
        capabilities: {
          contextWindow: 128000,
          supportsStreaming: true,
          supportsTools: true,
          supportsVision: true,
          supportsJson: true,
          supportsCode: true,
          maxTokensOut: 4096,
          supportsSystemPrompt: true,
        },
        costPerTokenIn: 0.00001,
        costPerTokenOut: 0.00003,
        availability: "unknown",
      },
      {
        id: "gpt-4",
        providerId: "openai",
        displayName: "GPT-4",
        canonicalProviderId: "gpt-4",
        legacyAliases: ["openai/gpt-4"],
        capabilities: {
          contextWindow: 8192,
          supportsStreaming: true,
          supportsTools: true,
          supportsVision: false,
          supportsJson: true,
          supportsCode: true,
          maxTokensOut: 4096,
          supportsSystemPrompt: true,
        },
        costPerTokenIn: 0.00003,
        costPerTokenOut: 0.00006,
        availability: "unknown",
      },
      {
        id: "gpt-3.5-turbo",
        providerId: "openai",
        displayName: "GPT-3.5 Turbo",
        canonicalProviderId: "gpt-3.5-turbo",
        legacyAliases: ["openai/gpt-3.5-turbo"],
        capabilities: {
          contextWindow: 4096,
          supportsStreaming: true,
          supportsTools: true,
          supportsVision: false,
          supportsJson: true,
          supportsCode: true,
          maxTokensOut: 4096,
          supportsSystemPrompt: true,
        },
        costPerTokenIn: 0.0000015,
        costPerTokenOut: 0.000002,
        availability: "unknown",
      },
      {
        id: "gpt-3.5-turbo-16k",
        providerId: "openai",
        displayName: "GPT-3.5 Turbo 16K",
        canonicalProviderId: "gpt-3.5-turbo-16k",
        legacyAliases: ["openai/gpt-3.5-turbo-16k"],
        capabilities: {
          contextWindow: 16384,
          supportsStreaming: true,
          supportsTools: true,
          supportsVision: false,
          supportsJson: true,
          supportsCode: true,
          maxTokensOut: 4096,
          supportsSystemPrompt: true,
        },
        costPerTokenIn: 0.000003,
        costPerTokenOut: 0.000004,
        availability: "blocked",
        availabilityReason: "Model may be retired; verify at runtime",
      },
      {
        id: "gpt-3.5-turbo-instruct",
        providerId: "openai",
        displayName: "GPT-3.5 Turbo Instruct",
        canonicalProviderId: "gpt-3.5-turbo-instruct",
        legacyAliases: ["openai/gpt-3.5-turbo-instruct"],
        capabilities: {
          contextWindow: 4096,
          supportsStreaming: true,
          supportsTools: false,
          supportsVision: false,
          supportsJson: false,
          supportsCode: true,
          maxTokensOut: 4096,
          supportsSystemPrompt: true,
          supportsBatch: true,
        },
        costPerTokenIn: 0.0000015,
        costPerTokenOut: 0.000002,
        availability: "blocked",
        availabilityReason: "Instruct models may be retired; verify at runtime",
      },
    ];
  }

  async chat(request: ChatRequest): Promise<ChatResponse> {
    const start = Date.now();
    if (!this.apiKey) throw new Error("OpenAI API key not configured");

    const body: Record<string, unknown> = {
      model: request.model,
      messages: request.messages.map((m) => ({
        role: m.role,
        content: m.content,
        ...(m.toolCalls ? { tool_calls: m.toolCalls } : {}),
        ...(m.toolCallId ? { tool_call_id: m.toolCallId } : {}),
        ...(m.name ? { name: m.name } : {}),
      })),
      temperature: request.temperature ?? 0.7,
      max_tokens: request.maxTokens ?? 4096,
    };
    if (request.tools && request.tools.length > 0) {
      body.tools = request.tools;
    }

    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenAI API error ${response.status}: ${errText}`);
    }

    const data = await response.json() as Record<string, unknown>;
    const choice = (data.choices as Record<string, unknown>[])?.[0];
    const msg = choice?.message as Record<string, unknown> | undefined;
    const usage = data.usage as Record<string, unknown> | undefined;

    return {
      content: (msg?.content as string) || "",
      toolCalls: msg?.tool_calls as ToolCallResult[] | undefined,
      usage: {
        tokensIn: (usage?.prompt_tokens as number) || 0,
        tokensOut: (usage?.completion_tokens as number) || 0,
        tokensCached: 0,
      },
      model: request.model,
      provider: "openai",
      durationMs: Date.now() - start,
      isFallback: false,
    };
  }

  async *stream(request: ChatRequest): AsyncIterable<StreamChunk> {
    if (!this.apiKey) throw new Error("OpenAI API key not configured");

    const body: Record<string, unknown> = {
      model: request.model,
      messages: request.messages.map((m) => ({ role: m.role, content: m.content })),
      temperature: request.temperature ?? 0.7,
      max_tokens: request.maxTokens ?? 4096,
      stream: true,
    };

    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      yield { type: "error", data: `OpenAI stream error ${response.status}` };
      return;
    }

    const reader = response.body?.getReader();
    if (!reader) { yield { type: "error", data: "No response body" }; return; }
    const decoder = new TextDecoder();

    try {
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || !trimmed.startsWith("data: ")) continue;
          const payload = trimmed.slice(6);
          if (payload === "[DONE]") { yield { type: "done", data: null }; return; }
          try {
            const parsed = JSON.parse(payload) as Record<string, unknown>;
            const delta = ((parsed.choices as Record<string, unknown>[])?.[0]?.delta as Record<string, unknown>);
            if (delta?.content) yield { type: "token", data: delta.content };
            if (delta?.tool_calls) yield { type: "tool_call", data: delta.tool_calls };
          } catch { /* skip malformed chunks */ }
        }
      }
    } finally {
      reader.releaseLock();
    }
    yield { type: "done", data: null };
  }

  async healthCheck(): Promise<ProviderHealthResult> {
    if (!this.isConfigured) return { provider: "openai", configured: false, reachable: false, error: "API key not set" };
    const start = Date.now();
    try {
      const resp = await fetch(`${this.baseUrl}/models`, {
        headers: { Authorization: `Bearer ${this.apiKey}` },
        signal: AbortSignal.timeout(10000),
      });
      return {
        provider: "openai",
        configured: true,
        reachable: resp.ok,
        error: resp.ok ? undefined : `HTTP ${resp.status}`,
        responseTimeMs: Date.now() - start,
      };
    } catch (e) {
      return { provider: "openai", configured: true, reachable: false, error: String(e), responseTimeMs: Date.now() - start };
    }
  }

  estimateCost(modelId: string, tokensIn: number, tokensOut: number): number {
    const model = this.getModel(modelId);
    if (!model) return 0;
    return tokensIn * model.costPerTokenIn + tokensOut * model.costPerTokenOut;
  }
}

// ─── OpenRouter Provider ──────────────────────────────────

export class OpenRouterProvider extends ModelProvider {
  readonly id = "openrouter";
  readonly name = "OpenRouter";
  private baseUrl: string;

  constructor(apiKey?: string, baseUrl?: string) {
    super(apiKey);
    this.baseUrl = baseUrl || "https://openrouter.ai/api/v1";
  }

  listModels(): ModelInfo[] {
    return [
      {
        id: "openrouter/auto",
        providerId: "openrouter",
        displayName: "OpenRouter Auto",
        canonicalProviderId: "openrouter/auto",
        legacyAliases: [],
        capabilities: {
          contextWindow: 128000,
          supportsStreaming: true,
          supportsTools: true,
          supportsVision: true,
          supportsJson: true,
          supportsCode: true,
        },
        costPerTokenIn: 0.00001,
        costPerTokenOut: 0.00003,
        availability: "unknown",
        availabilityReason: "Auto router selects dynamically; actual capabilities depend on routed model",
      },
      {
        id: "mancer/weaver",
        providerId: "openrouter",
        displayName: "Mancer Weaver",
        canonicalProviderId: "mancer/weaver",
        legacyAliases: [],
        capabilities: {
          contextWindow: 8192,
          supportsStreaming: true,
          supportsTools: false,
          supportsVision: false,
          supportsJson: false,
          supportsCode: true,
        },
        costPerTokenIn: 0.000001,
        costPerTokenOut: 0.000001,
        availability: "blocked",
        availabilityReason: "Mancer provider may no longer be available on OpenRouter",
      },
      {
        id: "undi95/remm-slerp-13b",
        providerId: "openrouter",
        displayName: "ReMM SLERP 13B (Undi95)",
        canonicalProviderId: "undi95/remm-slerp-13b",
        legacyAliases: [],
        capabilities: {
          contextWindow: 4096,
          supportsStreaming: true,
          supportsTools: false,
          supportsVision: false,
          supportsJson: false,
          supportsCode: true,
        },
        costPerTokenIn: 0.0000004,
        costPerTokenOut: 0.0000004,
        availability: "blocked",
        availabilityReason: "Model may be delisted from OpenRouter; verify at runtime",
      },
      {
        id: "gryphe/mythomax-13b",
        providerId: "openrouter",
        displayName: "MythoMax 13B (Gryphe)",
        canonicalProviderId: "gryphe/mythomax-13b",
        legacyAliases: [],
        capabilities: {
          contextWindow: 4096,
          supportsStreaming: true,
          supportsTools: false,
          supportsVision: false,
          supportsJson: false,
          supportsCode: true,
        },
        costPerTokenIn: 0.0000006,
        costPerTokenOut: 0.0000006,
        availability: "blocked",
        availabilityReason: "Model may be delisted from OpenRouter; verify at runtime",
      },
    ];
  }

  async chat(request: ChatRequest): Promise<ChatResponse> {
    const start = Date.now();
    if (!this.apiKey) throw new Error("OpenRouter API key not configured");

    const body: Record<string, unknown> = {
      model: request.model,
      messages: request.messages.map((m) => ({ role: m.role, content: m.content })),
      temperature: request.temperature ?? 0.7,
      max_tokens: request.maxTokens ?? 4096,
    };

    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.apiKey}`,
        "HTTP-Referer": "https://agent-platform.dev",
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenRouter API error ${response.status}: ${errText}`);
    }

    const data = await response.json() as Record<string, unknown>;
    const choice = (data.choices as Record<string, unknown>[])?.[0];
    const msg = choice?.message as Record<string, unknown> | undefined;
    const usage = data.usage as Record<string, unknown> | undefined;

    return {
      content: (msg?.content as string) || "",
      usage: {
        tokensIn: (usage?.prompt_tokens as number) || 0,
        tokensOut: (usage?.completion_tokens as number) || 0,
        tokensCached: 0,
      },
      model: request.model,
      provider: "openrouter",
      durationMs: Date.now() - start,
      isFallback: false,
    };
  }

  async *stream(request: ChatRequest): AsyncIterable<StreamChunk> {
    if (!this.apiKey) throw new Error("OpenRouter API key not configured");

    const body = {
      model: request.model,
      messages: request.messages.map((m) => ({ role: m.role, content: m.content })),
      temperature: request.temperature ?? 0.7,
      max_tokens: request.maxTokens ?? 4096,
      stream: true,
    };

    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) { yield { type: "error", data: `OpenRouter stream error ${response.status}` }; return; }

    const reader = response.body?.getReader();
    if (!reader) { yield { type: "error", data: "No response body" }; return; }
    const decoder = new TextDecoder();

    try {
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || !trimmed.startsWith("data: ")) continue;
          const payload = trimmed.slice(6);
          if (payload === "[DONE]") { yield { type: "done", data: null }; return; }
          try {
            const parsed = JSON.parse(payload) as Record<string, unknown>;
            const delta = ((parsed.choices as Record<string, unknown>[])?.[0]?.delta as Record<string, unknown>);
            if (delta?.content) yield { type: "token", data: delta.content };
          } catch { /* skip */ }
        }
      }
    } finally {
      reader.releaseLock();
    }
    yield { type: "done", data: null };
  }

  async healthCheck(): Promise<ProviderHealthResult> {
    if (!this.isConfigured) return { provider: "openrouter", configured: false, reachable: false, error: "API key not set" };
    const start = Date.now();
    try {
      const resp = await fetch(`${this.baseUrl}/models`, {
        headers: { Authorization: `Bearer ${this.apiKey}` },
        signal: AbortSignal.timeout(10000),
      });
      return { provider: "openrouter", configured: true, reachable: resp.ok, error: resp.ok ? undefined : `HTTP ${resp.status}`, responseTimeMs: Date.now() - start };
    } catch (e) {
      return { provider: "openrouter", configured: true, reachable: false, error: String(e), responseTimeMs: Date.now() - start };
    }
  }

  estimateCost(modelId: string, tokensIn: number, tokensOut: number): number {
    const model = this.getModel(modelId);
    if (!model) return 0;
    return tokensIn * model.costPerTokenIn + tokensOut * model.costPerTokenOut;
  }
}

// ─── Mistral Provider ─────────────────────────────────────

export class MistralProvider extends ModelProvider {
  readonly id = "mistral";
  readonly name = "Mistral";
  private baseUrl: string;

  constructor(apiKey?: string, baseUrl?: string) {
    super(apiKey);
    this.baseUrl = baseUrl || "https://api.mistral.ai/v1";
  }

  listModels(): ModelInfo[] {
    return [
      {
        id: "mistral-large-latest",
        providerId: "mistral",
        displayName: "Mistral Large",
        canonicalProviderId: "mistral-large-latest",
        legacyAliases: ["mistralai/mistral-large", "mistral-large"],
        capabilities: {
          contextWindow: 128000,
          supportsStreaming: true,
          supportsTools: true,
          supportsVision: false,
          supportsJson: true,
          supportsCode: true,
          maxTokensOut: 4096,
          supportsSystemPrompt: true,
        },
        costPerTokenIn: 0.000004,
        costPerTokenOut: 0.000012,
        availability: "unknown",
      },
    ];
  }

  async chat(request: ChatRequest): Promise<ChatResponse> {
    const start = Date.now();
    if (!this.apiKey) throw new Error("Mistral API key not configured");

    const body: Record<string, unknown> = {
      model: request.model,
      messages: request.messages.map((m) => ({ role: m.role, content: m.content })),
      temperature: request.temperature ?? 0.7,
      max_tokens: request.maxTokens ?? 4096,
    };

    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${this.apiKey}` },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Mistral API error ${response.status}: ${errText}`);
    }

    const data = await response.json() as Record<string, unknown>;
    const choice = (data.choices as Record<string, unknown>[])?.[0];
    const msg = choice?.message as Record<string, unknown> | undefined;
    const usage = data.usage as Record<string, unknown> | undefined;

    return {
      content: (msg?.content as string) || "",
      usage: {
        tokensIn: (usage?.prompt_tokens as number) || 0,
        tokensOut: (usage?.completion_tokens as number) || 0,
        tokensCached: 0,
      },
      model: request.model,
      provider: "mistral",
      durationMs: Date.now() - start,
      isFallback: false,
    };
  }

  async *stream(request: ChatRequest): AsyncIterable<StreamChunk> {
    if (!this.apiKey) throw new Error("Mistral API key not configured");

    const body = {
      model: request.model,
      messages: request.messages.map((m) => ({ role: m.role, content: m.content })),
      temperature: request.temperature ?? 0.7,
      max_tokens: request.maxTokens ?? 4096,
      stream: true,
    };

    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${this.apiKey}` },
      body: JSON.stringify(body),
    });

    if (!response.ok) { yield { type: "error", data: `Mistral stream error ${response.status}` }; return; }

    const reader = response.body?.getReader();
    if (!reader) { yield { type: "error", data: "No response body" }; return; }
    const decoder = new TextDecoder();

    try {
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || !trimmed.startsWith("data: ")) continue;
          const payload = trimmed.slice(6);
          if (payload === "[DONE]") { yield { type: "done", data: null }; return; }
          try {
            const parsed = JSON.parse(payload) as Record<string, unknown>;
            const delta = ((parsed.choices as Record<string, unknown>[])?.[0]?.delta as Record<string, unknown>);
            if (delta?.content) yield { type: "token", data: delta.content };
          } catch { /* skip */ }
        }
      }
    } finally {
      reader.releaseLock();
    }
    yield { type: "done", data: null };
  }

  async healthCheck(): Promise<ProviderHealthResult> {
    if (!this.isConfigured) return { provider: "mistral", configured: false, reachable: false, error: "API key not set" };
    const start = Date.now();
    try {
      const resp = await fetch(`${this.baseUrl}/models`, {
        headers: { Authorization: `Bearer ${this.apiKey}` },
        signal: AbortSignal.timeout(10000),
      });
      return { provider: "mistral", configured: true, reachable: resp.ok, error: resp.ok ? undefined : `HTTP ${resp.status}`, responseTimeMs: Date.now() - start };
    } catch (e) {
      return { provider: "mistral", configured: true, reachable: false, error: String(e), responseTimeMs: Date.now() - start };
    }
  }

  estimateCost(modelId: string, tokensIn: number, tokensOut: number): number {
    const model = this.getModel(modelId);
    if (!model) return 0;
    return tokensIn * model.costPerTokenIn + tokensOut * model.costPerTokenOut;
  }
}

// ─── Provider Registry ────────────────────────────────────

export class ProviderRegistry {
  private providers = new Map<string, ModelProvider>();

  register(provider: ModelProvider): void {
    this.providers.set(provider.id, provider);
  }

  get(providerId: string): ModelProvider | undefined {
    return this.providers.get(providerId);
  }

  getAll(): ModelProvider[] {
    return Array.from(this.providers.values());
  }

  listAll(): Array<{ id: string; name: string; configured: boolean }> {
    return this.getAll().map((p) => ({ id: p.id, name: p.name, configured: p.isConfigured }));
  }
}

// ─── Model Registry ───────────────────────────────────────

export class ModelRegistry {
  constructor(private providerRegistry: ProviderRegistry) {}

  getAllModels(): ModelInfo[] {
    return this.providerRegistry.getAll().flatMap((p) => p.listModels());
  }

  findModel(modelId: string): { model: ModelInfo; provider: ModelProvider } | undefined {
    for (const provider of this.providerRegistry.getAll()) {
      const model = provider.getModel(modelId);
      if (model) return { model, provider };
    }
    return undefined;
  }

  getModelsByProvider(providerId: string): ModelInfo[] {
    return this.providerRegistry.get(providerId)?.listModels() ?? [];
  }
}

// ─── Model Router ─────────────────────────────────────────

export type RoutingStrategy = "fixed" | "auto" | "cost" | "latency" | "capability" | "fallback" | "task-type";

export class ModelRouter {
  private fallbackChain: string[] = [];

  constructor(private modelRegistry: ModelRegistry) {}

  setFallbackChain(models: string[]): void {
    this.fallbackChain = models;
  }

  resolve(
    preferredModel: string,
    strategy: RoutingStrategy = "fixed",
    taskType?: string
  ): { model: ModelInfo; provider: ModelProvider } | undefined {
    const direct = this.modelRegistry.findModel(preferredModel);
    if (!direct) return undefined;

    switch (strategy) {
      case "fixed":
        return direct;
      case "capability": {
        if (taskType === "vision") {
          const visionModel = this.modelRegistry.getAllModels().find((m) => m.capabilities.supportsVision && m.availability !== "blocked");
          if (visionModel) return this.modelRegistry.findModel(visionModel.id) ?? direct;
        }
        if (taskType === "coding") {
          const codeModel = this.modelRegistry.getAllModels().find((m) => m.capabilities.supportsCode && m.capabilities.supportsTools && m.availability !== "blocked");
          if (codeModel) return this.modelRegistry.findModel(codeModel.id) ?? direct;
        }
        return direct;
      }
      case "cost": {
        const sorted = this.modelRegistry.getAllModels()
          .filter((m) => m.availability !== "blocked")
          .sort((a, b) => (a.costPerTokenIn + a.costPerTokenOut) - (b.costPerTokenIn + b.costPerTokenOut));
        if (sorted.length > 0) return this.modelRegistry.findModel(sorted[0].id) ?? direct;
        return direct;
      }
      case "fallback":
        return direct;
      default:
        return direct;
    }
  }

  async resolveWithFallback(
    preferredModel: string,
    strategy: RoutingStrategy = "fixed",
    taskType?: string
  ): Promise<{ model: ModelInfo; provider: ModelProvider; isFallback: boolean; fallbackFrom?: string }> {
    const resolved = this.resolve(preferredModel, strategy, taskType);
    if (resolved) return { ...resolved, isFallback: false };
    // Try fallback chain
    for (const fallbackId of this.fallbackChain) {
      const fb = this.modelRegistry.findModel(fallbackId);
      if (fb) return { ...fb, isFallback: true, fallbackFrom: preferredModel };
    }
    throw new Error(`No model available for ${preferredModel} and no fallbacks configured`);
  }
}

// ─── Platform Bootstrap ───────────────────────────────────

export function createProviderRegistry(): ProviderRegistry {
  const registry = new ProviderRegistry();
  registry.register(new OpenAIProvider(process.env.OPENAI_API_KEY));
  registry.register(new OpenRouterProvider(process.env.OPENROUTER_API_KEY));
  registry.register(new MistralProvider(process.env.MISTRAL_API_KEY));
  return registry;
}

export function createModelGateway() {
  const providerRegistry = createProviderRegistry();
  const modelRegistry = new ModelRegistry(providerRegistry);
  const modelRouter = new ModelRouter(modelRegistry);
  modelRouter.setFallbackChain(["gpt-4-turbo", "gpt-3.5-turbo", "mistral-large-latest"]);
  return { providerRegistry, modelRegistry, modelRouter };
}

// Standalone creation without circular ref
export function createModelGatewaySafe() {
  const providerRegistry = createProviderRegistry();
  const modelRegistry = new ModelRegistry(providerRegistry);
  const modelRouter = new ModelRouter(modelRegistry);
  modelRouter.setFallbackChain(["gpt-4-turbo", "gpt-3.5-turbo", "mistral-large-latest"]);
  return { providerRegistry, modelRegistry, modelRouter };
}
