import { pgTable, text, timestamp, integer, jsonb, boolean, uuid, varchar, decimal } from "drizzle-orm/pg-core";

// ─── Users ────────────────────────────────────────────────
export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Workspaces ───────────────────────────────────────────
export const workspaces = pgTable("workspaces", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").references(() => users.id),
  name: varchar("name", { length: 255 }).notNull(),
  rootPath: text("root_path").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Provider Configs ─────────────────────────────────────
export const providerConfigs = pgTable("provider_configs", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").references(() => users.id),
  provider: varchar("provider", { length: 50 }).notNull(), // openai, openrouter, mistral
  apiKeyEnvVar: varchar("api_key_env_var", { length: 100 }).notNull(), // e.g. OPENAI_API_KEY
  baseUrl: text("base_url"),
  isConfigured: boolean("is_configured").default(false).notNull(),
  config: jsonb("config").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Sessions ─────────────────────────────────────────────
export const sessions = pgTable("sessions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").references(() => users.id),
  workspaceId: uuid("workspace_id").references(() => workspaces.id),
  title: varchar("title", { length: 500 }),
  modelId: varchar("model_id", { length: 100 }).notNull(),
  providerId: varchar("provider_id", { length: 50 }).notNull(),
  routingStrategy: varchar("routing_strategy", { length: 30 }).default("fixed"),
  status: varchar("status", { length: 20 }).default("active").notNull(), // active, completed, error
  metadata: jsonb("metadata").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Messages ─────────────────────────────────────────────
export const messages = pgTable("messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id").references(() => sessions.id).notNull(),
  role: varchar("role", { length: 20 }).notNull(), // user, assistant, system, tool
  content: text("content").notNull(),
  modelId: varchar("model_id", { length: 100 }),
  providerId: varchar("provider_id", { length: 50 }),
  toolCalls: jsonb("tool_calls").$type<unknown[]>(),
  toolCallId: varchar("tool_call_id", { length: 100 }),
  toolName: varchar("tool_name", { length: 100 }),
  tokensIn: integer("tokens_in").default(0),
  tokensOut: integer("tokens_out").default(0),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Tasks ────────────────────────────────────────────────
export const tasks = pgTable("tasks", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id").references(() => sessions.id).notNull(),
  parentTaskId: uuid("parent_task_id"),
  agentType: varchar("agent_type", { length: 50 }).default("coder"), // planner, coder, reviewer, tester, debugger
  description: text("description").notNull(),
  status: varchar("status", { length: 20 }).default("pending").notNull(), // pending, running, completed, failed, cancelled
  result: text("result"),
  plan: jsonb("plan").$type<unknown[]>(),
  currentStep: integer("current_step").default(0),
  totalSteps: integer("total_steps").default(0),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().default({}),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Agent Instances ──────────────────────────────────────
export const agents = pgTable("agents", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id").references(() => sessions.id).notNull(),
  taskId: uuid("task_id").references(() => tasks.id),
  agentType: varchar("agent_type", { length: 50 }).notNull(),
  modelId: varchar("model_id", { length: 100 }).notNull(),
  providerId: varchar("provider_id", { length: 50 }).notNull(),
  status: varchar("status", { length: 20 }).default("idle").notNull(), // idle, running, waiting, error
  currentTool: varchar("current_tool", { length: 100 }),
  currentFile: text("current_file"),
  tokensUsed: integer("tokens_used").default(0),
  estimatedCost: decimal("estimated_cost", { precision: 10, scale: 6 }).default("0"),
  elapsedTimeMs: integer("elapsed_time_ms").default(0),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Tool Calls ──────────────────────────────────────────
export const toolCalls = pgTable("tool_calls", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id").references(() => sessions.id).notNull(),
  taskId: uuid("task_id").references(() => tasks.id),
  agentId: uuid("agent_id").references(() => agents.id),
  toolName: varchar("tool_name", { length: 100 }).notNull(),
  input: jsonb("input").$type<Record<string, unknown>>().notNull(),
  output: jsonb("output").$type<unknown>(),
  status: varchar("status", { length: 20 }).default("pending").notNull(), // pending, running, completed, failed, denied
  exitCode: integer("exit_code"),
  durationMs: integer("duration_ms"),
  error: text("error"),
  isAuthorized: boolean("is_authorized").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Model Requests ───────────────────────────────────────
export const modelRequests = pgTable("model_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id").references(() => sessions.id),
  taskId: uuid("task_id").references(() => tasks.id),
  agentId: uuid("agent_id").references(() => agents.id),
  providerId: varchar("provider_id", { length: 50 }).notNull(),
  modelId: varchar("model_id", { length: 100 }).notNull(),
  requestType: varchar("request_type", { length: 20 }).default("chat").notNull(), // chat, stream, generate
  tokensIn: integer("tokens_in").default(0),
  tokensOut: integer("tokens_out").default(0),
  tokensCached: integer("tokens_cached").default(0),
  estimatedCost: decimal("estimated_cost", { precision: 10, scale: 6 }).default("0"),
  actualCost: decimal("actual_cost", { precision: 10, scale: 6 }),
  durationMs: integer("duration_ms"),
  isFallback: boolean("is_fallback").default(false).notNull(),
  fallbackFromModel: varchar("fallback_from_model", { length: 100 }),
  status: varchar("status", { length: 20 }).default("completed").notNull(), // completed, failed, timeout
  error: text("error"),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Model Usage (aggregated) ────────────────────────────
export const modelUsage = pgTable("model_usage", {
  id: uuid("id").defaultRandom().primaryKey(),
  providerId: varchar("provider_id", { length: 50 }).notNull(),
  modelId: varchar("model_id", { length: 100 }).notNull(),
  date: timestamp("date").notNull(),
  totalRequests: integer("total_requests").default(0).notNull(),
  totalTokensIn: integer("total_tokens_in").default(0).notNull(),
  totalTokensOut: integer("total_tokens_out").default(0).notNull(),
  totalTokensCached: integer("total_tokens_cached").default(0).notNull(),
  totalCost: decimal("total_cost", { precision: 12, scale: 6 }).default("0").notNull(),
  totalDurationMs: integer("total_duration_ms").default(0).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Checkpoints ──────────────────────────────────────────
export const checkpoints = pgTable("checkpoints", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id").references(() => sessions.id).notNull(),
  taskId: uuid("task_id").references(() => tasks.id),
  label: varchar("label", { length: 255 }),
  gitCommitHash: varchar("git_commit_hash", { length: 40 }),
  gitBranch: varchar("git_branch", { length: 255 }),
  filesChanged: jsonb("files_changed").$type<string[]>().default([]),
  diff: text("diff"),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Audit Events ─────────────────────────────────────────
export const auditEvents = pgTable("audit_events", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id"),
  taskId: uuid("task_id"),
  agentId: uuid("agent_id"),
  userId: uuid("user_id"),
  eventType: varchar("event_type", { length: 50 }).notNull(), // tool_call, model_request, checkpoint, security, session, task
  action: varchar("action", { length: 100 }).notNull(),
  resource: varchar("resource", { length: 255 }),
  details: jsonb("details").$type<Record<string, unknown>>().default({}),
  severity: varchar("severity", { length: 10 }).default("info").notNull(), // info, warn, error, critical
  ipAddress: varchar("ip_address", { length: 45 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Repositories ─────────────────────────────────────────
export const repositories = pgTable("repositories", {
  id: uuid("id").defaultRandom().primaryKey(),
  workspaceId: uuid("workspace_id").references(() => workspaces.id).notNull(),
  path: text("path").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  language: varchar("language", { length: 50 }),
  framework: varchar("framework", { length: 50 }),
  isIndexed: boolean("is_indexed").default(false).notNull(),
  lastIndexAt: timestamp("last_index_at"),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── File Index ───────────────────────────────────────────
export const fileIndex = pgTable("file_index", {
  id: uuid("id").defaultRandom().primaryKey(),
  repositoryId: uuid("repository_id").references(() => repositories.id).notNull(),
  filePath: text("file_path").notNull(),
  fileName: varchar("file_name", { length: 255 }).notNull(),
  extension: varchar("extension", { length: 20 }),
  directory: text("directory"),
  fileSize: integer("file_size"),
  symbols: jsonb("symbols").$type<unknown[]>().default([]),
  imports: jsonb("imports").$type<string[]>().default([]),
  exports: jsonb("exports").$type<string[]>().default([]),
  lastModified: timestamp("last_modified"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
