"use client";

import Link from "next/link";
import { Code, X, MessageCircle, Sparkles } from "lucide-react";

const footerLinks = [
  {
    title: "Product",
    links: ["Models", "Agents", "API", "Pricing"],
  },
  {
    title: "Developers",
    links: ["Documentation", "SDK", "GitHub", "Status"],
  },
  {
    title: "Company",
    links: ["About", "Blog", "Careers", "Contact"],
  },
  {
    title: "Legal",
    links: ["Privacy", "Terms", "Cookie Policy"],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-white/5 bg-slate-950 px-6 pt-16 pb-8">
      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-5">
          <div className="col-span-2 md:col-span-1">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold">
                Melodie<span className="text-gradient">GPT</span>
              </span>
            </Link>
            <p className="mt-4 text-sm text-slate-400">
              The decentralized AI chat interface for every frontier model.
            </p>
            <div className="mt-5 flex items-center gap-4">
              <a
                href="#"
                className="text-slate-400 transition-colors hover:text-white"
                aria-label="X"
              >
                <X className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="text-slate-400 transition-colors hover:text-white"
                aria-label="GitHub"
              >
                <Code className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="text-slate-400 transition-colors hover:text-white"
                aria-label="Discord"
              >
                <MessageCircle className="h-5 w-5" />
              </a>
            </div>
          </div>

          {footerLinks.map((group) => (
            <div key={group.title}>
              <h4 className="text-sm font-semibold text-white">{group.title}</h4>
              <ul className="mt-4 space-y-3">
                {group.links.map((link) => (
                  <li key={link}>
                    <Link
                      href="#"
                      className="text-sm text-slate-400 transition-colors hover:text-white"
                    >
                      {link}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 flex flex-col items-center justify-between gap-4 border-t border-white/5 pt-8 md:flex-row">
          <p className="text-xs text-slate-500">
            © {new Date().getFullYear()} MelodieGPT. All rights reserved.
          </p>
          <p className="text-xs text-slate-500">
            Powered by Next.js, Tailwind CSS, and decentralized inference.
          </p>
        </div>
      </div>
    </footer>
  );
}
