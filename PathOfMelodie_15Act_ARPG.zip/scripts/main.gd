
extends Node2D

var player:Soulbearer
var spawn_timer:=0.0
var elapsed:=0.0
var font:=ThemeDB.fallback_font
var act_data

func _ready():
    randomize()
    RenderingServer.set_default_clear_color(Color("#070711"))
    player=preload("res://scripts/player.gd").new()
    player.position=Vector2(640,410)
    add_child(player)
    player.changed.connect(queue_redraw)
    act_data=Acts.get_act(player.act)
    for i in 12: spawn_enemy()
    queue_redraw()

func _process(delta):
    elapsed+=delta
    spawn_timer-=delta
    if spawn_timer<=0:
        spawn_timer=1.0
        spawn_enemy()
    # Acts are data-driven; prototype advances after enough kills.
    if player.kills>0 and player.kills%25==0:
        var new_act=min(15,1+int(player.kills/25))
        if new_act!=player.act:
            player.act=new_act
            act_data=Acts.get_act(new_act)
            player.hp=player.max_hp
            player.mana=player.max_mana
            spawn_boss()
    queue_redraw()

func spawn_enemy():
    var e=preload("res://scripts/enemy.gd").new()
    var side=randi()%4
    if side==0:e.position=Vector2(randf_range(70,1210),125)
    elif side==1:e.position=Vector2(randf_range(70,1210),640)
    elif side==2:e.position=Vector2(65,randf_range(140,630))
    else:e.position=Vector2(1215,randf_range(140,630))
    e.setup(player,min(10,1+int(player.level/8)))
    add_child(e)

func spawn_boss():
    var b=preload("res://scripts/enemy.gd").new()
    b.position=Vector2(640,180)
    b.setup(player,10,true)
    add_child(b)

func _draw():
    draw_rect(Rect2(0,0,1280,720),Color("#080812"))
    draw_rect(Rect2(0,100,640,620),Color("#170a16"))
    draw_rect(Rect2(640,100,640,620),Color("#0d1c2b"))

    # Isometric-inspired diamond tiles
    for y in range(130,650,64):
        for x in range(35,1280,96):
            var p=Vector2(x,y)
            var pts=PackedVector2Array([p+Vector2(48,0),p+Vector2(96,32),p+Vector2(48,64),p])
            var c=Color("#241326") if x<640 else Color("#183143")
            draw_colored_polygon(pts,c)
            draw_polyline(PackedVector2Array([pts[0],pts[1],pts[2],pts[3],pts[0]]),Color("#38223b") if x<640 else Color("#264a5a"),1)

    draw_rect(Rect2(20,18,1240,74),Color("#090a14e8"))
    draw_line(Vector2(20,92),Vector2(1260,92),Color("#e7b55b"),2)
    draw_string(font,Vector2(42,51),"PATH OF MELODIE",HORIZONTAL_ALIGNMENT_LEFT,-1,30,Color("#f4d18d"))
    draw_string(font,Vector2(42,76),"MAAKARAS PROTOCOLS • PHOENIX ASCENSION",HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color("#a7e8ff"))
    draw_string(font,Vector2(820,48),"ACT %02d • %s" % [player.act,act_data.title],HORIZONTAL_ALIGNMENT_LEFT,-1,17,Color("#ffe8b1"))
    draw_string(font,Vector2(820,71),"REGION: %s • BOSS: %s" % [act_data.region,act_data.boss],HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color("#d3d9e6"))

    draw_rect(Rect2(20,650,1240,52),Color("#090a12ee"))
    var s="LV %d   HP %.0f/%.0f   MP %.0f/%.0f   XP %d/%d   GOLD %d   KARMA %d   MA %.2f   ASC %d" % [player.level,player.hp,player.max_hp,player.mana,player.max_mana,player.xp,player.xp_next(),player.gold,player.karma,player.ma,player.ascension]
    draw_string(font,Vector2(35,682),s,HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color("#f3ead8"))
    draw_string(font,Vector2(870,682),"WASD • LMB • 1-4 SKILLS • Q GUARDIAN • SPACE ASCEND",HORIZONTAL_ALIGNMENT_LEFT,-1,11,Color("#bfe1f2"))

    draw_string(font,Vector2(45,125),"NETHERVALE",HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("#ff8d77"))
    draw_string(font,Vector2(1040,125),"AURELION",HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("#9ce8ff"))
