
extends CharacterBody2D
class_name Soulbearer

signal changed

var level := 1
var xp := 0
var hp := 180.0
var max_hp := 180.0
var mana := 80.0
var max_mana := 80.0
var power := 24.0
var armor := 8.0
var speed := 260.0
var karma := 0
var ma := 0.0
var ascension := 0
var act := 1
var kills := 0
var gold := 0
var cooldown := 0.0
var guardian_cd := 0.0
var skill_cd := [0.0,0.0,0.0,0.0]

func _physics_process(delta):
    var v=Input.get_vector("move_left","move_right","move_up","move_down")
    velocity=v*speed
    move_and_slide()
    global_position.x=clamp(global_position.x,55.0,1225.0)
    global_position.y=clamp(global_position.y,125.0,640.0)
    cooldown=max(0.0,cooldown-delta)
    guardian_cd=max(0.0,guardian_cd-delta)
    for i in 4: skill_cd[i]=max(0.0,skill_cd[i]-delta)

    if Input.is_action_just_pressed("attack"): basic_attack()
    if Input.is_action_just_pressed("skill_1"): cast_skill(0,1.0)
    if Input.is_action_just_pressed("skill_2"): cast_skill(1,1.7)
    if Input.is_action_just_pressed("skill_3"): cast_skill(2,2.5)
    if Input.is_action_just_pressed("skill_4"): cast_skill(3,3.6)
    if Input.is_action_just_pressed("guardian"): guardian_pulse()
    if Input.is_action_just_pressed("ascend") and xp>=xp_next(): ascension += 1; power += 15; max_hp += 45; hp=max_hp; karma += 20; ma += 1; xp=0; changed.emit()
    queue_redraw()

func basic_attack():
    if cooldown>0: return
    cooldown=.18
    damage_area(power,90)

func cast_skill(slot:int,mult:float):
    if skill_cd[slot]>0 or mana<10: return
    skill_cd[slot]=[2.0,4.0,7.0,11.0][slot]
    mana-=10
    damage_area(power*mult,110+slot*25)
    changed.emit()

func guardian_pulse():
    if guardian_cd>0 or mana<20:return
    guardian_cd=6
    mana-=20
    damage_area(power*2.2,210)
    karma+=3
    changed.emit()

func damage_area(amount:float,radius:float):
    for e in get_tree().get_nodes_in_group("enemies"):
        if e.global_position.distance_to(global_position)<=radius:
            e.take_damage(amount)

func take_damage(amount:float):
    hp-=max(1.0,amount-armor*.35)
    if hp<=0:
        hp=max_hp
        global_position=Vector2(640,410)
        gold=max(0,gold-50)
        karma=max(0,karma-3)
    changed.emit()

func gain_xp(v:int):
    xp+=v
    kills+=1
    karma+=1
    ma+=.005
    gold+=10
    while xp>=xp_next():
        xp-=xp_next()
        level+=1
        max_hp+=14
        max_mana+=5
        power+=4
        armor+=1
        hp=max_hp
        mana=max_mana
    changed.emit()

func xp_next()->int:
    return 60+level*35

func _draw():
    draw_circle(Vector2.ZERO,21,Color("#dcecff"))
    draw_circle(Vector2(0,-7),10,Color("#fff0f4"))
    draw_colored_polygon(PackedVector2Array([Vector2(-17,8),Vector2(0,39),Vector2(17,8),Vector2(10,-4),Vector2(-10,-4)]),Color("#1b1830"))
    draw_arc(Vector2.ZERO,30,0,TAU,32,Color("#7ce6ff"),3)
    if ascension>0: draw_arc(Vector2.ZERO,42,0,TAU,32,Color("#ffbd55"),4)
