
extends CharacterBody2D
class_name Enemy

var hp=70.0
var speed=75.0
var damage=10.0
var target
var elite=false
var boss=false
var tint=Color("#a52e4d")

func setup(t,tier:int, is_boss:=false):
    target=t; boss=is_boss
    hp=70+tier*28
    speed=75+tier*4
    damage=10+tier*2
    if boss:
        hp*=12; speed*=.65; damage*=3; scale=Vector2(1.8,1.8); tint=Color("#b65cff")
    elif tier>=5:
        elite=true; scale=Vector2(1.35,1.35); tint=Color("#6e55ff")
    queue_redraw()

func _physics_process(delta):
    if not is_instance_valid(target):return
    var d=global_position.distance_to(target.global_position)
    if d>45:
        velocity=global_position.direction_to(target.global_position)*speed
        move_and_slide()
    else:
        target.take_damage(damage*delta)

func take_damage(v):
    hp-=v
    if hp<=0:
        if is_instance_valid(target):
            target.gain_xp(250 if boss else (35 if elite else 10))
        queue_free()

func _draw():
    draw_circle(Vector2.ZERO,20,Color("#100b18"))
    draw_circle(Vector2.ZERO,15,tint)
    draw_circle(Vector2(-5,-3),3,Color("#ffe58d"))
    draw_circle(Vector2(5,-3),3,Color("#ffe58d"))
    if boss: draw_arc(Vector2.ZERO,30,0,TAU,32,Color("#ff9e4d"),4)
