# Architecture

## Layers

### 1. Web Platform (Next.js App Router)
- Landing page, dashboard, wallet, marketplace, CLI terminal, agent IDE
- Server components fetch from PostgreSQL via Drizzle ORM
- API routes under `/api/*`

### 2. Agent Core (`src/agent/`)
- `types.ts` — shared domain types
- `providers/` — provider adapters, registry, router, verifier
- `tools/` — filesystem, shell, git, code search, test/build/lint tools
- `security/` — sandbox, command/path classification policies
- `engine/` — autonomous agent loop

### 3. CLI (`src/cli/index.ts` + `bin/agent`)
- Commander-based CLI
- Real-time health checks, model verification, tool listing, agent task execution

### 4. Database (PostgreSQL + Drizzle)
- Products, services, workflows, karma, orders
- Agent sessions, messages, tasks, tool calls, model requests, checkpoints, audit events

## Data Flow

```
User Task
    ↓
CLI / IDE
    ↓
ModelRouter → ProviderAdapter → Provider API
    ↓
LLM Response (+ tool_calls)
    ↓
ToolRegistry → WorkspaceSandbox authorization
    ↓
Tool execution (fs, shell, git, test/build/lint)
    ↓
Observation → next LLM turn
    ↓
Final report
```

## Security

- Path sandboxing: tools cannot read/write outside workspace
- Command classification: ALLOW / CONFIRM / DENY
- Denied commands include destructive operations (`rm -rf /`, `format`, `mkfs`, etc.)
- No API keys are logged or committed
