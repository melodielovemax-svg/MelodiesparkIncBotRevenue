import { execSync } from "child_process";
import { existsSync } from "fs";

function run(cmd: string) {
  console.log(`> ${cmd}`);
  execSync(cmd, { stdio: "inherit" });
}

function check(cmd: string, name: string) {
  try {
    const out = execSync(cmd, { encoding: "utf-8" }).trim();
    console.log(`✓ ${name}: ${out}`);
    return true;
  } catch (err) {
    console.error(`✗ ${name} not available`);
    return false;
  }
}

async function main() {
  console.log("Melodie Agent Bootstrap\n");

  const node = check("node --version", "Node.js");
  const npm = check("npm --version", "npm");
  if (!node || !npm) process.exit(1);

  if (!existsSync("node_modules")) {
    run("npm install");
  }

  run("npx drizzle-kit push");
  run("npm run test");
  run("npm run typecheck");
  run("npm run lint");
  run("npm run build");

  console.log("\nBootstrap complete. Run ./bin/agent doctor for health check.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
