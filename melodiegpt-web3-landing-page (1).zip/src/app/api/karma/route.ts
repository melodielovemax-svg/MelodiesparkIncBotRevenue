import { NextResponse } from "next/server";
import { db } from "@/db";
import { karmaTransactions } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const wallet = searchParams.get("wallet");
  if (!wallet) {
    return NextResponse.json({ success: false, error: "wallet required" }, { status: 400 });
  }

  try {
    const rows = await db
      .select()
      .from(karmaTransactions)
      .where(eq(karmaTransactions.walletAddress, wallet.toLowerCase()))
      .orderBy(desc(karmaTransactions.createdAt));

    const total = await db
      .select({ sum: sql<number>`COALESCE(SUM(${karmaTransactions.amount}), 0)` })
      .from(karmaTransactions)
      .where(eq(karmaTransactions.walletAddress, wallet.toLowerCase()));

    return NextResponse.json({
      success: true,
      data: rows,
      total: total[0]?.sum ?? 0,
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { walletAddress, type, amount, reason, workflowId, txHash } = body;

    if (!walletAddress || !type || amount == null || !reason) {
      return NextResponse.json({ success: false, error: "Missing fields" }, { status: 400 });
    }

    const [row] = await db
      .insert(karmaTransactions)
      .values({
        walletAddress: walletAddress.toLowerCase(),
        type,
        amount,
        reason,
        workflowId,
        txHash,
        metadata: body.metadata ?? {},
      })
      .returning();

    return NextResponse.json({ success: true, data: row });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
