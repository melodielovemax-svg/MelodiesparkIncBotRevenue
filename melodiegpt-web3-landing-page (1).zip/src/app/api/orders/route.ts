import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const wallet = searchParams.get("wallet");
  if (!wallet) {
    return NextResponse.json({ success: false, error: "wallet required" }, { status: 400 });
  }

  try {
    const rows = await db
      .select()
      .from(orders)
      .where(eq(orders.walletAddress, wallet.toLowerCase()))
      .orderBy(desc(orders.createdAt));
    return NextResponse.json({ success: true, data: rows });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { walletAddress, itemType, itemId, quantity, totalUsd, totalMa, txHash } = body;

    if (!walletAddress || !itemType || !itemId || !totalUsd || !totalMa) {
      return NextResponse.json({ success: false, error: "Missing fields" }, { status: 400 });
    }

    const [row] = await db
      .insert(orders)
      .values({
        walletAddress: walletAddress.toLowerCase(),
        itemType,
        itemId,
        quantity: quantity ?? 1,
        totalUsd,
        totalMa,
        txHash,
        status: txHash ? "paid" : "pending",
        metadata: body.metadata ?? {},
      })
      .returning();

    return NextResponse.json({ success: true, data: row });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
