import { NextResponse } from "next/server";
import { readdir, stat } from "fs/promises";
import { join } from "path";

interface TreeNode {
  name: string;
  path: string;
  type: "file" | "dir";
  children?: TreeNode[];
}

const IGNORE = ["node_modules", ".next", ".git", "dist", "coverage", ".turbo"];

async function buildTree(root: string, relativePath: string): Promise<TreeNode[]> {
  const fullPath = join(root, relativePath);
  const entries = await readdir(fullPath);
  const nodes: TreeNode[] = [];

  for (const name of entries) {
    if (IGNORE.includes(name)) continue;
    const entryPath = join(relativePath, name);
    const full = join(root, entryPath);
    const s = await stat(full);
    if (s.isDirectory()) {
      const children = await buildTree(root, entryPath);
      nodes.push({ name, path: entryPath, type: "dir", children });
    } else {
      nodes.push({ name, path: entryPath, type: "file" });
    }
  }

  return nodes.sort((a, b) => (a.type === "dir" ? -1 : 1) - (b.type === "dir" ? -1 : 1) || a.name.localeCompare(b.name));
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const path = searchParams.get("path") || ".";
    const tree = await buildTree(process.cwd(), path);
    return NextResponse.json({ success: true, data: tree });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
