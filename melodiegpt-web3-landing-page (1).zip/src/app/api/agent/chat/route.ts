import { NextResponse } from "next/server";
import { modelRouter } from "@/agent/providers/router";
import { toolRegistry } from "@/agent/tools/registry";
import { WorkspaceSandbox } from "@/agent/security/sandbox";
import type { Message } from "@/agent/types";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { messages, model = "openrouter/auto", workspace = process.cwd(), sessionId = "web" } = body;

    const response = await modelRouter.chat({
      model,
      messages: messages as Message[],
      tools: toolRegistry.schemas(),
    });

    let toolResults: Array<{ name: string; output: string; error?: string }> = [];
    if (response.toolCalls && response.toolCalls.length > 0) {
      const sandbox = new WorkspaceSandbox();
      const ctx = sandbox.createContext(sessionId, workspace);
      toolResults = await Promise.all(response.toolCalls.map((call) => toolRegistry.execute(call, ctx)));
    }

    return NextResponse.json({
      success: true,
      content: response.content,
      toolCalls: response.toolCalls ?? [],
      toolResults,
      usage: response.usage,
      model: response.model,
      provider: response.provider,
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
