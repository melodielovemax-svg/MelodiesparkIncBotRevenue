import { NextResponse } from "next/server";
import { toolRegistry } from "@/agent/tools/registry";
import { WorkspaceSandbox } from "@/agent/security/sandbox";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { command, workspace = process.cwd() } = body;

    const sandbox = new WorkspaceSandbox();
    const ctx = sandbox.createContext("web-terminal", workspace);
    const result = await toolRegistry.execute(
      { id: "term", name: "shell.execute", arguments: { command } },
      ctx
    );

    return NextResponse.json({
      success: !result.error,
      output: result.output,
      error: result.error,
      durationMs: result.durationMs,
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
