import { NextResponse } from "next/server";
import { db } from "@/db";
import { agentSessions } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(agentSessions).orderBy(desc(agentSessions.createdAt));
    return NextResponse.json({ success: true, data: rows });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const [row] = await db
      .insert(agentSessions)
      .values({
        name: body.name ?? "Untitled Session",
        workspace: body.workspace ?? process.cwd(),
        modelId: body.modelId ?? "openrouter/auto",
        providerId: body.providerId ?? "openrouter",
        metadata: body.metadata ?? {},
      })
      .returning();
    return NextResponse.json({ success: true, data: row });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
