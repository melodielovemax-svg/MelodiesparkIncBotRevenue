import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, services, workflows } from "@/db/schema";

const seedProducts = [
  {
    slug: "web3-saas-starter",
    name: "Web3 SaaS Starter Kit",
    description:
      "Complete Next.js + Solidity starter with wallet integration, token gating, and subscription contracts. Launch your decentralized SaaS in hours.",
    category: "Digital Product",
    priceUsd: "299.00",
    priceMa: "12500.00",
    featured: true,
    inStock: true,
    metadata: { tags: ["SaaS", "Solidity", "Next.js"] },
  },
  {
    slug: "ai-coding-agent",
    name: "MelodieLLM Coding Agent v8.5",
    description:
      "Autonomous coding agent that builds fullstack apps, CLI tools, and smart contracts from natural language prompts.",
    category: "AI Agent",
    priceUsd: "149.00",
    priceMa: "6200.00",
    featured: true,
    inStock: true,
    metadata: { tags: ["AI", "Agent", "Automation"] },
  },
  {
    slug: "quantum-fractal-workflow",
    name: "Quantum Fractal Workflow Engine",
    description:
      "Recursive task execution framework with parallel branching, rollback safety, and real-time telemetry for bot revenue systems.",
    category: "Automation",
    priceUsd: "499.00",
    priceMa: "21000.00",
    featured: true,
    inStock: true,
    metadata: { tags: ["Workflow", "Automation", "Bots"] },
  },
  {
    slug: "crypto-trading-bot",
    name: "Alpha Omega Trading Bot",
    description:
      "Multi-chain DEX arbitrage and market-making bot with MEV protection and automated rebalancing.",
    category: "Bot",
    priceUsd: "899.00",
    priceMa: "37500.00",
    featured: false,
    inStock: true,
    metadata: { tags: ["Trading", "DeFi", "MEV"] },
  },
  {
    slug: "nft-membership-pass",
    name: "Karma Ascension NFT Pass",
    description:
      "Lifetime membership NFT granting boosted karma rewards, early product access, and governance voting power.",
    category: "NFT",
    priceUsd: "199.00",
    priceMa: "8300.00",
    featured: false,
    inStock: true,
    metadata: { tags: ["NFT", "Membership", "Governance"] },
  },
  {
    slug: "dao-launchpad",
    name: "DAO Launchpad Template",
    description:
      "Full governance template with proposal creation, voting, treasury management, and token distribution.",
    category: "Digital Product",
    priceUsd: "399.00",
    priceMa: "16600.00",
    featured: false,
    inStock: true,
    metadata: { tags: ["DAO", "Governance", "Launchpad"] },
  },
];

const seedServices = [
  {
    slug: "smart-contract-audit",
    name: "Smart Contract Security Audit",
    description:
      "Professional audit of Solidity and Rust smart contracts with vulnerability report and remediation guidance.",
    category: "Service",
    priceUsd: "2500.00",
    priceMa: "104000.00",
    durationHours: 120,
    featured: true,
    active: true,
    metadata: { tags: ["Security", "Audit", "Solidity"] },
  },
  {
    slug: "web3-landing-page",
    name: "Web3 Landing Page Build",
    description:
      "High-converting landing page with wallet connection, tokenomics section, and gamified waitlist mechanics.",
    category: "Service",
    priceUsd: "1200.00",
    priceMa: "50000.00",
    durationHours: 48,
    featured: true,
    active: true,
    metadata: { tags: ["Design", "Landing Page", "Conversion"] },
  },
  {
    slug: "tokenomics-design",
    name: "Tokenomics & Token Design",
    description:
      "Comprehensive tokenomics modeling, distribution schedules, utility design, and vesting contracts.",
    category: "Service",
    priceUsd: "3500.00",
    priceMa: "145000.00",
    durationHours: 80,
    featured: false,
    active: true,
    metadata: { tags: ["Tokenomics", "Design", "Strategy"] },
  },
  {
    slug: "bot-automation-setup",
    name: "Bot Revenue Automation Setup",
    description:
      "End-to-end deployment of sales bots, workflow automations, and revenue tracking dashboards.",
    category: "Service",
    priceUsd: "1800.00",
    priceMa: "75000.00",
    durationHours: 72,
    featured: true,
    active: true,
    metadata: { tags: ["Bots", "Automation", "Revenue"] },
  },
];

const seedWorkflows = [
  {
    name: "Karma Mining Loop",
    description: "Completes good-deed-as-a-service tasks and earns karma power points.",
    triggerType: "manual",
    steps: [
      { id: "scan", label: "Scan network for good-deed opportunities", status: "idle" },
      { id: "verify", label: "Verify service completion on-chain", status: "idle" },
      { id: "mint", label: "Mint karma points to wallet", status: "idle" },
      { id: "notify", label: "Notify user and update leaderboard", status: "idle" },
    ],
    karmaReward: 250,
    maReward: "10.50",
    active: true,
  },
  {
    name: "Product Release Pipeline",
    description: "Automatically packages and releases digital products across marketplaces.",
    triggerType: "scheduled",
    steps: [
      { id: "build", label: "Build product artifact", status: "idle" },
      { id: "test", label: "Run quality checks", status: "idle" },
      { id: "deploy", label: "Deploy to storefront", status: "idle" },
      { id: "promote", label: "Distribute promotion bot", status: "idle" },
    ],
    karmaReward: 100,
    maReward: "5.00",
    active: true,
  },
  {
    name: "Treasury Sync Rebalancer",
    description: "Monitors revenue and rebalances treasury across ETH, USDT, and Bitcoin vaults.",
    triggerType: "event",
    steps: [
      { id: "collect", label: "Collect revenue from sales contracts", status: "idle" },
      { id: "swap", label: "Swap to target allocation", status: "idle" },
      { id: "deposit", label: "Deposit into multi-sig treasury", status: "idle" },
      { id: "report", label: "Generate on-chain report", status: "idle" },
    ],
    karmaReward: 500,
    maReward: "25.00",
    active: true,
  },
];

export async function POST() {
  try {
    await db.delete(workflows);
    await db.delete(products);
    await db.delete(services);

    await db.insert(products).values(seedProducts);
    await db.insert(services).values(seedServices);
    await db.insert(workflows).values(seedWorkflows);

    return NextResponse.json({
      success: true,
      counts: {
        products: seedProducts.length,
        services: seedServices.length,
        workflows: seedWorkflows.length,
      },
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
