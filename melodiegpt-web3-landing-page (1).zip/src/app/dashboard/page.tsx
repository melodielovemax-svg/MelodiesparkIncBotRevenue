import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { DashboardShell } from "@/components/dashboard/DashboardShell";
import { StatsGrid } from "@/components/dashboard/StatsGrid";
import { WorkflowPanel } from "@/components/dashboard/WorkflowPanel";
import { KarmaLeaderboard } from "@/components/dashboard/KarmaLeaderboard";
import { RecentOrders } from "@/components/dashboard/RecentOrders";
import { db } from "@/db";
import { workflows, orders, products, services } from "@/db/schema";
import { desc, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

async function getDashboardData() {
  const [workflowRows, orderRows, productCount, serviceCount] = await Promise.all([
    db.select().from(workflows).orderBy(desc(workflows.id)),
    db.select().from(orders).orderBy(desc(orders.createdAt)).limit(10),
    db.select({ count: sql<number>`COUNT(*)` }).from(products),
    db.select({ count: sql<number>`COUNT(*)` }).from(services),
  ]);

  return {
    workflows: workflowRows,
    orders: orderRows,
    productCount: productCount[0]?.count ?? 0,
    serviceCount: serviceCount[0]?.count ?? 0,
  };
}

export default async function DashboardPage() {
  const data = await getDashboardData();

  return (
    <div className="bg-mesh min-h-screen">
      <Header />
      <main className="pt-28 pb-20">
        <DashboardShell title="Melodie Ecosystem" subtitle="Bot revenue automation, karma gamification, and Web3 portfolio sync.">
          <StatsGrid productCount={data.productCount} serviceCount={data.serviceCount} workflowCount={data.workflows.length} />
          <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <WorkflowPanel workflows={data.workflows} />
            </div>
            <div className="space-y-6">
              <KarmaLeaderboard />
              <RecentOrders orders={data.orders} />
            </div>
          </div>
        </DashboardShell>
      </main>
      <Footer />
    </div>
  );
}
