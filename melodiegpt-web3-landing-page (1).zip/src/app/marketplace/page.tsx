import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { MarketplaceGrid } from "@/components/marketplace/MarketplaceGrid";
import { db } from "@/db";
import { products, services } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Marketplace — MelodieGPT",
  description: "Digital products and services for Web3 automation, AI agents, and crypto ecosystems.",
};

async function getMarketplaceData() {
  const [productRows, serviceRows] = await Promise.all([
    db.select().from(products).orderBy(desc(products.featured), desc(products.id)),
    db.select().from(services).orderBy(desc(services.featured), desc(services.id)),
  ]);
  return { products: productRows, services: serviceRows };
}

export default async function MarketplacePage() {
  const data = await getMarketplaceData();

  return (
    <div className="bg-mesh min-h-screen">
      <Header />
      <main className="pt-28 pb-20">
        <MarketplaceGrid products={data.products} services={data.services} />
      </main>
      <Footer />
    </div>
  );
}
