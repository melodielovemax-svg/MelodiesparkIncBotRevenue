import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { AgentIDE } from "@/components/agent/AgentIDE";

export const metadata = {
  title: "Agent IDE — MelodieGPT",
  description: "Multi-model coding agent IDE with chat, explorer, and terminal.",
};

export default function AgentPage() {
  return (
    <div className="bg-mesh min-h-screen">
      <Header />
      <main className="pt-24 pb-12">
        <AgentIDE />
      </main>
      <Footer />
    </div>
  );
}
