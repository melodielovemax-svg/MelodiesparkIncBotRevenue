import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { WalletDashboard } from "@/components/wallet/WalletDashboard";

export const metadata = {
  title: "Metamello Wallet — MelodieGPT",
  description: "Web3 wallet with karma power points, MA token mining, and crypto swaps.",
};

export default function WalletPage() {
  return (
    <div className="bg-mesh min-h-screen">
      <Header />
      <main className="pt-28 pb-20">
        <WalletDashboard />
      </main>
      <Footer />
    </div>
  );
}
