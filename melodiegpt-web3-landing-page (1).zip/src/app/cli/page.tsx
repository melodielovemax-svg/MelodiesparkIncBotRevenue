import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Terminal } from "@/components/cli/Terminal";

export const metadata = {
  title: "Quantum CLI — MelodieGPT",
  description: "Quantum fractal CLI terminal for bot revenue automation and Web3 workflows.",
};

export default function CliPage() {
  return (
    <div className="bg-mesh min-h-screen">
      <Header />
      <main className="pt-28 pb-20">
        <Terminal />
      </main>
      <Footer />
    </div>
  );
}
