"use client";

import { useState } from "react";
import { ShoppingCart, Clock, Star, Package, Wrench } from "lucide-react";
import type { Product, Service } from "@/db/schema";
import { useWallet } from "@/components/wallet/WalletProvider";

interface MarketplaceGridProps {
  products: Product[];
  services: Service[];
}

export function MarketplaceGrid({ products, services }: MarketplaceGridProps) {
  const [tab, setTab] = useState<"products" | "services">("products");
  const [buying, setBuying] = useState<number | null>(null);
  const { wallet } = useWallet();

  const buyItem = async (item: Product | Service, type: "product" | "service") => {
    if (!wallet.address) {
      alert("Connect your wallet first.");
      return;
    }
    setBuying(item.id);
    await new Promise((resolve) => setTimeout(resolve, 1200));
    await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        walletAddress: wallet.address,
        itemType: type,
        itemId: item.id,
        totalUsd: item.priceUsd,
        totalMa: item.priceMa,
      }),
    });
    setBuying(null);
    alert(`${item.name} purchased. Complete payment on-chain to activate.`);
  };

  const items = tab === "products" ? products : services;

  return (
    <div className="mx-auto max-w-7xl px-6">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white md:text-4xl">
            Digital <span className="text-gradient">Marketplace</span>
          </h1>
          <p className="mt-2 text-slate-400">
            Premium products and services for Web3 automation, AI, and crypto ecosystems.
          </p>
        </div>
        <div className="flex rounded-full border border-white/10 bg-white/5 p-1">
          <button
            onClick={() => setTab("products")}
            className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-all ${
              tab === "products"
                ? "bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Package className="h-4 w-4" /> Products
          </button>
          <button
            onClick={() => setTab("services")}
            className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-all ${
              tab === "services"
                ? "bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Wrench className="h-4 w-4" /> Services
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((item) => {
          const isProduct = "inStock" in item;
          return (
            <div
              key={item.id}
              className="glass-card group flex flex-col rounded-3xl p-6 transition-all hover:-translate-y-1 hover:border-white/10 hover:shadow-xl hover:shadow-violet-500/10"
            >
              <div className="flex items-start justify-between">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500/20 to-cyan-500/20 text-lg font-bold text-cyan-300">
                  {item.name.charAt(0)}
                </div>
                {item.featured && (
                  <span className="flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-0.5 text-[10px] font-medium uppercase text-amber-300">
                    <Star className="h-3 w-3" /> Featured
                  </span>
                )}
              </div>

              <h3 className="mt-4 text-lg font-semibold text-white">{item.name}</h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-400">{item.description}</p>

              <div className="mt-4 flex flex-wrap gap-2">
                {((item.metadata as { tags?: string[] })?.tags ?? []).map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] font-medium text-slate-300"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {!isProduct && "durationHours" in item && item.durationHours && (
                <div className="mt-4 flex items-center gap-1 text-xs text-slate-400">
                  <Clock className="h-3.5 w-3.5" /> {item.durationHours}h delivery
                </div>
              )}

              <div className="mt-5 flex items-center justify-between border-t border-white/5 pt-5">
                <div>
                  <p className="text-xl font-bold text-white">${item.priceUsd}</p>
                  <p className="text-xs text-fuchsia-400">{item.priceMa} MA</p>
                </div>
                <button
                  onClick={() => buyItem(item, isProduct ? "product" : "service")}
                  disabled={buying === item.id || (isProduct && !(item as Product).inStock)}
                  className="flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-violet-600/20 transition-all hover:from-violet-500 hover:to-fuchsia-500 disabled:opacity-60"
                >
                  <ShoppingCart className="h-4 w-4" />
                  {buying === item.id ? "..." : "Buy"}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
