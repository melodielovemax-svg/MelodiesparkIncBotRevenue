"use client";

import { useState } from "react";
import { Play, CheckCircle2, Loader2, RefreshCw, Bot } from "lucide-react";
import type { Workflow } from "@/db/schema";

interface WorkflowPanelProps {
  workflows: Workflow[];
}

export function WorkflowPanel({ workflows }: WorkflowPanelProps) {
  const [items, setItems] = useState(workflows);
  const [runningId, setRunningId] = useState<number | null>(null);

  const runWorkflow = async (workflow: Workflow) => {
    setRunningId(workflow.id);

    await fetch("/api/workflows", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: workflow.id, status: "running" }),
    });

    setItems((prev) =>
      prev.map((w) => (w.id === workflow.id ? { ...w, status: "running" } : w))
    );

    await new Promise((resolve) => setTimeout(resolve, 2500));

    await fetch("/api/workflows", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: workflow.id, status: "completed" }),
    });

    setItems((prev) =>
      prev.map((w) =>
        w.id === workflow.id
          ? { ...w, status: "completed", executedCount: (w.executedCount ?? 0) + 1 }
          : w
      )
    );
    setRunningId(null);
  };

  return (
    <div className="glass glow-violet rounded-3xl p-6">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500">
            <Bot className="h-5 w-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">Bot Revenue Workflows</h2>
            <p className="text-xs text-slate-400">Execute automated revenue and karma pipelines</p>
          </div>
        </div>
        <button
          onClick={() => window.location.reload()}
          className="rounded-full border border-white/10 bg-white/5 p-2 text-slate-300 transition-colors hover:bg-white/10"
        >
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-4">
        {items.map((workflow) => (
          <div
            key={workflow.id}
            className="rounded-2xl border border-white/5 bg-white/[0.03] p-4 transition-all hover:border-white/10"
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h3 className="font-semibold text-white">{workflow.name}</h3>
                <p className="text-sm text-slate-400">{workflow.description}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <span className="rounded-full bg-violet-500/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-violet-300">
                    {workflow.triggerType}
                  </span>
                  <span className="rounded-full bg-cyan-500/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-cyan-300">
                    +{workflow.karmaReward} Karma
                  </span>
                  <span className="rounded-full bg-fuchsia-500/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-fuchsia-300">
                    +{workflow.maReward} MA
                  </span>
                  <span className="rounded-full bg-slate-500/10 px-2 py-0.5 text-[10px] font-medium text-slate-400">
                    Runs: {workflow.executedCount ?? 0}
                  </span>
                </div>
              </div>
              <button
                onClick={() => runWorkflow(workflow)}
                disabled={runningId === workflow.id || workflow.status === "running"}
                className="flex shrink-0 items-center gap-2 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-violet-600/20 transition-all hover:from-violet-500 hover:to-fuchsia-500 disabled:opacity-60"
              >
                {runningId === workflow.id ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : workflow.status === "completed" ? (
                  <CheckCircle2 className="h-4 w-4" />
                ) : (
                  <Play className="h-4 w-4" />
                )}
                {runningId === workflow.id ? "Running" : workflow.status === "completed" ? "Run Again" : "Execute"}
              </button>
            </div>

            {Array.isArray(workflow.steps) && (
              <div className="mt-4 flex flex-wrap gap-2">
                {(workflow.steps as unknown as Array<{ id: string; label: string; status: string }>).map((step, idx) => (
                  <div key={step.id} className="flex items-center gap-2">
                    <span
                      className={`inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${
                        workflow.status === "completed"
                          ? "bg-emerald-500/20 text-emerald-400"
                          : workflow.status === "running"
                          ? "bg-amber-500/20 text-amber-400"
                          : "bg-slate-700 text-slate-400"
                      }`}
                    >
                      {idx + 1}
                    </span>
                    <span className="text-xs text-slate-400">{step.label}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
