import type { ReactNode } from "react";

interface DashboardShellProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
}

export function DashboardShell({ title, subtitle, children }: DashboardShellProps) {
  return (
    <div className="mx-auto max-w-7xl px-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-white md:text-4xl">{title}</h1>
        {subtitle && <p className="mt-2 text-slate-400">{subtitle}</p>}
      </div>
      <div className="space-y-6">{children}</div>
    </div>
  );
}
