"use client";

import { Trophy, Flame, Crown, Star } from "lucide-react";

const leaders = [
  { rank: 1, wallet: "0x7a3f...9c21", karma: 982400, level: "Ascended" },
  { rank: 2, wallet: "0xb8d2...1a44", karma: 875200, level: "Oracle" },
  { rank: 3, wallet: "0xe5c9...7f88", karma: 742100, level: "Guardian" },
  { rank: 4, wallet: "0x1f4a...3b12", karma: 621000, level: "Architect" },
  { rank: 5, wallet: "0x9d7e...5c66", karma: 548900, level: "Sentinel" },
];

export function KarmaLeaderboard() {
  return (
    <div className="glass-card rounded-3xl p-6">
      <div className="mb-5 flex items-center gap-2">
        <Trophy className="h-5 w-5 text-amber-400" />
        <h2 className="text-lg font-semibold text-white">Karma Ascension Board</h2>
      </div>
      <div className="space-y-3">
        {leaders.map((leader) => (
          <div
            key={leader.rank}
            className="flex items-center gap-3 rounded-xl bg-white/[0.03] p-3 transition-colors hover:bg-white/[0.06]"
          >
            <div
              className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold ${
                leader.rank === 1
                  ? "bg-amber-500/20 text-amber-400"
                  : leader.rank === 2
                  ? "bg-slate-400/20 text-slate-300"
                  : leader.rank === 3
                  ? "bg-orange-500/20 text-orange-400"
                  : "bg-slate-700 text-slate-400"
              }`}
            >
              {leader.rank === 1 ? <Crown className="h-4 w-4" /> : leader.rank}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-white">{leader.wallet}</p>
              <p className="text-xs text-slate-400">{leader.level}</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-white">
                {leader.karma.toLocaleString()}
              </p>
              <p className="flex items-center justify-end gap-1 text-[10px] text-amber-400">
                <Flame className="h-3 w-3" /> Karma
              </p>
            </div>
          </div>
        ))}
      </div>
      <button className="mt-5 w-full rounded-xl border border-white/10 bg-white/5 py-2.5 text-sm font-medium text-slate-300 transition-colors hover:bg-white/10">
        <span className="flex items-center justify-center gap-2">
          <Star className="h-4 w-4" />
          View Full Leaderboard
        </span>
      </button>
    </div>
  );
}
