"use client";

import { Package, Wrench, Bot, TrendingUp } from "lucide-react";

interface StatsGridProps {
  productCount: number;
  serviceCount: number;
  workflowCount: number;
}

export function StatsGrid({ productCount, serviceCount, workflowCount }: StatsGridProps) {
  const stats = [
    { label: "Digital Products", value: productCount, icon: Package, color: "text-violet-400" },
    { label: "Services", value: serviceCount, icon: Wrench, color: "text-cyan-400" },
    { label: "Active Workflows", value: workflowCount, icon: Bot, color: "text-fuchsia-400" },
    { label: "Network Karma", value: "2.4M+", icon: TrendingUp, color: "text-emerald-400" },
  ];

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="glass-card rounded-2xl p-5 transition-all hover:-translate-y-1 hover:border-white/10"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-white">{stat.value}</p>
              <p className="mt-1 text-sm text-slate-400">{stat.label}</p>
            </div>
            <stat.icon className={`h-8 w-8 ${stat.color}`} />
          </div>
        </div>
      ))}
    </div>
  );
}
