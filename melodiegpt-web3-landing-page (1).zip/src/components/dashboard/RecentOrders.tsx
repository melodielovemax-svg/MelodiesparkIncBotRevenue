"use client";

import { ArrowUpRight, ShoppingCart } from "lucide-react";
import type { Order } from "@/db/schema";

interface RecentOrdersProps {
  orders: Order[];
}

const statusStyles: Record<string, string> = {
  pending: "bg-amber-500/10 text-amber-300",
  paid: "bg-emerald-500/10 text-emerald-300",
  completed: "bg-cyan-500/10 text-cyan-300",
  failed: "bg-rose-500/10 text-rose-300",
};

export function RecentOrders({ orders }: RecentOrdersProps) {
  return (
    <div className="glass-card rounded-3xl p-6">
      <div className="mb-5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShoppingCart className="h-5 w-5 text-cyan-400" />
          <h2 className="text-lg font-semibold text-white">Recent Orders</h2>
        </div>
        <a
          href="/marketplace"
          className="flex items-center gap-1 text-xs font-medium text-violet-400 hover:text-violet-300"
        >
          Marketplace <ArrowUpRight className="h-3 w-3" />
        </a>
      </div>

      {orders.length === 0 ? (
        <div className="rounded-xl border border-dashed border-white/10 bg-white/5 py-8 text-center">
          <p className="text-sm text-slate-400">No orders yet.</p>
          <p className="mt-1 text-xs text-slate-500">Visit the marketplace to make a purchase.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((order) => (
            <div
              key={order.id}
              className="flex items-center justify-between rounded-xl bg-white/[0.03] p-3"
            >
              <div>
                <p className="text-sm font-medium text-white capitalize">
                  {order.itemType} #{order.itemId}
                </p>
                <p className="text-xs text-slate-400">
                  {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : "—"}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold text-white">${order.totalUsd}</p>
                <span
                  className={`rounded-full px-2 py-0.5 text-[10px] font-medium uppercase ${
                    statusStyles[order.status] ?? "bg-slate-500/10 text-slate-400"
                  }`}
                >
                  {order.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
