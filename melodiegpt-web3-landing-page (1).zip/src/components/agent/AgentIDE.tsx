"use client";

import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Loader2, Terminal as TerminalIcon, FolderTree, Settings } from "lucide-react";
import { FileExplorer } from "./FileExplorer";
import { AgentTerminal } from "./AgentTerminal";

interface ChatMessage {
  role: "user" | "assistant" | "tool";
  content: string;
  meta?: { model?: string; provider?: string; tokens?: number };
}

export function AgentIDE() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: "Welcome to Melodie Agent IDE. I can inspect code, run tests, modify files, and execute shell commands in the workspace sandbox.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [model, setModel] = useState("openrouter/auto");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg: ChatMessage = { role: "user", content: input };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/agent/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          messages: [...messages, userMsg].map((m) => ({ role: m.role, content: m.content })),
          workspace: process.cwd(),
          sessionId: "web-ide",
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMessages((prev) => [
          ...prev,
          { role: "assistant", content: data.content, meta: { model: data.model, provider: data.provider, tokens: data.usage?.totalTokens } },
        ]);
        if (data.toolResults?.length) {
          data.toolResults.forEach((tr: { name: string; output: string; error?: string }) => {
            setMessages((prev) => [
              ...prev,
              { role: "tool", content: `[${tr.name}]\n${tr.error ? `Error: ${tr.error}` : tr.output}` },
            ]);
          });
        }
      } else {
        setMessages((prev) => [...prev, { role: "assistant", content: `Error: ${data.error}` }]);
      }
    } catch (err) {
      setMessages((prev) => [...prev, { role: "assistant", content: `Error: ${err instanceof Error ? err.message : String(err)}` }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-7xl flex-col gap-4 px-6 lg:flex-row">
      {/* Sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col gap-4 lg:flex">
        <div className="glass-card rounded-2xl p-4">
          <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
            <FolderTree className="h-4 w-4" /> Explorer
          </div>
          <FileExplorer />
        </div>
        <div className="glass-card rounded-2xl p-4">
          <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
            <Settings className="h-4 w-4" /> Model
          </div>
          <select
            value={model}
            onChange={(e) => setModel(e.target.value)}
            className="w-full rounded-lg border border-white/10 bg-slate-900/60 px-3 py-2 text-sm text-white"
          >
            <option value="openrouter/auto">OpenRouter Auto</option>
            <option value="openai/gpt-4-turbo">GPT-4 Turbo</option>
            <option value="openai/gpt-4">GPT-4</option>
            <option value="openai/gpt-3.5-turbo">GPT-3.5 Turbo</option>
            <option value="mistralai/mistral-large">Mistral Large</option>
            <option value="undi95/remm-slerp-13b">ReMM SLERP 13B</option>
            <option value="gryphe/mythomax-13b">MythoMax 13B</option>
          </select>
        </div>
      </aside>

      {/* Main chat */}
      <div className="flex flex-1 flex-col gap-4">
        <div className="glass flex flex-1 flex-col overflow-hidden rounded-3xl">
          <div className="flex items-center justify-between border-b border-white/5 px-5 py-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <Bot className="h-4 w-4 text-cyan-400" /> Agent Chat
            </div>
            <span className="text-xs text-slate-400">{model}</span>
          </div>
          <div className="flex-1 overflow-y-auto px-5 py-4">
            {messages.map((m, idx) => (
              <div key={idx} className={`mb-4 flex gap-3 ${m.role === "user" ? "justify-end" : ""}`}>
                {m.role !== "user" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-cyan-500 to-violet-500">
                    {m.role === "tool" ? <TerminalIcon className="h-4 w-4 text-white" /> : <Bot className="h-4 w-4 text-white" />}
                  </div>
                )}
                <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm ${m.role === "user" ? "rounded-br-md bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white" : m.role === "tool" ? "rounded-tl-md border border-white/10 bg-slate-900/60 text-slate-300" : "rounded-tl-md glass-card text-slate-200"}`}>
                  <pre className="whitespace-pre-wrap font-sans">{m.content}</pre>
                  {m.meta && <p className="mt-1 text-[10px] text-slate-500">{m.meta.provider}/{m.meta.model} · {m.meta.tokens} tokens</p>}
                </div>
                {m.role === "user" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-700">
                    <User className="h-4 w-4 text-slate-300" />
                  </div>
                )}
              </div>
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Loader2 className="h-4 w-4 animate-spin" /> Agent is thinking...
              </div>
            )}
            <div ref={bottomRef} />
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage();
            }}
            className="flex items-center gap-3 border-t border-white/5 bg-white/5 px-5 py-4"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask the agent to code, test, refactor, or explain..."
              className="flex-1 rounded-full border border-white/10 bg-slate-900/60 px-5 py-3 text-sm text-white placeholder:text-slate-500 focus:border-violet-500/50 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-lg shadow-violet-600/25 transition-all hover:scale-105 disabled:opacity-60"
            >
              <Send className="h-5 w-5" />
            </button>
          </form>
        </div>
      </div>

      {/* Terminal panel */}
      <aside className="h-64 shrink-0 lg:h-auto lg:w-80">
        <AgentTerminal />
      </aside>
    </div>
  );
}
