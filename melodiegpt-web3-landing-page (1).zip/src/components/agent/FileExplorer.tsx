"use client";

import { useState, useEffect } from "react";
import { Folder, FileText, ChevronRight, ChevronDown } from "lucide-react";

interface TreeNode {
  name: string;
  path: string;
  type: "file" | "dir";
  children?: TreeNode[];
}

export function FileExplorer() {
  const [tree, setTree] = useState<TreeNode[]>([]);
  const [expanded, setExpanded] = useState<Set<string>>(new Set(["src"]));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/agent/files?path=.")
      .then((r) => r.json())
      .then((data) => {
        if (data.success) setTree(data.data);
      })
      .catch(() => setTree([]))
      .finally(() => setLoading(false));
  }, []);

  const toggle = (path: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });
  };

  const renderNode = (node: TreeNode, depth = 0) => (
    <div key={node.path} style={{ paddingLeft: depth * 12 }}>
      <button
        onClick={() => node.type === "dir" && toggle(node.path)}
        className="flex w-full items-center gap-1 rounded-md py-1 text-left text-xs text-slate-300 hover:bg-white/5"
      >
        {node.type === "dir" ? (
          <>
            {expanded.has(node.path) ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            <Folder className="h-3.5 w-3.5 text-amber-400" />
          </>
        ) : (
          <>
            <span className="w-3" />
            <FileText className="h-3.5 w-3.5 text-cyan-400" />
          </>
        )}
        <span className="truncate">{node.name}</span>
      </button>
      {node.type === "dir" && expanded.has(node.path) && node.children?.map((child) => renderNode(child, depth + 1))}
    </div>
  );

  if (loading) return <p className="text-xs text-slate-500">Loading...</p>;

  return <div className="max-h-64 overflow-y-auto">{tree.map((node) => renderNode(node))}</div>;
}
