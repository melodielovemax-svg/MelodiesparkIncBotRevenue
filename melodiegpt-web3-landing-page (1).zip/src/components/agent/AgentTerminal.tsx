"use client";

import { useState, useRef, useEffect } from "react";
import { Send, Terminal as TerminalIcon } from "lucide-react";

interface TerminalLine {
  type: "in" | "out" | "err";
  text: string;
}

export function AgentTerminal() {
  const [lines, setLines] = useState<TerminalLine[]>([
    { type: "out", text: "Melodie Agent Terminal v1.0" },
    { type: "out", text: "Type shell commands to execute in workspace sandbox." },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [lines]);

  const runCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;
    const cmd = input;
    setInput("");
    setLines((prev) => [...prev, { type: "in", text: `$ ${cmd}` }]);
    setLoading(true);

    try {
      const res = await fetch("/api/agent/terminal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command: cmd }),
      });
      const data = await res.json();
      setLines((prev) => [
        ...prev,
        { type: data.success ? "out" : "err", text: data.output || data.error || "No output" },
      ]);
    } catch (err) {
      setLines((prev) => [...prev, { type: "err", text: err instanceof Error ? err.message : String(err) }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="glass flex h-full flex-col overflow-hidden rounded-3xl">
      <div className="flex items-center gap-2 border-b border-white/5 px-4 py-3 text-sm font-semibold text-white">
        <TerminalIcon className="h-4 w-4 text-cyan-400" /> Terminal
      </div>
      <div className="flex-1 overflow-y-auto bg-slate-950/70 p-4 font-mono text-xs">
        {lines.map((line, idx) => (
          <div
            key={idx}
            className={`whitespace-pre-wrap break-words py-0.5 ${
              line.type === "in" ? "text-cyan-400" : line.type === "err" ? "text-rose-400" : "text-slate-300"
            }`}
          >
            {line.text}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <form onSubmit={runCommand} className="flex items-center gap-2 border-t border-white/5 bg-white/5 px-3 py-2">
        <span className="font-mono text-sm text-cyan-400">$</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={loading}
          placeholder="command..."
          className="flex-1 bg-transparent font-mono text-xs text-white placeholder:text-slate-600 focus:outline-none"
        />
        <button type="submit" disabled={loading || !input.trim()} className="text-slate-300 hover:text-white disabled:opacity-50">
          <Send className="h-3.5 w-3.5" />
        </button>
      </form>
    </div>
  );
}
