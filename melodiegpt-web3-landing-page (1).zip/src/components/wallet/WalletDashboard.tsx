"use client";

import { useEffect, useState } from "react";
import {
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  RefreshCw,
  Zap,
  Loader2,
  Copy,
  ExternalLink,
  AlertCircle,
} from "lucide-react";
import { useWallet } from "./WalletProvider";
import { sendTransaction, shortenAddress, getExplorerUrl } from "@/lib/web3";

export function WalletDashboard() {
  const { wallet, connect, disconnect, loading, refresh, error } = useWallet();
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [txHash, setTxHash] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [mining, setMining] = useState(false);
  const [maBalance, setMaBalance] = useState("0.00");
  const [karma, setKarma] = useState(0);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!wallet.address) return;
    fetch(`/api/karma?wallet=${wallet.address}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.success) setKarma(data.total ?? 0);
      })
      .catch(() => {});
  }, [wallet.address]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!wallet.isConnected || !recipient || !amount) return;
    setSending(true);
    setTxHash(null);
    try {
      const hash = await sendTransaction(recipient, amount);
      setTxHash(hash);
      setRecipient("");
      setAmount("");
      refresh();
    } catch (err) {
      alert(err instanceof Error ? err.message : "Transaction failed");
    } finally {
      setSending(false);
    }
  };

  const handleMine = async () => {
    if (!wallet.address) return;
    setMining(true);
    await new Promise((resolve) => setTimeout(resolve, 2000));
    const reward = (Math.random() * 5 + 1).toFixed(2);
    setMaBalance((prev) => (parseFloat(prev) + parseFloat(reward)).toFixed(2));
    await fetch("/api/karma", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        walletAddress: wallet.address,
        type: "mine",
        amount: Math.floor(parseFloat(reward) * 10),
        reason: "MA Token Mining reward",
      }),
    });
    fetch(`/api/karma?wallet=${wallet.address}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.success) setKarma(data.total ?? 0);
      });
    setMining(false);
  };

  const copyAddress = () => {
    if (!wallet.address) return;
    navigator.clipboard.writeText(wallet.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="mx-auto max-w-6xl px-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-white md:text-4xl">
          Metamello <span className="text-gradient">Wallet</span>
        </h1>
        <p className="mt-2 text-slate-400">Karma power points, MA tokens, and real blockchain sync.</p>
      </div>

      {error && (
        <div className="mb-6 flex items-center gap-3 rounded-2xl border border-rose-500/20 bg-rose-500/10 p-4 text-rose-200">
          <AlertCircle className="h-5 w-5" />
          {error}
        </div>
      )}

      {!wallet.isConnected ? (
        <div className="glass-card flex flex-col items-center justify-center rounded-3xl py-20 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500">
            <Wallet className="h-8 w-8 text-white" />
          </div>
          <h2 className="mt-6 text-xl font-semibold text-white">Connect Your Wallet</h2>
          <p className="mt-2 max-w-md text-slate-400">
            Connect MetaMask, Brave Wallet, or any injected Web3 provider to view your portfolio and
            start mining MA tokens.
          </p>
          <button
            onClick={() => connect()}
            disabled={loading}
            className="mt-6 flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 px-8 py-3.5 text-base font-semibold text-white shadow-lg shadow-violet-600/25 transition-all hover:from-violet-500 hover:to-fuchsia-500 disabled:opacity-60"
          >
            {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Wallet className="h-5 w-5" />}
            Connect Wallet
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Balance card */}
          <div className="glass glow-violet rounded-3xl p-6 lg:col-span-2">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-400">Wallet Address</p>
                <div className="mt-1 flex items-center gap-2">
                  <span className="text-lg font-semibold text-white">{shortenAddress(wallet.address ?? "")}</span>
                  <button onClick={copyAddress} className="text-slate-400 hover:text-white">
                    <Copy className="h-4 w-4" />
                  </button>
                  {copied && <span className="text-xs text-emerald-400">Copied</span>}
                </div>
              </div>
              <button
                onClick={() => refresh()}
                className="rounded-full border border-white/10 bg-white/5 p-2 text-slate-300 transition-colors hover:bg-white/10"
              >
                <RefreshCw className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div className="rounded-2xl bg-white/5 p-4">
                <p className="text-xs text-slate-400">Native Balance</p>
                <p className="mt-1 text-2xl font-bold text-white">
                  {parseFloat(wallet.balance).toFixed(4)} {wallet.symbol}
                </p>
              </div>
              <div className="rounded-2xl bg-white/5 p-4">
                <p className="text-xs text-slate-400">MA Tokens</p>
                <p className="mt-1 text-2xl font-bold text-white">{maBalance} MA</p>
              </div>
              <div className="rounded-2xl bg-white/5 p-4">
                <p className="text-xs text-slate-400">Karma Power</p>
                <p className="mt-1 text-2xl font-bold text-white">{karma.toLocaleString()}</p>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <button className="flex items-center justify-center gap-2 rounded-xl bg-violet-600 py-3 text-sm font-semibold text-white transition-all hover:bg-violet-500">
                <ArrowDownLeft className="h-4 w-4" /> Receive
              </button>
              <button className="flex items-center justify-center gap-2 rounded-xl bg-cyan-600 py-3 text-sm font-semibold text-white transition-all hover:bg-cyan-500">
                <ArrowUpRight className="h-4 w-4" /> Send
              </button>
              <button className="flex items-center justify-center gap-2 rounded-xl bg-fuchsia-600 py-3 text-sm font-semibold text-white transition-all hover:bg-fuchsia-500">
                <RefreshCw className="h-4 w-4" /> Swap
              </button>
              <button
                onClick={handleMine}
                disabled={mining}
                className="col-span-2 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 py-3 text-sm font-semibold text-white shadow-lg shadow-orange-500/20 transition-all hover:from-amber-400 hover:to-orange-400 disabled:opacity-60 sm:col-span-1"
              >
                {mining ? <Loader2 className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}
                Start MA Mining
              </button>
            </div>
          </div>

          {/* Send form */}
          <div className="glass-card rounded-3xl p-6">
            <h2 className="text-lg font-semibold text-white">Transfer Crypto</h2>
            <p className="text-xs text-slate-400">Send native tokens to any address.</p>
            <form onSubmit={handleSend} className="mt-5 space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-400">Recipient</label>
                <input
                  type="text"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  placeholder="0x..."
                  className="mt-1 w-full rounded-xl border border-white/10 bg-slate-900/60 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:border-violet-500/50 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-400">Amount ({wallet.symbol})</label>
                <input
                  type="number"
                  step="0.0001"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.0"
                  className="mt-1 w-full rounded-xl border border-white/10 bg-slate-900/60 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:border-violet-500/50 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
                />
              </div>
              <button
                type="submit"
                disabled={sending || !recipient || !amount}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 py-3 text-sm font-semibold text-white shadow-lg shadow-violet-600/20 transition-all hover:from-violet-500 hover:to-fuchsia-500 disabled:opacity-60"
              >
                {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowUpRight className="h-4 w-4" />}
                Confirm Transfer
              </button>
            </form>

            {txHash && (
              <div className="mt-4 rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-3">
                <p className="text-xs text-emerald-300">Transaction submitted</p>
                <a
                  href={getExplorerUrl(wallet.chainId ?? 1, txHash)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-1 flex items-center gap-1 text-xs text-emerald-400 hover:underline"
                >
                  {shortenAddress(txHash)} <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
