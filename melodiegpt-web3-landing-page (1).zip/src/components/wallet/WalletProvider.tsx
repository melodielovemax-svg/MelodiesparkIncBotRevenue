"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  type ReactNode,
} from "react";
import { connectWallet, disconnectWallet, type WalletState } from "@/lib/web3";

interface WalletContextValue {
  wallet: WalletState;
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  refresh: () => Promise<void>;
  loading: boolean;
  error: string | null;
}

const initialWallet: WalletState = {
  address: null,
  chainId: null,
  balance: "0",
  symbol: "ETH",
  isConnected: false,
};

const WalletContext = createContext<WalletContextValue | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<WalletState>(initialWallet);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!wallet.isConnected || !wallet.address) return;
    setLoading(true);
    try {
      const state = await connectWallet();
      setWallet(state);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Refresh failed");
    } finally {
      setLoading(false);
    }
  }, [wallet.isConnected, wallet.address]);

  const connect = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const state = await connectWallet();
      setWallet(state);
      localStorage.setItem("metamello_wallet_connected", "true");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Connection failed");
    } finally {
      setLoading(false);
    }
  }, []);

  const disconnect = useCallback(async () => {
    setLoading(true);
    try {
      const state = await disconnectWallet();
      setWallet(state);
      localStorage.removeItem("metamello_wallet_connected");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Disconnect failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const auto = localStorage.getItem("metamello_wallet_connected");
    if (auto === "true") {
      connect().catch(() => {});
    }
  }, [connect]);

  useEffect(() => {
    if (typeof window === "undefined" || !window.ethereum) return;

    const handleAccountsChanged = (accounts: unknown) => {
      if (Array.isArray(accounts) && accounts.length === 0) {
        disconnect().catch(() => {});
      } else {
        refresh().catch(() => {});
      }
    };

    const handleChainChanged = () => {
      refresh().catch(() => {});
    };

    window.ethereum.on("accountsChanged", handleAccountsChanged);
    window.ethereum.on("chainChanged", handleChainChanged);

    return () => {
      window.ethereum?.removeListener("accountsChanged", handleAccountsChanged);
      window.ethereum?.removeListener("chainChanged", handleChainChanged);
    };
  }, [disconnect, refresh]);

  return (
    <WalletContext.Provider value={{ wallet, connect, disconnect, refresh, loading, error }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used within WalletProvider");
  return ctx;
}
