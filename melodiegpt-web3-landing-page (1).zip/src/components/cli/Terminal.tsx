"use client";

import { useState, useRef, useEffect } from "react";
import { Terminal as TerminalIcon, Play, Trash2, Copy, CheckCircle2 } from "lucide-react";

interface LogLine {
  id: number;
  text: string;
  type: "info" | "success" | "warn" | "error" | "cmd";
  timestamp: string;
}

const initialLogs: LogLine[] = [
  { id: 1, text: "Melodie Quantum Fractal CLI v8.5", type: "info", timestamp: "[SYSTEM]" },
  { id: 2, text: "Initializing sacred geometry task matrix...", type: "info", timestamp: "[INIT]" },
  { id: 3, text: "Loaded 80,000 bot revenue automation scripts", type: "success", timestamp: "[OK]" },
  { id: 4, text: "Connected to decentralized inference mesh", type: "success", timestamp: "[OK]" },
  { id: 5, text: "Type 'help' to view available commands.", type: "warn", timestamp: "[READY]" },
];

const COMMANDS: Record<string, string[]> = {
  help: [
    "Available commands:",
    "  help              Show this help menu",
    "  status            Display ecosystem status",
    "  mine              Start MA token karma mining loop",
    "  release           Auto-release superior product packages",
    "  workflows         List active bot revenue workflows",
    "  treasury          Sync treasury across ETH/USDT/BTC vaults",
    "  swap <to> <amt>   Swap MA tokens to ETH, USDT, or BTC",
    "  clear             Clear terminal output",
  ],
  status: [
    "Ecosystem Status:",
    "  Node: online",
    "  Wallet sync: active",
    "  Bot fleet: 80,000 idle agents",
    "  Karma pool: 2,412,890 points",
    "  MA token supply: 100,000,000",
    "  Last block: synced",
  ],
  workflows: [
    "Active Workflows:",
    "  1. Karma Mining Loop        [idle]",
    "  2. Product Release Pipeline [idle]",
    "  3. Treasury Sync Rebalancer [idle]",
    "Use the Dashboard to execute workflows.",
  ],
};

export function Terminal() {
  const [logs, setLogs] = useState<LogLine[]>(initialLogs);
  const [input, setInput] = useState("");
  const [running, setRunning] = useState(false);
  const [copied, setCopied] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(initialLogs.length + 1);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  const addLog = (text: string, type: LogLine["type"] = "info") => {
    setLogs((prev) => [
      ...prev,
      {
        id: idRef.current++,
        text,
        type,
        timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
      },
    ]);
  };

  const runCommand = async (raw: string) => {
    const cmd = raw.trim();
    if (!cmd) return;

    addLog(`> ${cmd}`, "cmd");
    setInput("");

    if (cmd === "clear") {
      setLogs([]);
      return;
    }

    if (cmd === "mine") {
      setRunning(true);
      addLog("Spinning quantum fractal matrix...", "info");
      await new Promise((r) => setTimeout(r, 1200));
      addLog("Good-deed-as-a-service contracts discovered: 142", "success");
      await new Promise((r) => setTimeout(r, 800));
      addLog("Karma power points minted: +250", "success");
      addLog("MA tokens rewarded: +10.50 MA", "success");
      setRunning(false);
      return;
    }

    if (cmd === "release") {
      setRunning(true);
      addLog("Scanning high-demand product catalog...", "info");
      await new Promise((r) => setTimeout(r, 1000));
      addLog("Packaging superior digital products...", "info");
      await new Promise((r) => setTimeout(r, 1000));
      addLog("Released: Web3 SaaS Starter, MelodieLLM Agent, DAO Launchpad", "success");
      setRunning(false);
      return;
    }

    if (cmd === "treasury") {
      setRunning(true);
      addLog("Collecting revenue from sales contracts...", "info");
      await new Promise((r) => setTimeout(r, 1200));
      addLog("Rebalanced: 40% ETH, 35% USDT, 25% BTC", "success");
      addLog("Multi-sig treasury deposit confirmed", "success");
      setRunning(false);
      return;
    }

    if (cmd.startsWith("swap ")) {
      const parts = cmd.split(" ");
      const to = parts[1];
      const amt = parts[2];
      if (!to || !amt) {
        addLog("Usage: swap <eth|usdt|btc> <amount>", "error");
        return;
      }
      setRunning(true);
      addLog(`Initiating swap of ${amt} MA to ${to.toUpperCase()}...`, "info");
      await new Promise((r) => setTimeout(r, 1500));
      addLog(`Swap route found via decentralized aggregator`, "success");
      addLog(`Awaiting wallet confirmation...`, "warn");
      setRunning(false);
      return;
    }

    if (COMMANDS[cmd]) {
      COMMANDS[cmd].forEach((line) => addLog(line, "info"));
      return;
    }

    addLog(`Command not found: ${cmd}`, "error");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    runCommand(input);
  };

  const copyLogs = () => {
    navigator.clipboard.writeText(logs.map((l) => `${l.timestamp} ${l.text}`).join("\n"));
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const colorClass = {
    info: "text-slate-300",
    success: "text-emerald-400",
    warn: "text-amber-400",
    error: "text-rose-400",
    cmd: "text-cyan-400",
  };

  return (
    <div className="mx-auto max-w-6xl px-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-white md:text-4xl">
          Quantum <span className="text-gradient">Fractal CLI</span>
        </h1>
        <p className="mt-2 text-slate-400">
          Alpha Omega Beta Theta Delta Bravo Gamma tasklist execution engine.
        </p>
      </div>

      <div className="glass glow-cyan overflow-hidden rounded-3xl">
        <div className="flex items-center justify-between border-b border-white/10 bg-slate-900/60 px-5 py-3">
          <div className="flex items-center gap-2">
            <TerminalIcon className="h-5 w-5 text-cyan-400" />
            <span className="text-sm font-semibold text-white">metamello@quantum-fractal:~$</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={copyLogs}
              className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-white/10 hover:text-white"
              title="Copy logs"
            >
              {copied ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
            </button>
            <button
              onClick={() => setLogs(initialLogs)}
              className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-white/10 hover:text-white"
              title="Reset"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="h-[500px] overflow-y-auto bg-slate-950/70 p-5 font-mono text-sm">
          {logs.map((log) => (
            <div key={log.id} className="py-0.5">
              <span className="text-slate-600">{log.timestamp}</span>{" "}
              <span className={colorClass[log.type]}>{log.text}</span>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        <form
          onSubmit={handleSubmit}
          className="flex items-center gap-3 border-t border-white/10 bg-slate-900/60 px-5 py-4"
        >
          <span className="text-cyan-400 font-mono text-sm">$</span>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={running}
            placeholder="Enter command..."
            className="flex-1 bg-transparent font-mono text-sm text-white placeholder:text-slate-600 focus:outline-none"
          />
          <button
            type="submit"
            disabled={running || !input.trim()}
            className="flex items-center gap-2 rounded-lg bg-cyan-600 px-4 py-2 text-sm font-semibold text-white transition-all hover:bg-cyan-500 disabled:opacity-60"
          >
            {running ? <Play className="h-4 w-4 animate-pulse" /> : <Play className="h-4 w-4" />}
            Run
          </button>
        </form>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {["help", "status", "mine", "release", "workflows", "treasury", "swap eth 10", "clear"].map((cmd) => (
          <button
            key={cmd}
            onClick={() => runCommand(cmd)}
            className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-left text-xs font-mono text-slate-300 transition-all hover:border-cyan-500/30 hover:bg-white/10 hover:text-white"
          >
            {`> ${cmd}`}
          </button>
        ))}
      </div>
    </div>
  );
}
