"use client";

import { ethers } from "ethers";

declare global {
  interface Window {
    ethereum?: {
      request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
      on: (event: string, callback: (params: unknown) => void) => void;
      removeListener: (event: string, callback: (params: unknown) => void) => void;
    };
  }
}

export const SUPPORTED_CHAINS = [
  {
    id: 1,
    name: "Ethereum Mainnet",
    symbol: "ETH",
    rpc: "https://eth.llamarpc.com",
    explorer: "https://etherscan.io",
    nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
  },
  {
    id: 11155111,
    name: "Sepolia Testnet",
    symbol: "SEP",
    rpc: "https://rpc.sepolia.org",
    explorer: "https://sepolia.etherscan.io",
    nativeCurrency: { name: "Sepolia Ether", symbol: "SEP", decimals: 18 },
  },
  {
    id: 56,
    name: "BNB Smart Chain",
    symbol: "BNB",
    rpc: "https://bsc-dataseed.binance.org",
    explorer: "https://bscscan.com",
    nativeCurrency: { name: "BNB", symbol: "BNB", decimals: 18 },
  },
  {
    id: 137,
    name: "Polygon",
    symbol: "MATIC",
    rpc: "https://polygon.llamarpc.com",
    explorer: "https://polygonscan.com",
    nativeCurrency: { name: "MATIC", symbol: "MATIC", decimals: 18 },
  },
];

export const MA_TOKEN_ADDRESS = "0x0000000000000000000000000000000000000000";

export const ERC20_ABI = [
  "function balanceOf(address owner) view returns (uint256)",
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function transfer(address to, uint256 amount) returns (bool)",
  "function approve(address spender, uint256 amount) returns (bool)",
  "event Transfer(address indexed from, address indexed to, uint256 amount)",
];

export interface WalletState {
  address: string | null;
  chainId: number | null;
  balance: string;
  symbol: string;
  isConnected: boolean;
}

export async function connectWallet(): Promise<WalletState> {
  if (typeof window === "undefined" || !window.ethereum) {
    throw new Error("No Web3 wallet detected. Install MetaMask or Brave Wallet.");
  }

  const provider = new ethers.BrowserProvider(window.ethereum);
  const accounts = await provider.send("eth_requestAccounts", []);
  if (!accounts || accounts.length === 0) {
    throw new Error("No accounts authorized.");
  }

  const network = await provider.getNetwork();
  const signer = await provider.getSigner();
  const balanceWei = await provider.getBalance(signer.address);
  const symbol = network.name === "sepolia" ? "SEP" : "ETH";

  return {
    address: signer.address,
    chainId: Number(network.chainId),
    balance: ethers.formatEther(balanceWei),
    symbol,
    isConnected: true,
  };
}

export async function disconnectWallet(): Promise<WalletState> {
  return {
    address: null,
    chainId: null,
    balance: "0",
    symbol: "ETH",
    isConnected: false,
  };
}

export async function sendTransaction(
  to: string,
  amount: string
): Promise<string> {
  if (typeof window === "undefined" || !window.ethereum) {
    throw new Error("No Web3 wallet detected.");
  }
  const provider = new ethers.BrowserProvider(window.ethereum);
  const signer = await provider.getSigner();
  const tx = await signer.sendTransaction({
    to,
    value: ethers.parseEther(amount),
  });
  return tx.hash;
}

export function shortenAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function getExplorerUrl(chainId: number, hash: string): string {
  const chain = SUPPORTED_CHAINS.find((c) => c.id === chainId);
  if (!chain) return `#`;
  return `${chain.explorer}/tx/${hash}`;
}

export async function getEthPriceUsd(): Promise<number> {
  try {
    const res = await fetch(
      "https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd",
      { next: { revalidate: 60 } }
    );
    const data = await res.json();
    return data.ethereum.usd ?? 0;
  } catch {
    return 0;
  }
}
