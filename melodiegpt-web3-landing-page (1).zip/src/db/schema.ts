import {
  pgTable,
  serial,
  varchar,
  text,
  integer,
  timestamp,
  decimal,
  boolean,
  jsonb,
  uuid,
  bigint,
} from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  name: varchar("name", { length: 256 }).notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 64 }).notNull(),
  priceUsd: decimal("price_usd", { precision: 12, scale: 2 }).notNull(),
  priceMa: decimal("price_ma", { precision: 18, scale: 8 }).notNull(),
  imageUrl: text("image_url"),
  featured: boolean("featured").default(false),
  inStock: boolean("in_stock").default(true),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  name: varchar("name", { length: 256 }).notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 64 }).notNull(),
  priceUsd: decimal("price_usd", { precision: 12, scale: 2 }).notNull(),
  priceMa: decimal("price_ma", { precision: 18, scale: 8 }).notNull(),
  durationHours: integer("duration_hours"),
  featured: boolean("featured").default(false),
  active: boolean("active").default(true),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const workflows = pgTable("workflows", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 256 }).notNull(),
  description: text("description").notNull(),
  status: varchar("status", { length: 32 }).notNull().default("idle"),
  triggerType: varchar("trigger_type", { length: 64 }).notNull(),
  steps: jsonb("steps").notNull().default([]),
  karmaReward: integer("karma_reward").notNull().default(0),
  maReward: decimal("ma_reward", { precision: 18, scale: 8 }).notNull().default("0"),
  executedCount: integer("executed_count").default(0),
  lastExecutedAt: timestamp("last_executed_at", { withTimezone: true }),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const karmaTransactions = pgTable("karma_transactions", {
  id: serial("id").primaryKey(),
  walletAddress: varchar("wallet_address", { length: 64 }).notNull(),
  type: varchar("type", { length: 32 }).notNull(),
  amount: integer("amount").notNull(),
  reason: text("reason").notNull(),
  workflowId: integer("workflow_id"),
  txHash: varchar("tx_hash", { length: 128 }),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const orders = pgTable("orders", {
  id: uuid("id").defaultRandom().primaryKey(),
  walletAddress: varchar("wallet_address", { length: 64 }).notNull(),
  itemType: varchar("item_type", { length: 32 }).notNull(),
  itemId: integer("item_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  totalUsd: decimal("total_usd", { precision: 12, scale: 2 }).notNull(),
  totalMa: decimal("total_ma", { precision: 18, scale: 8 }).notNull(),
  status: varchar("status", { length: 32 }).notNull().default("pending"),
  txHash: varchar("tx_hash", { length: 128 }),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const cliLogs = pgTable("cli_logs", {
  id: serial("id").primaryKey(),
  sessionId: varchar("session_id", { length: 128 }).notNull(),
  level: varchar("level", { length: 16 }).notNull().default("info"),
  message: text("message").notNull(),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export type Product = typeof products.$inferSelect;
export type NewProduct = typeof products.$inferInsert;
export type Service = typeof services.$inferSelect;
export type NewService = typeof services.$inferInsert;
export type Workflow = typeof workflows.$inferSelect;
export type NewWorkflow = typeof workflows.$inferInsert;
export type KarmaTransaction = typeof karmaTransactions.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type CliLog = typeof cliLogs.$inferSelect;

export const agentSessions = pgTable("agent_sessions", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 256 }).notNull(),
  workspace: varchar("workspace", { length: 512 }).notNull().default("."),
  modelId: varchar("model_id", { length: 128 }).notNull(),
  providerId: varchar("provider_id", { length: 64 }).notNull(),
  status: varchar("status", { length: 32 }).notNull().default("active"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const agentMessages = pgTable("agent_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id").notNull(),
  role: varchar("role", { length: 32 }).notNull(),
  content: text("content").notNull(),
  modelId: varchar("model_id", { length: 128 }),
  providerId: varchar("provider_id", { length: 64 }),
  toolCalls: jsonb("tool_calls"),
  tokensIn: integer("tokens_in"),
  tokensOut: integer("tokens_out"),
  costUsd: decimal("cost_usd", { precision: 12, scale: 6 }),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const agentTasks = pgTable("agent_tasks", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id").notNull(),
  title: varchar("title", { length: 512 }).notNull(),
  description: text("description"),
  status: varchar("status", { length: 32 }).notNull().default("pending"),
  plan: jsonb("plan"),
  result: text("result"),
  error: text("error"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export const toolCalls = pgTable("tool_calls", {
  id: uuid("id").defaultRandom().primaryKey(),
  taskId: uuid("task_id"),
  sessionId: uuid("session_id"),
  toolName: varchar("tool_name", { length: 128 }).notNull(),
  arguments: jsonb("arguments").notNull(),
  result: jsonb("result"),
  error: text("error"),
  status: varchar("status", { length: 32 }).notNull().default("pending"),
  durationMs: integer("duration_ms"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const modelRequests = pgTable("model_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id"),
  taskId: uuid("task_id"),
  providerId: varchar("provider_id", { length: 64 }).notNull(),
  modelId: varchar("model_id", { length: 128 }).notNull(),
  tokensIn: integer("tokens_in"),
  tokensOut: integer("tokens_out"),
  costUsd: decimal("cost_usd", { precision: 12, scale: 6 }),
  durationMs: integer("duration_ms"),
  status: varchar("status", { length: 32 }).notNull().default("pending"),
  error: text("error"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const checkpoints = pgTable("checkpoints", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id").notNull(),
  name: varchar("name", { length: 256 }).notNull(),
  gitCommit: varchar("git_commit", { length: 128 }),
  fileSnapshot: jsonb("file_snapshot"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const auditEvents = pgTable("audit_events", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id"),
  taskId: uuid("task_id"),
  actor: varchar("actor", { length: 64 }).notNull(),
  action: varchar("action", { length: 128 }).notNull(),
  resource: varchar("resource", { length: 512 }),
  outcome: varchar("outcome", { length: 32 }).notNull(),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export type AgentSession = typeof agentSessions.$inferSelect;
export type AgentMessage = typeof agentMessages.$inferSelect;
export type AgentTask = typeof agentTasks.$inferSelect;
export type ToolCall = typeof toolCalls.$inferSelect;
export type ModelRequest = typeof modelRequests.$inferSelect;
export type Checkpoint = typeof checkpoints.$inferSelect;
export type AuditEvent = typeof auditEvents.$inferSelect;
