#!/usr/bin/env node
import { Command } from "commander";
import chalk from "chalk";
import ora from "ora";
import { providerRegistry } from "@/agent/providers/registry";
import { modelRouter } from "@/agent/providers/router";
import { verifyModels } from "@/agent/providers/verifier";
import { toolRegistry } from "@/agent/tools/registry";
import { runAgentLoop } from "@/agent/engine/loop";
import { WorkspaceSandbox } from "@/agent/security/sandbox";
import { DEFAULT_POLICIES } from "@/agent/security/policies";
import { execSync } from "child_process";
import { existsSync } from "fs";
import { join } from "path";
import { readFileSync } from "fs";

const program = new Command();

function readPackageVersion(): string {
  try {
    const pkg = JSON.parse(readFileSync(join(__dirname, "../../package.json"), "utf-8"));
    return pkg.version ?? "0.0.0";
  } catch {
    return "0.0.0";
  }
}

program.name("agent").description("MelodieGPT coding agent CLI").version(readPackageVersion());

program
  .command("doctor")
  .description("Verify platform health")
  .action(async () => {
    console.log(chalk.bold("Melodie Agent Doctor\n"));

    const checks = [
      { name: "Node.js", test: () => process.version },
      { name: "Working directory", test: () => process.cwd() },
      { name: "package.json", test: () => (existsSync("package.json") ? "present" : "missing") },
      { name: "Git", test: () => execSync("git --version", { encoding: "utf-8" }).trim() },
    ];

    for (const check of checks) {
      try {
        const result = check.test();
        console.log(`${chalk.green("✓")} ${check.name}: ${result}`);
      } catch (err) {
        console.log(`${chalk.red("✗")} ${check.name}: ${err instanceof Error ? err.message : String(err)}`);
      }
    }

    const providers = providerRegistry.list();
    console.log(chalk.bold("\nProviders"));
    for (const provider of providers) {
      const health = await provider.healthCheck();
      const configured = !!process.env[provider.config.apiKeyEnvVar];
      const icon = health.reachable && configured ? chalk.green("✓") : chalk.yellow("⚠");
      console.log(`${icon} ${provider.config.displayName}: ${health.status} (configured: ${configured})`);
    }

    const tools = toolRegistry.list();
    console.log(chalk.bold(`\nTools: ${tools.length} registered`));
  });

program
  .command("status")
  .description("Show platform status")
  .action(async () => {
    const status = {
      Platform: "OPERATIONAL",
      CLI: "OPERATIONAL",
      AgentEngine: "OPERATIONAL",
      ToolSystem: "OPERATIONAL",
      SecurityPolicies: "OPERATIONAL",
      RepositoryIndexing: "SCAFFOLD",
      IDE: "OPERATIONAL (web)",
    };
    console.log(chalk.bold("Melodie Agent Status\n"));
    for (const [k, v] of Object.entries(status)) {
      console.log(`${k.padEnd(24)} ${v}`);
    }
  });

program
  .command("models")
  .description("List configured models")
  .option("--verify", "Verify provider connectivity and model availability")
  .action(async (opts) => {
    if (opts.verify) {
      const spinner = ora("Verifying models...").start();
      const results = await verifyModels();
      spinner.stop();
      console.table(
        results.map((r) => ({
          Model: r.model,
          Provider: r.provider,
          Configured: r.configured ? "YES" : "NO",
          Reachable: r.reachable ? "YES" : "NO",
          Status: r.status,
        }))
      );
    } else {
      const all = await modelRouter.listAllModels();
      console.table(
        all.map((m) => ({
          Model: m.displayName,
          Provider: m.provider,
          Context: m.capabilities.contextWindow,
          Tools: m.capabilities.supportsTools ? "YES" : "NO",
          Streaming: m.capabilities.supportsStreaming ? "YES" : "NO",
        }))
      );
    }
  });

program
  .command("providers")
  .description("List registered providers")
  .action(() => {
    const providers = providerRegistry.list();
    console.table(
      providers.map((p) => ({
        ID: p.config.id,
        Name: p.config.displayName,
        EnvVar: p.config.apiKeyEnvVar,
        Configured: !!process.env[p.config.apiKeyEnvVar] ? "YES" : "NO",
      }))
    );
  });

program
  .command("tools")
  .description("List available tools")
  .action(() => {
    const tools = toolRegistry.list();
    for (const tool of tools) {
      console.log(`${chalk.cyan(tool.name)} — ${tool.description}`);
    }
  });

program
  .command("chat <message>")
  .description("Send a one-off chat message to the default model")
  .option("-m, --model <model>", "Model ID", "openrouter/auto")
  .action(async (message, opts) => {
    const spinner = ora("Thinking...").start();
    try {
      const res = await modelRouter.chat({
        model: opts.model,
        messages: [{ role: "user", content: message }],
      });
      spinner.stop();
      console.log(chalk.green(res.content));
      console.log(chalk.gray(`\nModel: ${res.model} | Provider: ${res.provider} | Tokens: ${res.usage.totalTokens}`));
    } catch (err) {
      spinner.stop();
      console.error(chalk.red(err instanceof Error ? err.message : String(err)));
      process.exit(1);
    }
  });

program
  .command("code <task>")
  .description("Run an autonomous coding task")
  .option("-m, --model <model>", "Model ID", "openrouter/auto")
  .option("-w, --workspace <path>", "Workspace path", process.cwd())
  .action(async (task, opts) => {
    console.log(chalk.bold("Task:") + ` ${task}`);
    const result = await runAgentLoop({
      task,
      workspace: opts.workspace,
      sessionId: `cli-${Date.now()}`,
      model: opts.model,
      onUpdate: (u) => console.log(chalk.gray(`[${u.type}] ${u.content.slice(0, 200)}`)),
    });

    console.log(chalk.bold("\nResult:"));
    console.log(result.output);
    if (result.filesModified?.length) {
      console.log(chalk.bold("\nFiles modified:"));
      result.filesModified.forEach((f) => console.log(`  ${f}`));
    }
    process.exit(result.success ? 0 : 1);
  });

program
  .command("run <command>")
  .description("Execute a shell command through the agent sandbox")
  .option("-w, --workspace <path>", "Workspace path", process.cwd())
  .action(async (cmd, opts) => {
    const sandbox = new WorkspaceSandbox();
    const ctx = sandbox.createContext(`cli-${Date.now()}`, opts.workspace);
    const decision = ctx.policies.shell ? "allow" : "deny";
    if (decision === "deny") {
      console.error(chalk.red("Command denied"));
      process.exit(1);
    }
    const result = await toolRegistry.execute(
      { id: "run", name: "shell.execute", arguments: { command: cmd } },
      ctx
    );
    console.log(result.output);
    if (result.error) {
      console.error(chalk.red(result.error));
      process.exit(1);
    }
  });

program
  .command("index")
  .description("Index the workspace for repository-aware context")
  .action(() => {
    console.log(chalk.yellow("Repository indexing is SCAFFOLD — implement tree-sitter or AST parser integration."));
  });

program
  .command("sessions")
  .description("List active sessions")
  .action(() => {
    console.log(chalk.yellow("Session persistence is SCAFFOLD — implement database-backed session store."));
  });

program
  .command("costs")
  .description("Show cost estimates")
  .action(() => {
    console.log(chalk.yellow("Cost tracking is SCAFFOLD — implement model_requests aggregation."));
  });

program
  .command("audit")
  .description("Show audit log")
  .action(() => {
    console.log(chalk.yellow("Audit log is SCAFFOLD — implement audit_events table query."));
  });

program.parse();
