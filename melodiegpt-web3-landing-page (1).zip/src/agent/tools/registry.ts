import { filesystemTools } from "./filesystem";
import { shellTool } from "./shell";
import { gitTools } from "./git";
import { codeTools } from "./code";
import type { Tool, ToolContext, ToolResult, ToolCallRequest } from "@/agent/types";

export class ToolRegistry {
  private tools: Map<string, Tool> = new Map();

  constructor() {
    [...filesystemTools, shellTool, ...gitTools, ...codeTools].forEach((t) => this.register(t));
  }

  register(tool: Tool): void {
    this.tools.set(tool.name, tool);
  }

  get(name: string): Tool | undefined {
    return this.tools.get(name);
  }

  list(): Tool[] {
    return Array.from(this.tools.values());
  }

  schemas(): Array<{ name: string; description: string; parameters: Tool["parameters"] }> {
    return this.list().map((t) => ({
      name: t.name,
      description: t.description,
      parameters: t.parameters,
    }));
  }

  async execute(call: ToolCallRequest, ctx: ToolContext): Promise<ToolResult> {
    const tool = this.tools.get(call.name);
    if (!tool) {
      return {
        toolCallId: call.id,
        name: call.name,
        output: "",
        error: `Tool ${call.name} not found`,
        durationMs: 0,
      };
    }

    const decision = tool.authorize(call.arguments, ctx);
    if (decision === "deny") {
      return {
        toolCallId: call.id,
        name: call.name,
        output: "",
        error: "denied by security policy",
        durationMs: 0,
      };
    }
    if (decision === "confirm") {
      // In CLI mode, confirm automatically for now; IDE should prompt.
    }

    const start = Date.now();
    try {
      const result = await tool.execute(call.arguments, ctx);
      result.toolCallId = call.id;
      return result;
    } catch (err) {
      return {
        toolCallId: call.id,
        name: call.name,
        output: "",
        error: err instanceof Error ? err.message : String(err),
        durationMs: Date.now() - start,
      };
    }
  }
}

export const toolRegistry = new ToolRegistry();
