import { spawn } from "child_process";
import type { Tool, ToolContext, ToolResult } from "@/agent/types";
import { classifyShellCommand } from "@/agent/security/policies";

export const shellTool: Tool = {
  name: "shell.execute",
  description: "Execute a shell command in the workspace with timeout",
  parameters: {
    type: "object",
    properties: {
      command: { type: "string", description: "Shell command to execute" },
      timeoutMs: { type: "number", description: "Timeout in milliseconds" },
    },
    required: ["command"],
  },
  authorize(args, ctx) {
    return classifyShellCommand(String(args.command ?? ""), ctx.policies);
  },
  async execute(args, ctx): Promise<ToolResult> {
    const start = Date.now();
    const command = String(args.command ?? "");
    const decision = classifyShellCommand(command, ctx.policies);

    if (decision === "deny") {
      return {
        toolCallId: "",
        name: "shell.execute",
        output: "",
        error: "Command denied by security policy",
        durationMs: Date.now() - start,
      };
    }

    const timeout = Number(args.timeoutMs ?? ctx.policies.shell.timeoutMs);

    return new Promise((resolve) => {
      const [cmd, ...cmdArgs] = command.split(" ");
      const child = spawn(cmd, cmdArgs, {
        cwd: ctx.workspace,
        shell: true,
        env: { ...process.env, PATH: process.env.PATH },
      });

      let stdout = "";
      let stderr = "";
      let killed = false;

      const timer = setTimeout(() => {
        killed = true;
        child.kill("SIGTERM");
      }, timeout);

      child.stdout?.on("data", (data) => {
        stdout += data.toString();
      });

      child.stderr?.on("data", (data) => {
        stderr += data.toString();
      });

      child.on("close", (code) => {
        clearTimeout(timer);
        const output = stdout + (stderr ? `\n[stderr]\n${stderr}` : "");
        ctx.log("shell.execute", command, code === 0 ? "success" : "failure", { exitCode: code });
        resolve({
          toolCallId: "",
          name: "shell.execute",
          output: output.slice(0, 10000),
          error: killed ? `Timeout after ${timeout}ms` : code !== 0 ? `Exit code ${code}` : undefined,
          durationMs: Date.now() - start,
        });
      });

      child.on("error", (err) => {
        clearTimeout(timer);
        resolve({
          toolCallId: "",
          name: "shell.execute",
          output: "",
          error: err.message,
          durationMs: Date.now() - start,
        });
      });
    });
  },
};
