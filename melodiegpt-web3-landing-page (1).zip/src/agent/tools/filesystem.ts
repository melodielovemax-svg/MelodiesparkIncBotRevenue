import { readFile, writeFile, unlink, readdir, stat, mkdir } from "fs/promises";
import { join, resolve } from "path";
import type { Tool, ToolContext, ToolResult } from "@/agent/types";

function safePath(input: unknown, workspace: string): string {
  if (typeof input !== "string") throw new Error("path must be a string");
  const target = resolve(workspace, input);
  if (!target.startsWith(resolve(workspace))) throw new Error("Path escapes workspace");
  return target;
}

export const filesystemTools: Tool[] = [
  {
    name: "filesystem.read",
    description: "Read the contents of a file",
    parameters: {
      type: "object",
      properties: {
        path: { type: "string", description: "Relative path to file" },
      },
      required: ["path"],
    },
    authorize(args, ctx) {
      return ctx.policies.filesystem.allowedPaths.length > 0 ? "allow" : "deny";
    },
    async execute(args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const path = safePath(args.path, ctx.workspace);
        if (!ctx.policies.filesystem.allowedPaths.some((p) => path.startsWith(resolve(p)))) {
          throw new Error("Path not allowed by policy");
        }
        const content = await readFile(path, "utf-8");
        ctx.log("filesystem.read", path, "success", { size: content.length });
        return { toolCallId: "", name: "filesystem.read", output: content, durationMs: Date.now() - start };
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        return { toolCallId: "", name: "filesystem.read", output: "", error: msg, durationMs: Date.now() - start };
      }
    },
  },
  {
    name: "filesystem.write",
    description: "Write content to a file",
    parameters: {
      type: "object",
      properties: {
        path: { type: "string" },
        content: { type: "string" },
      },
      required: ["path", "content"],
    },
    authorize() {
      return "allow";
    },
    async execute(args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const path = safePath(args.path, ctx.workspace);
        await mkdir(path.split("/").slice(0, -1).join("/"), { recursive: true });
        await writeFile(path, String(args.content), "utf-8");
        ctx.log("filesystem.write", path, "success", { size: String(args.content).length });
        return { toolCallId: "", name: "filesystem.write", output: `Wrote ${path}`, durationMs: Date.now() - start };
      } catch (err) {
        return { toolCallId: "", name: "filesystem.write", output: "", error: err instanceof Error ? err.message : String(err), durationMs: Date.now() - start };
      }
    },
  },
  {
    name: "filesystem.delete",
    description: "Delete a file",
    parameters: {
      type: "object",
      properties: { path: { type: "string" } },
      required: ["path"],
    },
    authorize() {
      return "confirm";
    },
    async execute(args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const path = safePath(args.path, ctx.workspace);
        await unlink(path);
        ctx.log("filesystem.delete", path, "success", {});
        return { toolCallId: "", name: "filesystem.delete", output: `Deleted ${path}`, durationMs: Date.now() - start };
      } catch (err) {
        return { toolCallId: "", name: "filesystem.delete", output: "", error: err instanceof Error ? err.message : String(err), durationMs: Date.now() - start };
      }
    },
  },
  {
    name: "filesystem.list",
    description: "List files in a directory",
    parameters: {
      type: "object",
      properties: { path: { type: "string" } },
      required: ["path"],
    },
    authorize() {
      return "allow";
    },
    async execute(args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const path = safePath(args.path, ctx.workspace);
        const entries = await readdir(path, { withFileTypes: true });
        const output = entries.map((e) => `${e.isDirectory() ? "DIR" : "FILE"} ${e.name}`).join("\n");
        return { toolCallId: "", name: "filesystem.list", output, durationMs: Date.now() - start };
      } catch (err) {
        return { toolCallId: "", name: "filesystem.list", output: "", error: err instanceof Error ? err.message : String(err), durationMs: Date.now() - start };
      }
    },
  },
  {
    name: "filesystem.search",
    description: "Search file names in workspace",
    parameters: {
      type: "object",
      properties: { pattern: { type: "string" } },
      required: ["pattern"],
    },
    authorize() {
      return "allow";
    },
    async execute(args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const { execSync } = await import("child_process");
        const pattern = String(args.pattern).replace(/'/g, "'\\''");
        const output = execSync(`find '${ctx.workspace}' -type f -name '${pattern}' | head -50`, { encoding: "utf-8" });
        return { toolCallId: "", name: "filesystem.search", output: output || "No matches", durationMs: Date.now() - start };
      } catch (err) {
        return { toolCallId: "", name: "filesystem.search", output: "", error: err instanceof Error ? err.message : String(err), durationMs: Date.now() - start };
      }
    },
  },
];
