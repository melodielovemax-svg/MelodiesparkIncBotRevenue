import { execSync } from "child_process";
import type { Tool, ToolContext, ToolResult } from "@/agent/types";

function runGit(args: string, cwd: string): string {
  return execSync(`git ${args}`, { cwd, encoding: "utf-8", stdio: ["pipe", "pipe", "pipe"] });
}

export const gitTools: Tool[] = [
  {
    name: "git.status",
    description: "Get git status",
    parameters: { type: "object", properties: {}, required: [] },
    authorize() {
      return "allow";
    },
    execute(_args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const output = runGit("status --short", ctx.workspace);
        return Promise.resolve({ toolCallId: "", name: "git.status", output: output || "Clean", durationMs: Date.now() - start });
      } catch (err) {
        return Promise.resolve({ toolCallId: "", name: "git.status", output: "", error: err instanceof Error ? err.message : String(err), durationMs: Date.now() - start });
      }
    },
  },
  {
    name: "git.diff",
    description: "Show git diff",
    parameters: { type: "object", properties: {}, required: [] },
    authorize() {
      return "allow";
    },
    execute(_args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const output = runGit("diff", ctx.workspace);
        return Promise.resolve({ toolCallId: "", name: "git.diff", output: output || "No diff", durationMs: Date.now() - start });
      } catch (err) {
        return Promise.resolve({ toolCallId: "", name: "git.diff", output: "", error: err instanceof Error ? err.message : String(err), durationMs: Date.now() - start });
      }
    },
  },
  {
    name: "git.log",
    description: "Show recent git log",
    parameters: { type: "object", properties: { count: { type: "number" } }, required: [] },
    authorize() {
      return "allow";
    },
    execute(args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const count = Number(args.count ?? 10);
        const output = runGit(`log -${count} --oneline`, ctx.workspace);
        return Promise.resolve({ toolCallId: "", name: "git.log", output, durationMs: Date.now() - start });
      } catch (err) {
        return Promise.resolve({ toolCallId: "", name: "git.log", output: "", error: err instanceof Error ? err.message : String(err), durationMs: Date.now() - start });
      }
    },
  },
  {
    name: "git.commit",
    description: "Create a git commit",
    parameters: {
      type: "object",
      properties: { message: { type: "string" } },
      required: ["message"],
    },
    authorize() {
      return "confirm";
    },
    execute(args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const message = String(args.message).replace(/'/g, "'\\''");
        runGit("add -A", ctx.workspace);
        const output = runGit(`commit -m '${message}'`, ctx.workspace);
        return Promise.resolve({ toolCallId: "", name: "git.commit", output, durationMs: Date.now() - start });
      } catch (err) {
        return Promise.resolve({ toolCallId: "", name: "git.commit", output: "", error: err instanceof Error ? err.message : String(err), durationMs: Date.now() - start });
      }
    },
  },
];
