import { execSync } from "child_process";
import type { Tool, ToolContext, ToolResult } from "@/agent/types";

export const codeTools: Tool[] = [
  {
    name: "code.search",
    description: "Search code with grep",
    parameters: {
      type: "object",
      properties: { pattern: { type: "string" }, path: { type: "string" } },
      required: ["pattern"],
    },
    authorize() {
      return "allow";
    },
    execute(args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const pattern = String(args.pattern).replace(/'/g, "'\\''");
        const path = args.path ? String(args.path).replace(/'/g, "'\\''") : ctx.workspace;
        const output = execSync(`grep -RIn '${pattern}' '${path}' --include='*.ts' --include='*.tsx' --include='*.js' --include='*.json' 2>/dev/null | head -50`, { encoding: "utf-8" });
        return Promise.resolve({ toolCallId: "", name: "code.search", output: output || "No matches", durationMs: Date.now() - start });
      } catch (err) {
        return Promise.resolve({ toolCallId: "", name: "code.search", output: "", error: err instanceof Error ? err.message : String(err), durationMs: Date.now() - start });
      }
    },
  },
  {
    name: "test.run",
    description: "Run project tests",
    parameters: { type: "object", properties: { pattern: { type: "string" } }, required: [] },
    authorize() {
      return "allow";
    },
    execute(args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const cmd = args.pattern ? `npm test -- ${args.pattern}` : "npm test";
        const output = execSync(cmd, { cwd: ctx.workspace, encoding: "utf-8", timeout: 120000 });
        return Promise.resolve({ toolCallId: "", name: "test.run", output: output.slice(0, 10000), durationMs: Date.now() - start });
      } catch (err) {
        const error = err instanceof Error ? err : new Error(String(err));
        const stdout = (err as { stdout?: string }).stdout ?? "";
        return Promise.resolve({ toolCallId: "", name: "test.run", output: stdout.slice(0, 10000), error: error.message, durationMs: Date.now() - start });
      }
    },
  },
  {
    name: "build.run",
    description: "Run project build",
    parameters: { type: "object", properties: {}, required: [] },
    authorize() {
      return "allow";
    },
    execute(_args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const output = execSync("npm run build", { cwd: ctx.workspace, encoding: "utf-8", timeout: 300000 });
        return Promise.resolve({ toolCallId: "", name: "build.run", output: output.slice(0, 10000), durationMs: Date.now() - start });
      } catch (err) {
        const error = err instanceof Error ? err : new Error(String(err));
        const stdout = (err as { stdout?: string }).stdout ?? "";
        return Promise.resolve({ toolCallId: "", name: "build.run", output: stdout.slice(0, 10000), error: error.message, durationMs: Date.now() - start });
      }
    },
  },
  {
    name: "lint.run",
    description: "Run project lint",
    parameters: { type: "object", properties: {}, required: [] },
    authorize() {
      return "allow";
    },
    execute(_args, ctx): Promise<ToolResult> {
      const start = Date.now();
      try {
        const output = execSync("npm run lint", { cwd: ctx.workspace, encoding: "utf-8", timeout: 120000 });
        return Promise.resolve({ toolCallId: "", name: "lint.run", output: output.slice(0, 10000), durationMs: Date.now() - start });
      } catch (err) {
        const error = err instanceof Error ? err : new Error(String(err));
        const stdout = (err as { stdout?: string }).stdout ?? "";
        return Promise.resolve({ toolCallId: "", name: "lint.run", output: stdout.slice(0, 10000), error: error.message, durationMs: Date.now() - start });
      }
    },
  },
];
