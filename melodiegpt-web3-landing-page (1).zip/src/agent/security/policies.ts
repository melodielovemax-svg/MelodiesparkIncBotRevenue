import type { SecurityPolicies } from "@/agent/types";

export const DEFAULT_POLICIES: SecurityPolicies = {
  filesystem: {
    allowedPaths: [process.cwd()],
    deniedPaths: [
      "/etc",
      "/usr",
      "/bin",
      "/sbin",
      "/root",
      "/sys",
      "/proc",
      "/dev",
    ],
    allowDelete: true,
  },
  shell: {
    allowedCommands: ["ls", "cat", "echo", "grep", "find", "npm", "npx", "node", "git", "tsc", "vitest", "jest"],
    deniedCommands: ["rm -rf /", "format", "mkfs", "dd", "sudo", "su"],
    requireConfirmation: ["git push", "git reset", "rm -rf"],
    timeoutMs: 60000,
    maxConcurrent: 4,
  },
  network: {
    allowedHosts: ["api.openai.com", "openrouter.ai", "api.mistral.ai", "neuroapi.host"],
    blockedHosts: [],
  },
};

export function classifyShellCommand(command: string, policies: SecurityPolicies): "allow" | "confirm" | "deny" {
  const normalized = command.toLowerCase().trim();
  if (policies.shell.deniedCommands.some((c) => normalized.includes(c.toLowerCase()))) {
    return "deny";
  }
  if (policies.shell.requireConfirmation.some((c) => normalized.includes(c.toLowerCase()))) {
    return "confirm";
  }
  if (policies.shell.allowedCommands.some((c) => normalized.startsWith(c.toLowerCase()))) {
    return "allow";
  }
  return "confirm";
}

export function isPathAllowed(targetPath: string, policies: SecurityPolicies): boolean {
  const normalized = targetPath.replace(/\\/g, "/");
  if (policies.filesystem.deniedPaths.some((p) => normalized.startsWith(p))) return false;
  if (policies.filesystem.allowedPaths.some((p) => normalized.startsWith(p.replace(/\\/g, "/")))) return true;
  return false;
}
