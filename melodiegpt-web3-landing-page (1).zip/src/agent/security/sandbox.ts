import { isPathAllowed, classifyShellCommand, DEFAULT_POLICIES } from "./policies";
import type { SecurityPolicies, ToolContext } from "@/agent/types";

export class WorkspaceSandbox {
  constructor(private policies: SecurityPolicies = DEFAULT_POLICIES) {}

  authorizeRead(path: string): boolean {
    return isPathAllowed(path, this.policies);
  }

  authorizeWrite(path: string): boolean {
    return isPathAllowed(path, this.policies);
  }

  authorizeDelete(path: string): boolean {
    return this.policies.filesystem.allowDelete && isPathAllowed(path, this.policies);
  }

  authorizeShell(command: string): "allow" | "confirm" | "deny" {
    return classifyShellCommand(command, this.policies);
  }

  createContext(sessionId: string, workspace: string, taskId?: string): ToolContext {
    return {
      workspace,
      sessionId,
      taskId,
      policies: this.policies,
      log: (action, resource, outcome, meta) => {
        // In a real system, persist to audit_events table.
        console.log(`[AUDIT] ${action} ${resource} -> ${outcome}`, meta ?? {});
      },
    };
  }
}
