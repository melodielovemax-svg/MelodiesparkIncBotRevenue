export interface ModelCapabilities {
  supportsStreaming: boolean;
  supportsTools: boolean;
  supportsVision: boolean;
  supportsJson: boolean;
  supportsCode: boolean;
  contextWindow: number;
}

export interface ModelInfo {
  id: string;
  provider: string;
  displayName: string;
  canonicalProviderId: string;
  legacyAliases: string[];
  availability: "available" | "unavailable" | "unknown" | "blocked";
  capabilities: ModelCapabilities;
  pricing: {
    inputTokensPerMillion: number;
    outputTokensPerMillion: number;
  };
}

export interface ProviderConfig {
  id: string;
  displayName: string;
  apiKeyEnvVar: string;
  baseUrl?: string;
  enabled: boolean;
}

export interface Message {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  toolCalls?: ToolCallRequest[];
  toolCallId?: string;
}

export interface ToolCallRequest {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
}

export interface ToolResult {
  toolCallId: string;
  name: string;
  output: string;
  error?: string;
  durationMs: number;
}

export interface ChatOptions {
  model: string;
  messages: Message[];
  temperature?: number;
  maxTokens?: number;
  tools?: ToolSchema[];
  stream?: boolean;
}

export interface ChatResponse {
  content: string;
  toolCalls?: ToolCallRequest[];
  usage: {
    inputTokens: number;
    outputTokens: number;
    cachedTokens?: number;
    totalTokens: number;
  };
  model: string;
  provider: string;
  durationMs: number;
}

export interface ToolSchema {
  name: string;
  description: string;
  parameters: {
    type: string;
    properties: Record<string, unknown>;
    required?: string[];
  };
}

export interface Tool {
  name: string;
  description: string;
  parameters: ToolSchema["parameters"];
  authorize: (args: Record<string, unknown>, ctx: ToolContext) => "allow" | "confirm" | "deny";
  execute: (args: Record<string, unknown>, ctx: ToolContext) => Promise<ToolResult>;
}

export interface ToolContext {
  workspace: string;
  sessionId: string;
  taskId?: string;
  policies: SecurityPolicies;
  log: (action: string, resource: string, outcome: string, meta?: Record<string, unknown>) => void;
}

export interface SecurityPolicies {
  filesystem: {
    allowedPaths: string[];
    deniedPaths: string[];
    allowDelete: boolean;
  };
  shell: {
    allowedCommands: string[];
    deniedCommands: string[];
    requireConfirmation: string[];
    timeoutMs: number;
    maxConcurrent: number;
  };
  network: {
    allowedHosts: string[];
    blockedHosts: string[];
  };
}

export interface AgentPlan {
  steps: string[];
}

export interface TaskResult {
  success: boolean;
  output: string;
  error?: string;
  filesModified?: string[];
  testsRun?: boolean;
  testResults?: string;
}

export interface CheckpointData {
  id: string;
  name: string;
  createdAt: Date;
  gitCommit?: string;
  files: Record<string, string>;
}
