import assert from "node:assert";
import test from "node:test";
import { classifyShellCommand, isPathAllowed, DEFAULT_POLICIES } from "@/agent/security/policies";

test("classifyShellCommand denies destructive commands", () => {
  assert.strictEqual(classifyShellCommand("rm -rf /", DEFAULT_POLICIES), "deny");
  assert.strictEqual(classifyShellCommand("format disk", DEFAULT_POLICIES), "deny");
});

test("classifyShellCommand requires confirmation for risky git commands", () => {
  assert.strictEqual(classifyShellCommand("git push origin main", DEFAULT_POLICIES), "confirm");
  assert.strictEqual(classifyShellCommand("git reset --hard HEAD", DEFAULT_POLICIES), "confirm");
});

test("classifyShellCommand allows safe commands", () => {
  assert.strictEqual(classifyShellCommand("npm test", DEFAULT_POLICIES), "allow");
  assert.strictEqual(classifyShellCommand("git status", DEFAULT_POLICIES), "allow");
});

test("isPathAllowed blocks system paths", () => {
  assert.strictEqual(isPathAllowed("/etc/passwd", DEFAULT_POLICIES), false);
  assert.strictEqual(isPathAllowed("/root/.ssh", DEFAULT_POLICIES), false);
});

test("isPathAllowed allows workspace paths", () => {
  assert.strictEqual(isPathAllowed(process.cwd(), DEFAULT_POLICIES), true);
  assert.strictEqual(isPathAllowed(`${process.cwd()}/src/index.ts`, DEFAULT_POLICIES), true);
});
