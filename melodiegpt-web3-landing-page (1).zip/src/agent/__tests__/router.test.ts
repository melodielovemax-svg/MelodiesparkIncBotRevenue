import assert from "node:assert";
import test from "node:test";
import { providerRegistry } from "@/agent/providers/registry";
import { ModelRouter } from "@/agent/providers/router";

test("router resolves provider for OpenAI model", async () => {
  const router = new ModelRouter(providerRegistry);
  const { provider, modelId } = await router.resolveProvider("openai/gpt-4-turbo");
  assert.strictEqual(provider.config.id, "openai");
  assert.strictEqual(modelId, "openai/gpt-4-turbo");
});

test("router resolves provider for OpenRouter auto", async () => {
  const router = new ModelRouter(providerRegistry);
  const { provider, modelId } = await router.resolveProvider("openrouter/auto");
  assert.strictEqual(provider.config.id, "openrouter");
  assert.strictEqual(modelId, "openrouter/auto");
});

test("router resolves provider for Mistral model", async () => {
  const router = new ModelRouter(providerRegistry);
  const { provider, modelId } = await router.resolveProvider("mistralai/mistral-large");
  assert.strictEqual(provider.config.id, "mistral");
});
