import assert from "node:assert";
import test from "node:test";
import { toolRegistry } from "@/agent/tools/registry";
import { WorkspaceSandbox } from "@/agent/security/sandbox";
import { mkdtempSync, writeFileSync, existsSync } from "fs";
import { tmpdir } from "os";
import { join } from "path";

test("tool registry contains required tools", () => {
  const names = toolRegistry.list().map((t) => t.name);
  assert.ok(names.includes("filesystem.read"));
  assert.ok(names.includes("filesystem.write"));
  assert.ok(names.includes("filesystem.delete"));
  assert.ok(names.includes("filesystem.list"));
  assert.ok(names.includes("shell.execute"));
  assert.ok(names.includes("git.status"));
  assert.ok(names.includes("code.search"));
  assert.ok(names.includes("test.run"));
});

test("filesystem.write creates file in workspace", async () => {
  const dir = mkdtempSync(join(tmpdir(), "agent-test-"));
  const sandbox = new WorkspaceSandbox();
  const ctx = sandbox.createContext("test", dir);

  const result = await toolRegistry.execute(
    { id: "1", name: "filesystem.write", arguments: { path: "hello.txt", content: "world" } },
    ctx
  );

  assert.strictEqual(result.error, undefined);
  assert.ok(existsSync(join(dir, "hello.txt")));
});

test("shell.execute runs echo command", async () => {
  const dir = mkdtempSync(join(tmpdir(), "agent-test-"));
  const sandbox = new WorkspaceSandbox();
  const ctx = sandbox.createContext("test", dir);

  const result = await toolRegistry.execute(
    { id: "2", name: "shell.execute", arguments: { command: "echo melodie" } },
    ctx
  );

  assert.strictEqual(result.error, undefined);
  assert.ok(result.output.includes("melodie"));
});

test("denied shell command returns error", async () => {
  const dir = mkdtempSync(join(tmpdir(), "agent-test-"));
  const sandbox = new WorkspaceSandbox();
  const ctx = sandbox.createContext("test", dir);

  const result = await toolRegistry.execute(
    { id: "3", name: "shell.execute", arguments: { command: "rm -rf /" } },
    ctx
  );

  assert.ok(result.error);
  assert.ok(result.error?.includes("denied"));
});
