import assert from "node:assert";
import test from "node:test";
import { providerRegistry } from "@/agent/providers/registry";
import { OpenAIProvider } from "@/agent/providers/openai";
import { OpenRouterProvider } from "@/agent/providers/openrouter";
import { MistralProvider } from "@/agent/providers/mistral";

test("provider registry contains expected providers", () => {
  const ids = providerRegistry.list().map((p) => p.config.id);
  assert.ok(ids.includes("openai"));
  assert.ok(ids.includes("openrouter"));
  assert.ok(ids.includes("mistral"));
  assert.ok(ids.includes("mancer"));
  assert.ok(ids.includes("undi95"));
  assert.ok(ids.includes("gryphe"));
});

test("OpenAI provider lists requested legacy models", async () => {
  const p = new OpenAIProvider();
  const models = await p.listModels();
  const ids = models.map((m) => m.id);
  assert.ok(ids.includes("openai/gpt-4-turbo"));
  assert.ok(ids.includes("openai/gpt-4"));
  assert.ok(ids.includes("openai/gpt-3.5-turbo"));
  assert.ok(ids.includes("openai/gpt-3.5-turbo-16k"));
  assert.ok(ids.includes("openai/gpt-3.5-turbo-instruct"));
});

test("OpenRouter provider includes auto router", async () => {
  const p = new OpenRouterProvider();
  const models = await p.listModels();
  assert.ok(models.some((m) => m.id === "openrouter/auto"));
});

test("healthCheck reports NO_API_KEY when key missing", async () => {
  const p = new OpenAIProvider();
  delete process.env.OPENAI_API_KEY;
  const health = await p.healthCheck();
  assert.strictEqual(health.status, "NO_API_KEY");
  assert.strictEqual(health.reachable, false);
});

test("cost estimation returns non-negative number", () => {
  const p = new OpenAIProvider();
  const cost = p.estimateCost("openai/gpt-4-turbo", 1_000_000, 500_000);
  assert.ok(cost > 0);
});
