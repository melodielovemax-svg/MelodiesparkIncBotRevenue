import { providerRegistry } from "./registry";
import type { ModelInfo } from "@/agent/types";

export interface VerificationResult {
  model: string;
  provider: string;
  configured: boolean;
  reachable: boolean;
  available: boolean;
  tools: boolean;
  streaming: boolean;
  context: number;
  status: "OPERATIONAL" | "BLOCKED" | "UNVERIFIED" | "NO_API_KEY" | "UNAVAILABLE";
  reason?: string;
}

export async function verifyModels(): Promise<VerificationResult[]> {
  const providers = providerRegistry.list();
  const results: VerificationResult[] = [];

  for (const provider of providers) {
    const health = await provider.healthCheck();
    const models = await provider.listModels();

    for (const model of models) {
      const configured = !!process.env[provider.config.apiKeyEnvVar];
      const reachable = health.reachable;
      const available = configured && reachable;

      let status: VerificationResult["status"] = "UNVERIFIED";
      let reason: string | undefined;

      if (!configured) {
        status = "NO_API_KEY";
        reason = `${provider.config.apiKeyEnvVar} not set`;
      } else if (!reachable) {
        status = "BLOCKED";
        reason = health.error ?? "Provider unreachable";
      } else if (model.availability === "unavailable") {
        status = "UNAVAILABLE";
        reason = "Provider reports model unavailable";
      } else if (model.availability === "available") {
        status = "OPERATIONAL";
      }

      results.push({
        model: model.displayName,
        provider: provider.config.displayName,
        configured,
        reachable,
        available,
        tools: model.capabilities.supportsTools,
        streaming: model.capabilities.supportsStreaming,
        context: model.capabilities.contextWindow,
        status,
        reason,
      });
    }
  }

  return results;
}
