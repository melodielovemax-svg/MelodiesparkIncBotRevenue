import type { ModelProvider } from "./base";
import type { ChatOptions, ChatResponse, Message, ModelInfo, ProviderConfig } from "@/agent/types";

const CONFIG: ProviderConfig = {
  id: "mancer",
  displayName: "Mancer",
  apiKeyEnvVar: "MANCER_API_KEY",
  baseUrl: "https://neuroapi.host/v1",
  enabled: false,
};

const MODELS: ModelInfo[] = [
  {
    id: "mancer/weaver",
    provider: "mancer",
    displayName: "Mancer Weaver",
    canonicalProviderId: "weaver",
    legacyAliases: [],
    availability: "unknown",
    capabilities: {
      supportsStreaming: true,
      supportsTools: false,
      supportsVision: false,
      supportsJson: false,
      supportsCode: true,
      contextWindow: 8192,
    },
    pricing: { inputTokensPerMillion: 0, outputTokensPerMillion: 0 },
  },
];

export class MancerProvider implements ModelProvider {
  readonly config = CONFIG;

  async listModels(): Promise<ModelInfo[]> {
    return MODELS.map((m) => ({ ...m }));
  }

  async chat(options: ChatOptions): Promise<ChatResponse> {
    const apiKey = process.env[this.config.apiKeyEnvVar];
    if (!apiKey) throw new Error(`Missing ${this.config.apiKeyEnvVar}`);

    const modelId = options.model.replace(/^mancer\//, "");
    const start = Date.now();

    const res = await fetch(`${this.config.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: modelId,
        messages: this.toMancerMessages(options.messages),
        temperature: options.temperature ?? 0.7,
        max_tokens: options.maxTokens ?? 2048,
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Mancer HTTP ${res.status}: ${text}`);
    }

    const data = (await res.json()) as {
      choices: Array<{ message: { content: string } }>;
      usage?: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
      model: string;
    };

    return {
      content: data.choices[0]?.message?.content ?? "",
      usage: {
        inputTokens: data.usage?.prompt_tokens ?? 0,
        outputTokens: data.usage?.completion_tokens ?? 0,
        totalTokens: data.usage?.total_tokens ?? 0,
      },
      model: data.model,
      provider: this.config.id,
      durationMs: Date.now() - start,
    };
  }

  async healthCheck(): Promise<{ reachable: boolean; status: string; error?: string }> {
    const apiKey = process.env[this.config.apiKeyEnvVar];
    if (!apiKey) return { reachable: false, status: "NO_API_KEY", error: `${this.config.apiKeyEnvVar} not set` };
    try {
      const res = await fetch(`${this.config.baseUrl}/models`, { headers: { Authorization: `Bearer ${apiKey}` } });
      if (!res.ok) return { reachable: true, status: `HTTP_${res.status}`, error: await res.text() };
      return { reachable: true, status: "OK" };
    } catch (err) {
      return { reachable: false, status: "NETWORK_ERROR", error: err instanceof Error ? err.message : String(err) };
    }
  }

  estimateCost(): number {
    return 0;
  }

  private toMancerMessages(messages: Message[]): Array<{ role: string; content: string }> {
    return messages.map((m) => ({ role: m.role, content: m.content }));
  }
}
