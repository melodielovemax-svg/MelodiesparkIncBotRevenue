import type { ModelProvider } from "./base";
import { providerRegistry } from "./registry";
import type { ProviderRegistry } from "./registry";
import type { ChatOptions, ChatResponse, ModelInfo } from "@/agent/types";

export type RoutingStrategy = "fixed" | "auto" | "cost" | "latency" | "capability" | "fallback" | "task-type";

export interface RouterConfig {
  strategy: RoutingStrategy;
  defaultModel: string;
  fallbackModels: string[];
  taskType?: string;
  maxRetries?: number;
}

export class ModelRouter {
  constructor(private registry: ProviderRegistry) {}

  async resolveProvider(modelId?: string): Promise<{ provider: ModelProvider; modelId: string }> {
    const target = modelId ?? "openrouter/auto";
    const provider = this.registry.getProviderForModel(target);
    if (!provider) throw new Error(`No provider found for model ${target}`);
    return { provider, modelId: target };
  }

  async chat(options: ChatOptions, config?: RouterConfig): Promise<ChatResponse> {
    const cfg: RouterConfig = {
      strategy: "fixed",
      defaultModel: "openrouter/auto",
      fallbackModels: [],
      maxRetries: 1,
      ...config,
    };

    const candidates = [options.model ?? cfg.defaultModel, ...cfg.fallbackModels];
    let lastError: Error | undefined;

    for (const modelId of candidates) {
      try {
        const { provider, modelId: resolvedModel } = await this.resolveProvider(modelId);
        return await provider.chat({ ...options, model: resolvedModel });
      } catch (err) {
        lastError = err instanceof Error ? err : new Error(String(err));
      }
    }

    throw lastError ?? new Error("All model candidates failed");
  }

  async listAllModels(): Promise<ModelInfo[]> {
    const all = await Promise.all(this.registry.list().map((p) => p.listModels()));
    return all.flat();
  }
}

export const modelRouter = new ModelRouter(providerRegistry);
