import type { ModelProvider } from "./base";
import type { ChatOptions, ChatResponse, Message, ModelInfo, ProviderConfig, ToolCallRequest } from "@/agent/types";

const CONFIG: ProviderConfig = {
  id: "openai",
  displayName: "OpenAI",
  apiKeyEnvVar: "OPENAI_API_KEY",
  baseUrl: "https://api.openai.com/v1",
  enabled: true,
};

const MODELS: ModelInfo[] = [
  {
    id: "openai/gpt-4-turbo",
    provider: "openai",
    displayName: "GPT-4 Turbo",
    canonicalProviderId: "gpt-4-turbo",
    legacyAliases: ["gpt-4-turbo-preview"],
    availability: "unknown",
    capabilities: {
      supportsStreaming: true,
      supportsTools: true,
      supportsVision: true,
      supportsJson: true,
      supportsCode: true,
      contextWindow: 128000,
    },
    pricing: { inputTokensPerMillion: 10, outputTokensPerMillion: 30 },
  },
  {
    id: "openai/gpt-4",
    provider: "openai",
    displayName: "GPT-4",
    canonicalProviderId: "gpt-4",
    legacyAliases: [],
    availability: "unknown",
    capabilities: {
      supportsStreaming: true,
      supportsTools: true,
      supportsVision: false,
      supportsJson: true,
      supportsCode: true,
      contextWindow: 8192,
    },
    pricing: { inputTokensPerMillion: 30, outputTokensPerMillion: 60 },
  },
  {
    id: "openai/gpt-3.5-turbo",
    provider: "openai",
    displayName: "GPT-3.5 Turbo",
    canonicalProviderId: "gpt-3.5-turbo",
    legacyAliases: [],
    availability: "unknown",
    capabilities: {
      supportsStreaming: true,
      supportsTools: true,
      supportsVision: false,
      supportsJson: true,
      supportsCode: true,
      contextWindow: 16385,
    },
    pricing: { inputTokensPerMillion: 0.5, outputTokensPerMillion: 1.5 },
  },
  {
    id: "openai/gpt-3.5-turbo-16k",
    provider: "openai",
    displayName: "GPT-3.5 Turbo 16K",
    canonicalProviderId: "gpt-3.5-turbo-16k",
    legacyAliases: [],
    availability: "unknown",
    capabilities: {
      supportsStreaming: true,
      supportsTools: true,
      supportsVision: false,
      supportsJson: true,
      supportsCode: true,
      contextWindow: 16384,
    },
    pricing: { inputTokensPerMillion: 3, outputTokensPerMillion: 4 },
  },
  {
    id: "openai/gpt-3.5-turbo-instruct",
    provider: "openai",
    displayName: "GPT-3.5 Turbo Instruct",
    canonicalProviderId: "gpt-3.5-turbo-instruct",
    legacyAliases: [],
    availability: "unknown",
    capabilities: {
      supportsStreaming: true,
      supportsTools: false,
      supportsVision: false,
      supportsJson: false,
      supportsCode: false,
      contextWindow: 4096,
    },
    pricing: { inputTokensPerMillion: 1.5, outputTokensPerMillion: 2 },
  },
];

export class OpenAIProvider implements ModelProvider {
  readonly config = CONFIG;

  async listModels(): Promise<ModelInfo[]> {
    return MODELS.map((m) => ({ ...m }));
  }

  async chat(options: ChatOptions): Promise<ChatResponse> {
    const apiKey = process.env[this.config.apiKeyEnvVar];
    if (!apiKey) throw new Error(`Missing ${this.config.apiKeyEnvVar}`);

    const modelId = options.model.replace(/^openai\//, "");
    const start = Date.now();

    const body: Record<string, unknown> = {
      model: modelId,
      messages: this.toOpenAIMessages(options.messages),
      temperature: options.temperature ?? 0.2,
      max_tokens: options.maxTokens ?? 4096,
    };

    if (options.tools && options.tools.length > 0) {
      body.tools = options.tools.map((t) => ({
        type: "function",
        function: {
          name: t.name,
          description: t.description,
          parameters: t.parameters,
        },
      }));
    }

    const res = await fetch(`${this.config.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`OpenAI HTTP ${res.status}: ${text}`);
    }

    const data = (await res.json()) as {
      choices: Array<{
        message: {
          content: string | null;
          tool_calls?: Array<{
            id: string;
            function: { name: string; arguments: string };
          }>;
        };
      }>;
      usage: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
      model: string;
    };

    const choice = data.choices[0];
    const toolCalls: ToolCallRequest[] | undefined = choice.message.tool_calls?.map((tc) => ({
      id: tc.id,
      name: tc.function.name,
      arguments: JSON.parse(tc.function.arguments),
    }));

    return {
      content: choice.message.content ?? "",
      toolCalls,
      usage: {
        inputTokens: data.usage.prompt_tokens,
        outputTokens: data.usage.completion_tokens,
        totalTokens: data.usage.total_tokens,
      },
      model: data.model,
      provider: this.config.id,
      durationMs: Date.now() - start,
    };
  }

  async healthCheck(): Promise<{ reachable: boolean; status: string; error?: string }> {
    const apiKey = process.env[this.config.apiKeyEnvVar];
    if (!apiKey) return { reachable: false, status: "NO_API_KEY", error: `${this.config.apiKeyEnvVar} not set` };

    try {
      const res = await fetch(`${this.config.baseUrl}/models`, {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      if (!res.ok) {
        const text = await res.text();
        return { reachable: true, status: `HTTP_${res.status}`, error: text };
      }
      return { reachable: true, status: "OK" };
    } catch (err) {
      return { reachable: false, status: "NETWORK_ERROR", error: err instanceof Error ? err.message : String(err) };
    }
  }

  estimateCost(modelId: string, inputTokens: number, outputTokens: number): number {
    const model = MODELS.find((m) => m.id === modelId || m.canonicalProviderId === modelId.replace(/^openai\//, ""));
    if (!model) return 0;
    const inCost = (inputTokens / 1_000_000) * model.pricing.inputTokensPerMillion;
    const outCost = (outputTokens / 1_000_000) * model.pricing.outputTokensPerMillion;
    return inCost + outCost;
  }

  private toOpenAIMessages(messages: Message[]): Array<{ role: string; content: string }> {
    return messages.map((m) => ({ role: m.role, content: m.content }));
  }
}
