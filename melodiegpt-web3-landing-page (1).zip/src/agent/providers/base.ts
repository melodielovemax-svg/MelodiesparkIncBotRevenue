import type { ChatOptions, ChatResponse, ModelInfo, ProviderConfig } from "@/agent/types";

export interface ModelProvider {
  readonly config: ProviderConfig;
  listModels(): Promise<ModelInfo[]>;
  chat(options: ChatOptions): Promise<ChatResponse>;
  stream?(options: ChatOptions, onChunk: (chunk: string) => void): Promise<ChatResponse>;
  healthCheck(): Promise<{ reachable: boolean; status: string; error?: string }>;
  estimateCost(modelId: string, inputTokens: number, outputTokens: number): number;
}

export function hasApiKey(provider: ModelProvider): boolean {
  const key = process.env[provider.config.apiKeyEnvVar];
  return typeof key === "string" && key.length > 0;
}

export function normalizeModelId(id: string): string {
  return id.toLowerCase().replace(/\s+/g, "");
}

export function matchesAlias(model: ModelInfo, query: string): boolean {
  const q = normalizeModelId(query);
  if (normalizeModelId(model.id) === q) return true;
  if (normalizeModelId(model.canonicalProviderId) === q) return true;
  return model.legacyAliases.some((a) => normalizeModelId(a) === q);
}
