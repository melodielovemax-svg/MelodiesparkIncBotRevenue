import type { ModelProvider } from "./base";
import type { ChatOptions, ChatResponse, Message, ModelInfo, ProviderConfig } from "@/agent/types";

const CONFIG: ProviderConfig = {
  id: "gryphe",
  displayName: "Gryphe",
  apiKeyEnvVar: "OPENROUTER_API_KEY",
  baseUrl: "https://openrouter.ai/api/v1",
  enabled: false,
};

const MODELS: ModelInfo[] = [
  {
    id: "gryphe/mythomax-13b",
    provider: "gryphe",
    displayName: "MythoMax 13B",
    canonicalProviderId: "gryphe/mythomax-13b",
    legacyAliases: [],
    availability: "unknown",
    capabilities: {
      supportsStreaming: true,
      supportsTools: false,
      supportsVision: false,
      supportsJson: false,
      supportsCode: true,
      contextWindow: 4096,
    },
    pricing: { inputTokensPerMillion: 0, outputTokensPerMillion: 0 },
  },
];

export class GrypheProvider implements ModelProvider {
  readonly config = CONFIG;

  async listModels(): Promise<ModelInfo[]> {
    return MODELS.map((m) => ({ ...m }));
  }

  async chat(options: ChatOptions): Promise<ChatResponse> {
    const apiKey = process.env[this.config.apiKeyEnvVar];
    if (!apiKey) throw new Error(`Missing ${this.config.apiKeyEnvVar}`);

    const start = Date.now();
    const res = await fetch(`${this.config.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://melodiegpt.local",
      },
      body: JSON.stringify({
        model: options.model,
        messages: this.toMessages(options.messages),
        temperature: options.temperature ?? 0.7,
        max_tokens: options.maxTokens ?? 2048,
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Gryphe HTTP ${res.status}: ${text}`);
    }

    const data = (await res.json()) as {
      choices: Array<{ message: { content: string } }>;
      usage?: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
      model: string;
    };

    return {
      content: data.choices[0]?.message?.content ?? "",
      usage: {
        inputTokens: data.usage?.prompt_tokens ?? 0,
        outputTokens: data.usage?.completion_tokens ?? 0,
        totalTokens: data.usage?.total_tokens ?? 0,
      },
      model: data.model,
      provider: this.config.id,
      durationMs: Date.now() - start,
    };
  }

  async healthCheck(): Promise<{ reachable: boolean; status: string; error?: string }> {
    const apiKey = process.env[this.config.apiKeyEnvVar];
    if (!apiKey) return { reachable: false, status: "NO_API_KEY", error: `${this.config.apiKeyEnvVar} not set` };
    return { reachable: true, status: "UNVERIFIED", error: "Provider uses OpenRouter; model availability depends on OpenRouter catalog" };
  }

  estimateCost(): number {
    return 0;
  }

  private toMessages(messages: Message[]): Array<{ role: string; content: string }> {
    return messages.map((m) => ({ role: m.role, content: m.content }));
  }
}
