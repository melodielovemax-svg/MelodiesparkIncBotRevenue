import type { ModelProvider } from "./base";
import type { ChatOptions, ChatResponse, Message, ModelInfo, ProviderConfig, ToolCallRequest } from "@/agent/types";

const CONFIG: ProviderConfig = {
  id: "openrouter",
  displayName: "OpenRouter",
  apiKeyEnvVar: "OPENROUTER_API_KEY",
  baseUrl: "https://openrouter.ai/api/v1",
  enabled: true,
};

const MODELS: ModelInfo[] = [
  {
    id: "openrouter/auto",
    provider: "openrouter",
    displayName: "OpenRouter Auto",
    canonicalProviderId: "openrouter/auto",
    legacyAliases: [],
    availability: "unknown",
    capabilities: {
      supportsStreaming: true,
      supportsTools: true,
      supportsVision: true,
      supportsJson: true,
      supportsCode: true,
      contextWindow: 128000,
    },
    pricing: { inputTokensPerMillion: 5, outputTokensPerMillion: 15 },
  },
];

export class OpenRouterProvider implements ModelProvider {
  readonly config = CONFIG;

  async listModels(): Promise<ModelInfo[]> {
    const apiKey = process.env[this.config.apiKeyEnvVar];
    if (!apiKey) return MODELS.map((m) => ({ ...m }));

    try {
      const res = await fetch(`${this.config.baseUrl}/models`, {
        headers: { Authorization: `Bearer ${apiKey}` },
      });
      if (!res.ok) return MODELS.map((m) => ({ ...m }));
      const data = (await res.json()) as { data: Array<{ id: string; context_length?: number; pricing?: { prompt?: number; completion?: number } }> };
      const dynamic = data.data.map((m) => ({
        id: `openrouter/${m.id}`,
        provider: "openrouter",
        displayName: m.id,
        canonicalProviderId: m.id,
        legacyAliases: [] as string[],
        availability: "available" as const,
        capabilities: {
          supportsStreaming: true,
          supportsTools: true,
          supportsVision: false,
          supportsJson: true,
          supportsCode: true,
          contextWindow: m.context_length ?? 128000,
        },
        pricing: {
          inputTokensPerMillion: (m.pricing?.prompt ?? 0) * 1_000_000,
          outputTokensPerMillion: (m.pricing?.completion ?? 0) * 1_000_000,
        },
      }));
      return [...MODELS.map((m) => ({ ...m })), ...dynamic];
    } catch {
      return MODELS.map((m) => ({ ...m }));
    }
  }

  async chat(options: ChatOptions): Promise<ChatResponse> {
    const apiKey = process.env[this.config.apiKeyEnvVar];
    if (!apiKey) throw new Error(`Missing ${this.config.apiKeyEnvVar}`);

    const modelId = options.model.replace(/^openrouter\//, "");
    const start = Date.now();

    const body: Record<string, unknown> = {
      model: modelId,
      messages: this.toOpenRouterMessages(options.messages),
      temperature: options.temperature ?? 0.2,
      max_tokens: options.maxTokens ?? 4096,
    };

    if (options.tools && options.tools.length > 0) {
      body.tools = options.tools.map((t) => ({
        type: "function",
        function: {
          name: t.name,
          description: t.description,
          parameters: t.parameters,
        },
      }));
    }

    const res = await fetch(`${this.config.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://melodiegpt.local",
        "X-Title": "MelodieGPT Agent",
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`OpenRouter HTTP ${res.status}: ${text}`);
    }

    const data = (await res.json()) as {
      choices: Array<{
        message: {
          content: string | null;
          tool_calls?: Array<{ id: string; function: { name: string; arguments: string } }>;
        };
      }>;
      usage?: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
      model: string;
    };

    const choice = data.choices[0];
    const toolCalls: ToolCallRequest[] | undefined = choice.message.tool_calls?.map((tc) => ({
      id: tc.id,
      name: tc.function.name,
      arguments: JSON.parse(tc.function.arguments),
    }));

    return {
      content: choice.message.content ?? "",
      toolCalls,
      usage: {
        inputTokens: data.usage?.prompt_tokens ?? 0,
        outputTokens: data.usage?.completion_tokens ?? 0,
        totalTokens: data.usage?.total_tokens ?? 0,
      },
      model: data.model,
      provider: this.config.id,
      durationMs: Date.now() - start,
    };
  }

  async healthCheck(): Promise<{ reachable: boolean; status: string; error?: string }> {
    const apiKey = process.env[this.config.apiKeyEnvVar];
    if (!apiKey) return { reachable: false, status: "NO_API_KEY", error: `${this.config.apiKeyEnvVar} not set` };
    try {
      const res = await fetch(`${this.config.baseUrl}/models`, { headers: { Authorization: `Bearer ${apiKey}` } });
      if (!res.ok) return { reachable: true, status: `HTTP_${res.status}`, error: await res.text() };
      return { reachable: true, status: "OK" };
    } catch (err) {
      return { reachable: false, status: "NETWORK_ERROR", error: err instanceof Error ? err.message : String(err) };
    }
  }

  estimateCost(modelId: string, inputTokens: number, outputTokens: number): number {
    const baseId = modelId.replace(/^openrouter\//, "");
    const model = MODELS.find((m) => m.canonicalProviderId === baseId);
    if (!model) return 0;
    return (
      (inputTokens / 1_000_000) * model.pricing.inputTokensPerMillion +
      (outputTokens / 1_000_000) * model.pricing.outputTokensPerMillion
    );
  }

  private toOpenRouterMessages(messages: Message[]): Array<{ role: string; content: string }> {
    return messages.map((m) => ({ role: m.role, content: m.content }));
  }
}
