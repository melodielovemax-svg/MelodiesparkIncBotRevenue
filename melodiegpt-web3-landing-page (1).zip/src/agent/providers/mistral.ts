import type { ModelProvider } from "./base";
import type { ChatOptions, ChatResponse, Message, ModelInfo, ProviderConfig, ToolCallRequest } from "@/agent/types";

const CONFIG: ProviderConfig = {
  id: "mistral",
  displayName: "Mistral AI",
  apiKeyEnvVar: "MISTRAL_API_KEY",
  baseUrl: "https://api.mistral.ai/v1",
  enabled: true,
};

const MODELS: ModelInfo[] = [
  {
    id: "mistralai/mistral-large",
    provider: "mistral",
    displayName: "Mistral Large",
    canonicalProviderId: "mistral-large-latest",
    legacyAliases: ["mistral-large"],
    availability: "unknown",
    capabilities: {
      supportsStreaming: true,
      supportsTools: true,
      supportsVision: false,
      supportsJson: true,
      supportsCode: true,
      contextWindow: 128000,
    },
    pricing: { inputTokensPerMillion: 3, outputTokensPerMillion: 9 },
  },
];

export class MistralProvider implements ModelProvider {
  readonly config = CONFIG;

  async listModels(): Promise<ModelInfo[]> {
    return MODELS.map((m) => ({ ...m }));
  }

  async chat(options: ChatOptions): Promise<ChatResponse> {
    const apiKey = process.env[this.config.apiKeyEnvVar];
    if (!apiKey) throw new Error(`Missing ${this.config.apiKeyEnvVar}`);

    const modelId = options.model.replace(/^mistralai\//, "");
    const start = Date.now();

    const body: Record<string, unknown> = {
      model: modelId,
      messages: this.toMistralMessages(options.messages),
      temperature: options.temperature ?? 0.2,
      max_tokens: options.maxTokens ?? 4096,
    };

    if (options.tools && options.tools.length > 0) {
      body.tools = options.tools.map((t) => ({
        type: "function",
        function: {
          name: t.name,
          description: t.description,
          parameters: t.parameters,
        },
      }));
    }

    const res = await fetch(`${this.config.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Mistral HTTP ${res.status}: ${text}`);
    }

    const data = (await res.json()) as {
      choices: Array<{
        message: {
          content: string | null;
          tool_calls?: Array<{ id: string; function: { name: string; arguments: string } }>;
        };
      }>;
      usage: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
      model: string;
    };

    const choice = data.choices[0];
    const toolCalls: ToolCallRequest[] | undefined = choice.message.tool_calls?.map((tc) => ({
      id: tc.id,
      name: tc.function.name,
      arguments: JSON.parse(tc.function.arguments),
    }));

    return {
      content: choice.message.content ?? "",
      toolCalls,
      usage: {
        inputTokens: data.usage.prompt_tokens,
        outputTokens: data.usage.completion_tokens,
        totalTokens: data.usage.total_tokens,
      },
      model: data.model,
      provider: this.config.id,
      durationMs: Date.now() - start,
    };
  }

  async healthCheck(): Promise<{ reachable: boolean; status: string; error?: string }> {
    const apiKey = process.env[this.config.apiKeyEnvVar];
    if (!apiKey) return { reachable: false, status: "NO_API_KEY", error: `${this.config.apiKeyEnvVar} not set` };
    try {
      const res = await fetch(`${this.config.baseUrl}/models`, { headers: { Authorization: `Bearer ${apiKey}` } });
      if (!res.ok) return { reachable: true, status: `HTTP_${res.status}`, error: await res.text() };
      return { reachable: true, status: "OK" };
    } catch (err) {
      return { reachable: false, status: "NETWORK_ERROR", error: err instanceof Error ? err.message : String(err) };
    }
  }

  estimateCost(modelId: string, inputTokens: number, outputTokens: number): number {
    const baseId = modelId.replace(/^mistralai\//, "");
    const model = MODELS.find((m) => m.canonicalProviderId === baseId);
    if (!model) return 0;
    return (
      (inputTokens / 1_000_000) * model.pricing.inputTokensPerMillion +
      (outputTokens / 1_000_000) * model.pricing.outputTokensPerMillion
    );
  }

  private toMistralMessages(messages: Message[]): Array<{ role: string; content: string }> {
    return messages.map((m) => ({ role: m.role, content: m.content }));
  }
}
