import { OpenAIProvider } from "./openai";
import { OpenRouterProvider } from "./openrouter";
import { MistralProvider } from "./mistral";
import { MancerProvider } from "./mancer";
import { Undi95Provider } from "./undi95";
import { GrypheProvider } from "./gryphe";
import type { ModelProvider } from "./base";

export class ProviderRegistry {
  private providers: Map<string, ModelProvider> = new Map();

  constructor() {
    this.register(new OpenAIProvider());
    this.register(new OpenRouterProvider());
    this.register(new MistralProvider());
    this.register(new MancerProvider());
    this.register(new Undi95Provider());
    this.register(new GrypheProvider());
  }

  register(provider: ModelProvider): void {
    this.providers.set(provider.config.id, provider);
  }

  get(id: string): ModelProvider | undefined {
    return this.providers.get(id);
  }

  list(): ModelProvider[] {
    return Array.from(this.providers.values());
  }

  getProviderForModel(modelId: string): ModelProvider | undefined {
    const prefix = modelId.split("/")[0];
    const aliasMap: Record<string, string> = {
      openai: "openai",
      openrouter: "openrouter",
      mistralai: "mistral",
      mancer: "mancer",
      undi95: "undi95",
      gryphe: "gryphe",
    };
    return this.providers.get(aliasMap[prefix] ?? prefix) ?? this.providers.get("openrouter");
  }
}

export const providerRegistry = new ProviderRegistry();
