import { modelRouter } from "@/agent/providers/router";
import { toolRegistry } from "@/agent/tools/registry";
import { WorkspaceSandbox } from "@/agent/security/sandbox";
import type { Message, TaskResult, ToolCallRequest, ChatOptions } from "@/agent/types";

export interface AgentLoopOptions {
  task: string;
  workspace: string;
  sessionId: string;
  taskId?: string;
  model?: string;
  maxIterations?: number;
  onUpdate?: (update: { type: string; content: string }) => void;
}

const SYSTEM_PROMPT = `You are MelodieCode, an autonomous coding agent. You have access to filesystem, shell, git, code search, test, build, and lint tools. Follow this loop:
1. Inspect the repository with available tools.
2. Plan a minimal set of changes.
3. Apply changes with filesystem.write or filesystem.patch.
4. Run tests/build/lint to verify.
5. If failures occur, inspect and repair.
6. Return a concise final report.
Always prefer safe, incremental changes. Never run destructive commands without explicit user confirmation.`;

export async function runAgentLoop(options: AgentLoopOptions): Promise<TaskResult> {
  const { task, workspace, sessionId, taskId, model = "openrouter/auto", maxIterations = 10, onUpdate } = options;
  const sandbox = new WorkspaceSandbox();
  const ctx = sandbox.createContext(sessionId, workspace, taskId);
  const messages: Message[] = [
    { role: "system", content: SYSTEM_PROMPT },
    { role: "user", content: task },
  ];

  const filesModified: string[] = [];
  let finalOutput = "";

  for (let i = 0; i < maxIterations; i++) {
    onUpdate?.({ type: "status", content: `Iteration ${i + 1}: calling model...` });

    const chatOptions: ChatOptions = {
      model,
      messages,
      temperature: 0.2,
      maxTokens: 4096,
      tools: toolRegistry.schemas(),
    };

    let response;
    try {
      response = await modelRouter.chat(chatOptions);
    } catch (err) {
      return {
        success: false,
        output: "",
        error: `Model call failed: ${err instanceof Error ? err.message : String(err)}`,
        filesModified,
      };
    }

    messages.push({ role: "assistant", content: response.content, toolCalls: response.toolCalls });
    finalOutput = response.content;
    onUpdate?.({ type: "message", content: response.content });

    if (!response.toolCalls || response.toolCalls.length === 0) {
      break;
    }

    for (const call of response.toolCalls) {
      onUpdate?.({ type: "tool", content: `${call.name}(${JSON.stringify(call.arguments)})` });
      const result = await toolRegistry.execute(call, ctx);
      messages.push({
        role: "tool",
        content: result.error ? `Error: ${result.error}` : result.output,
        toolCallId: result.toolCallId,
      });

      if (call.name === "filesystem.write" && !result.error) {
        const path = String(call.arguments.path ?? "");
        if (path && !filesModified.includes(path)) filesModified.push(path);
      }
    }
  }

  return {
    success: true,
    output: finalOutput,
    filesModified,
  };
}
