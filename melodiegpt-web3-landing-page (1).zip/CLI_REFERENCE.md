# CLI Reference

The `agent` CLI is available at `./bin/agent`.

## Global

```bash
agent --version
agent --help
```

## Commands

| Command | Description |
|---------|-------------|
| `agent doctor` | Verify runtime, dependencies, providers, tools |
| `agent status` | Show platform capability status |
| `agent models` | List configured models |
| `agent models --verify` | Verify provider connectivity and model availability |
| `agent providers` | List registered providers |
| `agent tools` | List available agent tools |
| `agent chat <message>` | Send a chat message to the default model |
| `agent code <task>` | Run an autonomous coding task |
| `agent run <command>` | Execute a shell command through the sandbox |
| `agent index` | Repository indexing (SCAFFOLD) |
| `agent sessions` | List sessions (SCAFFOLD) |
| `agent costs` | Cost tracking (SCAFFOLD) |
| `agent audit` | Audit log (SCAFFOLD) |

## Options

- `--model <model>` — override model ID
- `--workspace <path>` — override workspace path

## Exit Codes

- `0` — success
- `1` — failure or denied operation
