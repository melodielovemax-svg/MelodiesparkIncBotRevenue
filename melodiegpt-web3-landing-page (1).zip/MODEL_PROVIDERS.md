# Model Providers

Runtime status is verified by `agent models --verify`. Without credentials, providers report `NO_API_KEY`.

## Supported Providers

| Provider | Env Var | Status | Notes |
|----------|---------|--------|-------|
| OpenAI | `OPENAI_API_KEY` | BLOCKED without key | GPT-4 Turbo, GPT-4, GPT-3.5 family |
| OpenRouter | `OPENROUTER_API_KEY` | BLOCKED without key | Auto router + dynamic catalog |
| Mistral | `MISTRAL_API_KEY` | BLOCKED without key | Mistral Large |
| Mancer | `MANCER_API_KEY` | BLOCKED without key | Weaver |
| Undi95 | `OPENROUTER_API_KEY` | BLOCKED without key | ReMM SLERP 13B via OpenRouter |
| Gryphe | `OPENROUTER_API_KEY` | BLOCKED without key | MythoMax 13B via OpenRouter |

## Requested Models

| Model | Provider | Capability | Notes |
|-------|----------|------------|-------|
| openai/gpt-4-turbo | OpenAI | tools, streaming, vision, code | availability verified at runtime |
| openai/gpt-4 | OpenAI | tools, streaming, code | legacy checkpoint model |
| openai/gpt-3.5-turbo | OpenAI | tools, streaming, code | widely available |
| openai/gpt-3.5-turbo-16k | OpenAI | tools, streaming, code | legacy 16k variant |
| openai/gpt-3.5-turbo-instruct | OpenAI | streaming | instruct-only, no tools |
| openrouter/auto | OpenRouter | tools, streaming, code | dynamic provider routing |
| mistralai/mistral-large | Mistral | tools, streaming, code | current Mistral large model |
| mancer/weaver | Mancer | streaming, code | niche provider |
| undi95/remm-slerp-13b | OpenRouter | streaming, code | availability depends on catalog |
| gryphe/mythomax-13b | OpenRouter | streaming, code | availability depends on catalog |

## Capability Detection

Each model exposes:

- `contextWindow`
- `supportsStreaming`
- `supportsTools`
- `supportsVision`
- `supportsJson`
- `supportsCode`

The router selects providers based on model ID prefix and falls back to OpenRouter when ambiguous.
