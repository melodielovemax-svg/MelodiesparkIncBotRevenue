# Capability Status

Last updated: build verification completed.

| Capability | Status | Evidence |
|------------|--------|----------|
| CLI | OPERATIONAL | `./bin/agent doctor`, `status`, `models`, `tools` execute |
| IDE (web) | OPERATIONAL | `/agent` page renders chat, explorer, terminal |
| Agent Engine | OPERATIONAL | `runAgentLoop` implemented with tool calls |
| Model Gateway | OPERATIONAL | Provider registry, router, verifier implemented and tested |
| Tool System | OPERATIONAL | 14 tools registered; fs/shell/git/test/build/lint tested |
| Security Sandbox | OPERATIONAL | Path policies and command classification tested |
| OpenAI Adapter | OPERATIONAL (with credentials) | Real HTTP adapter; `NO_API_KEY` without key |
| OpenRouter Adapter | OPERATIONAL (with credentials) | Real HTTP adapter; auto router supported |
| Mistral Adapter | OPERATIONAL (with credentials) | Real HTTP adapter |
| Mancer Adapter | IMPLEMENTED / UNVERIFIED | Endpoint implemented; no credentials to verify |
| Undi95 Adapter | IMPLEMENTED / UNVERIFIED | Routes via OpenRouter; model availability depends on catalog |
| Gryphe Adapter | IMPLEMENTED / UNVERIFIED | Routes via OpenRouter; model availability depends on catalog |
| Repository Indexing | SCAFFOLD | File tree API exists; symbol/AST indexing not implemented |
| Multi-Agent Orchestration | SCAFFOLD | Single agent loop operational; specialized agents defined as types only |
| Cost Tracking | SCAFFOLD | Model request table exists; aggregation CLI not implemented |
| Session Persistence | SCAFFOLD | DB tables exist; full session lifecycle not wired in CLI |
| Streaming | PARTIAL | Provider adapters support streaming interface; CLI render uses completion only |
| Checkpoints | SCAFFOLD | DB table exists; git-based checkpointing not implemented |
| Audit Log | SCAFFOLD | DB table + in-memory logging exist; persistent audit query not implemented |

## Test Results

```
npm test
17 tests passed, 0 failed
```

## Build Results

```
npm run typecheck  # passed
npm run lint       # passed
npm run build      # passed
```
