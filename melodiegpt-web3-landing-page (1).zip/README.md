# MelodieGPT — Web3 AI Ecosystem + Multi-Model Coding Agent Platform

A production-oriented fullstack platform combining:

- **MelodieGPT** landing page with model registry
- **Web3 wallet** (`Metamello`) with karma points and MA token mining
- **Digital marketplace** for products and services
- **Quantum Fractal CLI** terminal
- **Multi-model coding agent CLI + IDE**

## Quick Start

```bash
npm install
npx drizzle-kit push
npm run test
npm run typecheck
npm run lint
npm run build
npm run dev
```

## CLI

```bash
./bin/agent doctor      # health check
./bin/agent status      # platform status
./bin/agent models      # list models
./bin/agent models --verify
./bin/agent tools       # list tools
./bin/agent chat "hello"
./bin/agent code "refactor the auth module"
./bin/agent run "npm test"
```

## Web IDE

Open `/agent` in the browser to use the coding-agent IDE with chat, file explorer, and terminal.

## Environment Variables

```bash
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
OPENAI_API_KEY=...
OPENROUTER_API_KEY=...
MISTRAL_API_KEY=...
MANCER_API_KEY=...
```

## Model Providers

Configured adapters for OpenAI, OpenRouter, Mistral, Mancer, Undi95, and Gryphe. Models are verified at runtime; without API keys they report `NO_API_KEY` / `BLOCKED`.

## Tests

```bash
npm test
```

## Architecture

See [ARCHITECTURE.md](./ARCHITECTURE.md), [CLI_REFERENCE.md](./CLI_REFERENCE.md), [MODEL_PROVIDERS.md](./MODEL_PROVIDERS.md), and [STATUS.md](./STATUS.md).
