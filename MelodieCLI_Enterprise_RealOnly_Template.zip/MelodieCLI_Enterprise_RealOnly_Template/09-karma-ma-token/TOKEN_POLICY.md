# Karma / MA Token Policy

## Separation

Karma points, MA units, and blockchain assets are distinct accounting concepts unless and until a legally and technically verified conversion mechanism exists.

## No automatic value claim

The system must not claim that karma points have monetary value.

## Conversion gate

A conversion to a blockchain asset requires:
- defined legal/compliance basis
- defined token contract or provider
- supported jurisdiction
- rate source
- fees
- transaction authorization
- on-chain receipt
- accounting reconciliation

Until those conditions are satisfied, conversion remains `PLANNED`, `PAPER-ONLY`, `BLOCKED`, or `UNVERIFIED` as appropriate.

## Good deeds

A service reward can be recorded as an internal points event. That event is not automatically a cryptocurrency transaction.
