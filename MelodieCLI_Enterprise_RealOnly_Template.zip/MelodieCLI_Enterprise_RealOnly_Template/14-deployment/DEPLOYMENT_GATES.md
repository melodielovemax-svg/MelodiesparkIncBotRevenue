# Deployment Gates

1. tests pass
2. security checks pass
3. secrets verified
4. migrations reviewed
5. backups verified
6. network exposure reviewed
7. rollback plan verified
8. compliance gate satisfied
9. external providers verified
10. evidence registry updated

Production deployment does not automatically make a business capability operational.
