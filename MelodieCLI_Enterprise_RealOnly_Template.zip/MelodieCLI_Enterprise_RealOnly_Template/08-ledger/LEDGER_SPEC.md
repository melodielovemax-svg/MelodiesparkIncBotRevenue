# Revenue / Treasury Ledger

The ledger is an evidence system, not a generator of revenue.

Minimum event fields:

- event_id
- event_type
- occurred_at
- source_system
- external_reference
- asset
- amount
- currency/chain
- debit_account
- credit_account
- authorization_reference
- reconciliation_status
- evidence_reference

Rules:
- append-only event history
- idempotency
- immutable event IDs
- no silent mutation
- reconciliation against source systems
- correction through compensating entries
