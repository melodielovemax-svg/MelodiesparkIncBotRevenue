# Real Business Reality Register

Do not populate this file with assumptions.

## Customers

Status: UNVERIFIED
Evidence: none recorded in this template.

## Revenue

Status: UNVERIFIED
Evidence: none recorded in this template.

## Market activity

Status: UNVERIFIED
Evidence: none recorded in this template.

## Products and services

Use `catalog.yaml` for actual offerings. An offering becomes commercially active only after its real prerequisites and evidence are recorded.
