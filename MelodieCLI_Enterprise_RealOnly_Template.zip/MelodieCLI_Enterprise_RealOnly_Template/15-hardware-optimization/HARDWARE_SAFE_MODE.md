# Hardware Optimization — Safe Mode

The optimizer may inspect hardware and recommend settings.

It must not:
- overclock without explicit policy
- modify firmware automatically
- disable security software
- modify unrelated projects
- delete files outside its managed workspace
- mine cryptocurrency silently
- create hidden persistence

Optimization evidence should include before/after measurements. "Zero lag" and guaranteed performance claims are not valid without measured evidence.
