# Security Baseline

- secrets in a secret manager
- no private keys in repository
- MFA for privileged accounts
- least privilege
- network segmentation
- TLS
- dependency scanning
- image scanning
- immutable backups
- incident response
- audit logging
- rate limiting
- replay protection
- key rotation
- credential rotation
- firewall review
- exposed-port review
- scheduled-task/persistence review
- malware/EDR review

Security hardening does not establish business legitimacy.
