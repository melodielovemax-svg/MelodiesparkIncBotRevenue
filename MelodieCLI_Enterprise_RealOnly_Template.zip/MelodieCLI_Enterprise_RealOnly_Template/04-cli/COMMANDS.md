# MelodieCLI Command Contract

```text
melodie status
melodie evidence list
melodie product list
melodie service list
melodie sale prepare
melodie sale approve
melodie sale reconcile
melodie ledger inspect
melodie wallet status
melodie wallet address
melodie wallet prepare-transfer
melodie wallet simulate
melodie wallet confirm-transfer
melodie web3 receipt <tx-hash>
melodie bots status
melodie workflow run <workflow>
melodie compliance check
melodie security audit
melodie deploy plan
melodie deploy apply
```

Commands that can cause irreversible external effects must require explicit authorization and must produce an audit record.

No command should fabricate a transaction hash, balance, customer, revenue amount, or blockchain receipt.
