#requires -Version 7.2
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$Target = "C:\MaxAutoRevenue",
    [switch]$CreateDesktopShortcut
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Write-Host "MelodieCLI Real-Only Project Initializer" -ForegroundColor Cyan
Write-Host "Target: $Target"

if (-not (Test-Path -LiteralPath $Target)) {
    New-Item -ItemType Directory -Path $Target -Force | Out-Null
}

$folders = @(
    "01-governance","02-business","03-architecture","04-cli","05-bot-revenue",
    "06-products-services","07-web3-wallet","08-ledger","09-karma-ma-token",
    "10-compliance","11-security","12-observability","13-tests","14-deployment",
    "15-hardware-optimization","16-fiction-isolated","17-evidence","18-tasks"
)

foreach ($folder in $folders) {
    New-Item -ItemType Directory -Path (Join-Path $Target $folder) -Force | Out-Null
}

# Copy the template only. No credentials, private keys, or synthetic business data.
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
Get-ChildItem -LiteralPath $Source -File -Recurse |
    Where-Object {
        $_.FullName -notmatch '\\\.git\\' -and
        $_.Name -notmatch '(\.env$|\.key$|\.pem$|seed|private)'
    } |
    ForEach-Object {
        $relative = $_.FullName.Substring($Source.Length).TrimStart('\')
        $destination = Join-Path $Target $relative
        $parent = Split-Path -Parent $destination
        if (-not (Test-Path $parent)) {
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
        }
        Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
    }

@"
MelodieCLI initialized.

REAL BUSINESS:
  Evidence-driven statuses only.

FICTION:
  Explicitly isolated and FICTIONAL.

No private keys, seed phrases, fabricated revenue, fabricated customers,
fabricated transactions, or synthetic business metrics are created.

Next:
  1. Review 01-governance
  2. Populate real products/services
  3. Configure providers through a secret manager
  4. Run tests
  5. Record evidence
  6. Only then classify capabilities
"@ | Set-Content -LiteralPath (Join-Path $Target "INSTALLATION_RESULT.txt") -Encoding UTF8

Write-Host "Initialized safely at $Target" -ForegroundColor Green
Write-Host "No unrelated project directories were modified." -ForegroundColor Green
