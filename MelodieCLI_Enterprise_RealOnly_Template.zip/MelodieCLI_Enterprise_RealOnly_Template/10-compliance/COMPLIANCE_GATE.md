# Legal / Compliance Gate

This template is not legal advice and does not establish authorization.

Before activating financial or token functionality, obtain jurisdiction-specific review covering applicable:
- payments rules
- money transmission / virtual asset rules
- securities/token rules where applicable
- consumer protection
- privacy
- AML/KYC obligations where applicable
- tax
- sanctions
- advertising/disclosure requirements
- contracts and terms

Every external compliance assertion must reference the responsible authority or professional advice.

Status without evidence: UNVERIFIED.
