# Reference Architecture

## Planes

### Control plane
- identity
- RBAC
- policy engine
- approval workflow
- configuration
- audit

### Execution plane
- task queue
- bounded workers
- idempotency
- retries
- dead-letter queue
- workflow state

### Commerce plane
- product catalog
- checkout
- payment provider adapters
- order lifecycle
- refunds
- reconciliation

### Web3 plane
- chain adapters
- wallet gateway
- transaction builder
- simulation
- confirmation gate
- receipt verification

### Accounting plane
- append-only ledger
- double-entry rules where applicable
- reconciliation
- evidence references

### Observability plane
- structured logs
- metrics
- traces
- alerts
- security events

### Security plane
- secret manager
- key isolation
- least privilege
- network controls
- dependency scanning
- backup/recovery

## No direct autonomous money movement

Irreversible financial actions must pass through authorization and confirmation policies. A bot may prepare a transaction, but a transfer policy determines whether it can execute automatically.
