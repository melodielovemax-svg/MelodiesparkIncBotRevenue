# Observability

Required:
- service health
- workflow state
- queue depth
- worker utilization
- error rate
- latency
- payment webhook status
- ledger reconciliation status
- blockchain RPC health
- transaction receipt status
- security events

Never emit:
- private keys
- seed phrases
- authentication tokens
- full payment credentials
- sensitive personal data
