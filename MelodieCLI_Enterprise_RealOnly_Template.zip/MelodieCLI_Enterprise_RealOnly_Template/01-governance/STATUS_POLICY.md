# Status Policy

A capability may become `OPERATIONAL` only when its specific evidence requirements are satisfied.

## Evidence ladder

1. Source implementation exists.
2. Automated tests pass.
3. Runtime behavior is observed.
4. External dependency is actually connected.
5. Real-world event occurs when applicable.
6. Evidence is retained.
7. Reconciliation succeeds.
8. Classification is recorded.

## Examples

Revenue processing:
- code: insufficient
- tests: insufficient
- Stripe/other processor connected: required
- real payment captured: required
- processor receipt/webhook: required
- ledger reconciliation: required
- status: `SCAFFOLD` until those conditions are met

Customers:
- database row: insufficient
- test account: insufficient
- real customer relationship: required
- evidence: contract/order/account/payment/support record as appropriate
- status: `UNVERIFIED` until independently established

Dashboard:
- displaying database state: not business proof
- status may be `OPERATIONAL` as software while remaining incapable of proving commercial activity.

## Domain separation

`REAL BUSINESS` and `FICTION / NARRATIVE` are separate evidence domains.

A fictional event can never be used as evidence for:
- revenue
- customers
- transactions
- partnerships
- deployments
- market demand
- regulatory authorization
