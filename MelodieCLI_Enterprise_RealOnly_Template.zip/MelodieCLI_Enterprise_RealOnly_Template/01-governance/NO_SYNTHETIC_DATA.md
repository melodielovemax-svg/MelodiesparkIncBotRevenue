# No Synthetic Business Data Contract

The application must not generate fake:
- customers
- sales
- revenue
- balances
- transaction hashes
- blockchain receipts
- reviews
- demand statistics
- market activity
- partnerships

Synthetic data may be used only in explicitly isolated automated tests and must be labeled as test data. Test data must never enter production business metrics.

If no real value exists, return an empty result or `UNVERIFIED`.
