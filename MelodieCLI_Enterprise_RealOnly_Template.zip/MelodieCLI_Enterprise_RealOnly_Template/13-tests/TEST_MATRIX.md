# Test Matrix

| Area | Unit | Integration | Runtime | Real-world evidence |
|---|---:|---:|---:|---:|
| API | required | required | required | n/a |
| Database | required | required | required | n/a |
| Auth | required | required | required | n/a |
| Sales workflow | required | required | required | required for OPERATIONAL business claim |
| Payment | required | required | required | required |
| Ledger | required | required | required | required for real transaction claims |
| Wallet | required | required | required | required for real transfer claims |
| Token conversion | required | required | required | required |
| Customer acquisition | n/a | n/a | n/a | required |
