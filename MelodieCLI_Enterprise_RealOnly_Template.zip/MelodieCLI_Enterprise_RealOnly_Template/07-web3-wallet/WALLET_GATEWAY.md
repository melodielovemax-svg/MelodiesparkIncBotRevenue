# Web3 Wallet Gateway

## Supported lifecycle

```text
wallet connection
 -> address verification
 -> balance query
 -> transaction construction
 -> gas estimation
 -> simulation
 -> policy check
 -> explicit authorization
 -> broadcast
 -> receipt
 -> confirmation
 -> ledger reconciliation
```

## MetaMask / browser wallet

The application may request a connection through a supported provider. It must never request or store a seed phrase or private key.

## Treasury

A treasury wallet is an externally controlled financial account. Its address must be configured from verified deployment configuration, not invented.

## Transfer evidence

A successful transfer requires:
- chain/network
- sender
- recipient
- asset
- amount
- nonce where applicable
- gas data
- transaction hash
- receipt/status
- timestamp
- reconciliation reference

No transaction is considered successful because a UI says "success".
