import {
  pgTable,
  text,
  timestamp,
  integer,
  boolean,
  jsonb,
  uuid,
  pgEnum,
  real,
} from "drizzle-orm/pg-core";

// ─── Enums ────────────────────────────────────────────────────────────────────

export const modelStatusEnum = pgEnum("model_status", [
  "OPERATIONAL",
  "SCAFFOLD",
  "PLANNED",
  "BLOCKED",
  "UNVERIFIED",
  "FICTIONAL",
]);

export const providerEnum = pgEnum("provider_name", [
  "openrouter",
  "openai",
  "anthropic",
  "google",
  "mistral",
  "local",
  "generic",
]);

export const agentRoleEnum = pgEnum("agent_role", [
  "architect",
  "coder",
  "tester",
  "verifier",
  "orchestrator",
  "general",
]);

export const sessionStatusEnum = pgEnum("session_status", [
  "pending",
  "planning",
  "executing",
  "verifying",
  "completed",
  "failed",
  "aborted",
]);

export const auditEventTypeEnum = pgEnum("audit_event_type", [
  "model_call",
  "tool_call",
  "session_start",
  "session_end",
  "plan_created",
  "task_completed",
  "error",
  "approval_requested",
  "approval_granted",
  "approval_denied",
  "probe_run",
]);

export const toolCallStatusEnum = pgEnum("tool_call_status", [
  "success",
  "failure",
  "timeout",
  "denied",
]);

export const probeStatusEnum = pgEnum("probe_status", [
  "PASS",
  "FAIL",
  "SKIP",
  "PENDING",
]);

// ─── Providers ────────────────────────────────────────────────────────────────

export const providers = pgTable("providers", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: providerEnum("name").notNull(),
  displayName: text("display_name").notNull(),
  baseUrl: text("base_url"),
  isConfigured: boolean("is_configured").default(false),
  isReachable: boolean("is_reachable").default(false),
  lastCheckedAt: timestamp("last_checked_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ─── Models ───────────────────────────────────────────────────────────────────

export const models = pgTable("models", {
  id: uuid("id").primaryKey().defaultRandom(),
  providerId: uuid("provider_id").references(() => providers.id),
  modelId: text("model_id").notNull().unique(),
  displayName: text("display_name").notNull(),
  status: modelStatusEnum("status").notNull().default("UNVERIFIED"),
  role: agentRoleEnum("role").notNull().default("general"),
  contextWindow: integer("context_window"),
  inputPricePer1k: real("input_price_per_1k"),
  outputPricePer1k: real("output_price_per_1k"),
  supportsTools: boolean("supports_tools").default(false),
  supportsVision: boolean("supports_vision").default(false),
  supportsStreaming: boolean("supports_streaming").default(true),
  lastProbeAt: timestamp("last_probe_at"),
  lastProbeResult: probeStatusEnum("last_probe_result"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ─── Sessions ─────────────────────────────────────────────────────────────────

export const sessions = pgTable("sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  taskDescription: text("task_description").notNull(),
  modelId: uuid("model_id").references(() => models.id),
  role: agentRoleEnum("role").default("general"),
  status: sessionStatusEnum("status").notNull().default("pending"),
  planJson: jsonb("plan_json"),
  permissionsJson: jsonb("permissions_json"),
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  durationMs: integer("duration_ms"),
  totalToolCalls: integer("total_tool_calls").default(0),
  totalModelCalls: integer("total_model_calls").default(0),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ─── Audit Events ─────────────────────────────────────────────────────────────

export const auditEvents = pgTable("audit_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  sessionId: uuid("session_id").references(() => sessions.id),
  eventType: auditEventTypeEnum("event_type").notNull(),
  agentModel: text("agent_model"),
  tool: text("tool"),
  path: text("path"),
  action: text("action"),
  result: toolCallStatusEnum("result"),
  durationMs: integer("duration_ms"),
  metaJson: jsonb("meta_json"),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ─── Probe Results ────────────────────────────────────────────────────────────

export const probeResults = pgTable("probe_results", {
  id: uuid("id").primaryKey().defaultRandom(),
  category: text("category").notNull(),
  checkName: text("check_name").notNull(),
  status: probeStatusEnum("status").notNull(),
  message: text("message"),
  durationMs: integer("duration_ms"),
  modelId: uuid("model_id").references(() => models.id),
  runAt: timestamp("run_at").defaultNow(),
});

// ─── Tool Capabilities ────────────────────────────────────────────────────────

export const toolCapabilities = pgTable("tool_capabilities", {
  id: uuid("id").primaryKey().defaultRandom(),
  toolName: text("tool_name").notNull().unique(),
  displayName: text("display_name").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  isEnabled: boolean("is_enabled").default(true),
  requiresApproval: boolean("requires_approval").default(false),
  permissionsJson: jsonb("permissions_json"),
  lastTestedAt: timestamp("last_tested_at"),
  lastTestStatus: probeStatusEnum("last_test_status"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ─── Permissions ──────────────────────────────────────────────────────────────

export const permissionProfiles = pgTable("permission_profiles", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull().unique(),
  description: text("description"),
  permissionsJson: jsonb("permissions_json").notNull(),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});
