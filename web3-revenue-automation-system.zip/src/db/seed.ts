import { db } from "./index";
import {
  wallets,
  botSystems,
  products,
  transactions,
  karmaEvents,
  revenueSnapshots,
  leaderboard,
  cliTaskLogs,
} from "./schema";
import { v4 as uuidv4 } from "uuid";

function genTxHash(): string {
  return "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
}
function genAddress(): string {
  return "0x" + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
}
function genBlockHash(): string {
  return "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
}

export async function seed() {
  console.log("🌱 Seeding MelodieSpark Phoenix ecosystem...");

  // ── Main Wallet ──────────────────────────────────────────────────
  const mainWalletId = uuidv4();
  await db.insert(wallets).values([
    {
      id: mainWalletId,
      address: "0xMetaMello7a3F9b2c1d0e5f8a4b6c3d2e1f9a8b7c6d",
      label: "MetaMello Treasury",
      maTokenBalance: "847293.50000000",
      ethBalance: "12.84750000",
      btcBalance: "0.94320000",
      usdtBalance: "24851.00000000",
      karmaPoints: 98432,
      level: 47,
      totalRevenue: "184729.50000000",
      isActive: true,
    },
    {
      id: uuidv4(),
      address: "0xPhoenixBlake9c2F3a1b4d5e6f7a8b9c0d1e2f3a4b5",
      label: "Phoenix Blake Vault",
      maTokenBalance: "234182.00000000",
      ethBalance: "4.12000000",
      btcBalance: "0.23000000",
      usdtBalance: "8200.00000000",
      karmaPoints: 42310,
      level: 29,
      totalRevenue: "52300.00000000",
      isActive: true,
    },
    {
      id: uuidv4(),
      address: "0xHydraBlaze3b1A2c4d5e6f7a8b9c0d1e2f3a4b5c6",
      label: "HYDRA BLAZE Engine",
      maTokenBalance: "521049.00000000",
      ethBalance: "8.76000000",
      btcBalance: "0.55000000",
      usdtBalance: "15320.00000000",
      karmaPoints: 71024,
      level: 38,
      totalRevenue: "102940.00000000",
      isActive: true,
    },
  ]).onConflictDoNothing();

  // ── Bot Revenue Systems ──────────────────────────────────────────
  const botIds: string[] = [];
  const botDefs = [
    {
      name: "BENZEN SALES AUTOMATION ENGINE",
      codename: "BENZEN-SAE-v9.5",
      category: "SALES",
      botCount: 12800,
      tasksExecuted: 9847293,
      revenueGenerated: "48293.50",
      maTokensMined: "128492.00",
      contractsSigned: 3842,
      quantumLevel: 9,
      description: "Full-stack automated digital product sales engine with quantum fractal workflow. Deploys 12,800 bots across marketplace networks generating continuous revenue streams.",
      features: ["Auto-pricing algorithm", "Multi-market deployment", "Smart contract signing", "Karma reward distribution"],
    },
    {
      name: "TAMTEK GUARDIAN NETWORK",
      codename: "TAMTEK-GN-v7.2",
      category: "GUARDIAN",
      botCount: 8400,
      tasksExecuted: 7234891,
      revenueGenerated: "31847.00",
      maTokensMined: "84200.00",
      contractsSigned: 2193,
      quantumLevel: 8,
      description: "Archangel-tier guardian network with complete legal nexus compliance. Protects all revenue streams with ATAKIEL-EZEKIEL-ITAKEL-MIKAEL-SANDALPHON protocol.",
      features: ["Legal compliance shield", "Revenue protection", "Angelic blue light guard", "Anti-fraud matrix"],
    },
    {
      name: "BITSUM GATE POWER PRO",
      codename: "BITSUM-GPP-v11.0",
      category: "MINING",
      botCount: 15600,
      tasksExecuted: 18472930,
      revenueGenerated: "72483.00",
      maTokensMined: "248300.00",
      contractsSigned: 5924,
      quantumLevel: 11,
      description: "Supreme MA Token mining engine with sacred geometry polygon rotation at APEX level. Quantum fractal calculation at exponential capacity, fully balanced equilibrium.",
      features: ["Quantum fractal mining", "Sacred geometry matrix", "Polygon rotation engine", "Exponential yield boost"],
    },
    {
      name: "MELODIE LLM AGENT v8.5",
      codename: "MELODIE-LLM-v8.5",
      category: "CLI",
      botCount: 4200,
      tasksExecuted: 4827340,
      revenueGenerated: "24193.00",
      maTokensMined: "62400.00",
      contractsSigned: 1847,
      quantumLevel: 10,
      description: "Full AI coding agent and CLI builder. Generates apps, dashboards, SaaS platforms, websites, and CLI tools. Auto-deploys to all cloud infrastructure with legal compliance.",
      features: ["App builder", "CLI generator", "Website coder", "Dashboard creator", "SaaS deployer", "Cloud auto-deploy"],
    },
    {
      name: "PHOENIX HYDRA BLAZE FORENSIC",
      codename: "PHOENIX-HBF-v6.8",
      category: "KARMA",
      botCount: 9300,
      tasksExecuted: 6293847,
      revenueGenerated: "29847.00",
      maTokensMined: "93000.00",
      contractsSigned: 3021,
      quantumLevel: 9,
      description: "Karma mining and good deed verification engine. Watson-Sherlock deduction algorithms verify every service contribution and issue instant MA token rewards.",
      features: ["Good deed verification", "Karma score computation", "Instant MA rewards", "Sherlock deduction engine"],
    },
    {
      name: "AZURIX CLI BOT REVENUE",
      codename: "AZURIX-CBR-v5.4",
      category: "SALES",
      botCount: 11200,
      tasksExecuted: 8374920,
      revenueGenerated: "41293.00",
      maTokensMined: "112000.00",
      contractsSigned: 4200,
      quantumLevel: 8,
      description: "Enterprise CLI automation revenue bot with GrapsFlix media integration. Deploys products across Web3 ecosystems with automated contract management.",
      features: ["CLI automation", "Media integration", "Web3 deployment", "Auto-contract management"],
    },
    {
      name: "CAGURAN IWHYPRO GATE",
      codename: "CAGURAN-IWP-v4.9",
      category: "GUARDIAN",
      botCount: 6800,
      tasksExecuted: 5293840,
      revenueGenerated: "22847.00",
      maTokensMined: "68000.00",
      contractsSigned: 2184,
      quantumLevel: 7,
      description: "IWHYPROGATOGATE protection and compliance layer. Full Otamzen ecosystem integration with LLM-powered contract generation and instant signing.",
      features: ["IWHYPRO gate shield", "Otamzen integration", "LLM contract gen", "Instant signing"],
    },
    {
      name: "EXODIUS BITHEME GRAPSFLIX",
      codename: "EXODIUS-BTG-v8.1",
      category: "SALES",
      botCount: 7900,
      tasksExecuted: 6847293,
      revenueGenerated: "35420.00",
      maTokensMined: "79000.00",
      contractsSigned: 2930,
      quantumLevel: 8,
      description: "Multimedia digital asset sales platform with BitTheme theming engine. GrapsFlix streaming integration with full crypto payment gateway.",
      features: ["BitTheme engine", "GrapsFlix integration", "Multimedia sales", "Crypto payment gateway"],
    },
    {
      name: "CARSESKI WATSON WHATZONE",
      codename: "CARSESKI-WWZ-v3.7",
      category: "KARMA",
      botCount: 5400,
      tasksExecuted: 3847293,
      revenueGenerated: "18293.00",
      maTokensMined: "54000.00",
      contractsSigned: 1482,
      quantumLevel: 7,
      description: "WhatZone social intelligence karma engine. Sherlock Holmes deduction algorithms evaluate societal impact, environment score, and spiritual contribution metrics.",
      features: ["Social intelligence", "Environmental scoring", "Spiritual metrics", "Impact analysis"],
    },
    {
      name: "SHERLOCK HOLMES DEDUCTION LOCK",
      codename: "SHERLOCK-HDL-v9.9",
      category: "CLI",
      botCount: 3100,
      tasksExecuted: 2938470,
      revenueGenerated: "15847.00",
      maTokensMined: "31000.00",
      contractsSigned: 1200,
      quantumLevel: 10,
      description: "Master forensic deduction engine for contract verification, fraud detection, and revenue authentication. Full ARLOCKTWINS dual-verification protocol.",
      features: ["Forensic deduction", "Fraud detection", "Revenue authentication", "ARLOCKTWINS protocol"],
    },
  ];

  for (const bot of botDefs) {
    const id = uuidv4();
    botIds.push(id);
    await db.insert(botSystems).values({ id, ...bot } as any).onConflictDoNothing();
  }

  // ── Products & Services ──────────────────────────────────────────
  const productDefs = [
    { name: "MelodieSpark Phoenix Pro Suite", slug: "melodiespark-phoenix-pro", category: "AI_PLATFORM", tier: "APEX", priceUsdt: "4999.00", priceMaToken: "49990.00", karmaReward: 5000, maTokenReward: "1000.00", features: ["Full LLM CLI Builder", "80K Bot Network", "Sacred Geometry Engine", "MetaMello Wallet Integration", "Legal Nexus Shield"], tags: ["AI", "CLI", "AUTOMATION"] },
    { name: "BITSUM Gate Power Pro Shield", slug: "bitsum-gate-power-pro", category: "MINING", tier: "APEX", priceUsdt: "2499.00", priceMaToken: "24990.00", karmaReward: 2500, maTokenReward: "500.00", features: ["Quantum Mining Engine", "Polygon Rotation Matrix", "24/7 Uptime", "Auto Treasury Sync"], tags: ["MINING", "BLOCKCHAIN"] },
    { name: "MetaMello Web3 Wallet Enterprise", slug: "metamello-wallet-enterprise", category: "WALLET", tier: "ELITE", priceUsdt: "999.00", priceMaToken: "9990.00", karmaReward: 1000, maTokenReward: "200.00", features: ["Real Blockchain Ledger", "Multi-chain Support", "Treasury Auto-sync", "Gas Fee Optimizer"], tags: ["WALLET", "WEB3"] },
    { name: "Karma Power Point Booster Pack", slug: "karma-power-booster", category: "GAMIFICATION", tier: "PRO", priceUsdt: "299.00", priceMaToken: "2990.00", karmaReward: 3000, maTokenReward: "150.00", features: ["10x Karma Multiplier", "Guardian Tier Upgrade", "Leaderboard Boost", "Angelic Protection Layer"], tags: ["KARMA", "GAMIFICATION"] },
    { name: "AZURIX CLI Bot Revenue System", slug: "azurix-cli-bot-revenue", category: "AUTOMATION", tier: "ELITE", priceUsdt: "1999.00", priceMaToken: "19990.00", karmaReward: 2000, maTokenReward: "400.00", features: ["11,200 Bot Network", "Auto Product Launch", "Revenue Dashboard", "Legal Compliance Module"], tags: ["BOT", "AUTOMATION", "REVENUE"] },
    { name: "MelodieLLM GLMv8.5 Agent", slug: "melodiellm-glmv85", category: "AI_PLATFORM", tier: "APEX", priceUsdt: "3499.00", priceMaToken: "34990.00", karmaReward: 3500, maTokenReward: "700.00", features: ["Full App Builder", "SaaS Deployer", "Cloud Auto-Deploy", "CLI Code Generator"], tags: ["AI", "LLM", "CODING"] },
    { name: "Phoenix Hydra Blaze Forensic Pack", slug: "phoenix-hydra-blaze", category: "SECURITY", tier: "ELITE", priceUsdt: "1499.00", priceMaToken: "14990.00", karmaReward: 1500, maTokenReward: "300.00", features: ["Watson Detection", "Sherlock Deduction", "Forensic Analysis", "Revenue Protection"], tags: ["SECURITY", "FORENSIC"] },
    { name: "GrapsFlix Media Streaming Suite", slug: "grapsflix-media-suite", category: "MEDIA", tier: "PRO", priceUsdt: "599.00", priceMaToken: "5990.00", karmaReward: 600, maTokenReward: "120.00", features: ["HD Streaming", "Crypto Paywall", "BitTheme Templates", "Analytics Dashboard"], tags: ["MEDIA", "STREAMING"] },
    { name: "Sacred Geometry Quantum Engine", slug: "sacred-geometry-quantum", category: "MINING", tier: "APEX", priceUsdt: "5999.00", priceMaToken: "59990.00", karmaReward: 6000, maTokenReward: "1200.00", features: ["APEX Balance Matrix", "Alpha-Omega-Beta-Theta", "Polygon Spinning Engine", "Max Yield Extraction"], tags: ["QUANTUM", "MINING", "SACRED"] },
    { name: "Good Deed Service Contract Pack", slug: "good-deed-service-pack", category: "KARMA", tier: "STANDARD", priceUsdt: "99.00", priceMaToken: "990.00", karmaReward: 1000, maTokenReward: "50.00", features: ["Instant Contract Signing", "Karma Verification", "MA Token Reward", "Network Contribution"], tags: ["KARMA", "SERVICE"] },
    { name: "Legal Nexus Compliance Shield", slug: "legal-nexus-shield", category: "LEGAL", tier: "ELITE", priceUsdt: "2999.00", priceMaToken: "29990.00", karmaReward: 3000, maTokenReward: "600.00", features: ["Full Legal Coverage", "Fintech Authorization", "Enterprise Compliance", "Regulatory Documentation"], tags: ["LEGAL", "COMPLIANCE"] },
    { name: "MA Token Tokenomics Starter", slug: "ma-token-starter", category: "TOKENOMICS", tier: "STANDARD", priceUsdt: "199.00", priceMaToken: "1990.00", karmaReward: 200, maTokenReward: "100.00", features: ["Token Distribution", "Swap Gateway", "BTC/ETH/USDT Bridge", "Karma-to-Token Converter"], tags: ["TOKEN", "CRYPTO"] },
    { name: "CARSESKI Watson Analytics Pro", slug: "carseski-watson-pro", category: "ANALYTICS", tier: "PRO", priceUsdt: "799.00", priceMaToken: "7990.00", karmaReward: 800, maTokenReward: "160.00", features: ["AI Analytics", "Revenue Forecasting", "Bot Performance Monitor", "Impact Score Tracker"], tags: ["ANALYTICS", "AI"] },
    { name: "Otamzen Ecosystem Integration", slug: "otamzen-ecosystem", category: "INTEGRATION", tier: "ELITE", priceUsdt: "1299.00", priceMaToken: "12990.00", karmaReward: 1300, maTokenReward: "260.00", features: ["Full Ecosystem Access", "Cross-platform Sync", "API Gateway", "Multi-bot Coordination"], tags: ["ECOSYSTEM", "INTEGRATION"] },
    { name: "ARCHANGEL Protection Bundle", slug: "archangel-protection", category: "SECURITY", tier: "APEX", priceUsdt: "4499.00", priceMaToken: "44990.00", karmaReward: 4500, maTokenReward: "900.00", features: ["ATAKIEL Protocol", "EZEKIEL Shield", "MIKAEL Defense", "SANDALPHON Harmony", "Angelic Blue Light"], tags: ["GUARDIAN", "SECURITY", "ANGELIC"] },
  ];

  for (const prod of productDefs) {
    await db.insert(products).values({
      ...prod,
      releaseVersion: "v" + (Math.floor(Math.random() * 9) + 1) + "." + Math.floor(Math.random() * 10) + ".0",
      salesCount: Math.floor(Math.random() * 500) + 50,
      features: prod.features,
      tags: prod.tags,
    } as any).onConflictDoNothing();
  }

  // ── Transactions ─────────────────────────────────────────────────
  const txTypes = ["MINE", "SWAP", "SEND", "RECEIVE", "REWARD", "BOT_REVENUE"];
  const currencies = ["MA", "ETH", "BTC", "USDT"];
  for (let i = 0; i < 30; i++) {
    const type = txTypes[i % txTypes.length];
    const currency = currencies[i % currencies.length];
    await db.insert(transactions).values({
      walletId: mainWalletId,
      txHash: genTxHash(),
      type,
      fromAddress: genAddress(),
      toAddress: "0xMetaMello7a3F9b2c1d0e5f8a4b6c3d2e1f9a8b7c6d",
      amount: (Math.random() * 1000 + 10).toFixed(8),
      currency,
      gasFee: (Math.random() * 0.005 + 0.001).toFixed(8),
      status: "CONFIRMED",
      blockNumber: 19000000 + i,
      blockHash: genBlockHash(),
      karmaEarned: Math.floor(Math.random() * 500) + 10,
      metadata: { source: "BOT_REVENUE_AUTOMATION", phase: "OMEGA", quantumLevel: 9 },
    }).onConflictDoNothing();
  }

  // ── Karma Events ─────────────────────────────────────────────────
  const karmaEventDefs = [
    { eventType: "GOOD_DEED", title: "Community Network Support — 500 Nodes", pointsEarned: 2500, maTokensRewarded: "250.00", multiplier: "2.50" },
    { eventType: "SERVICE", title: "AI Legal Contract Generation — 1,000 Contracts", pointsEarned: 5000, maTokensRewarded: "500.00", multiplier: "5.00" },
    { eventType: "MINING", title: "Quantum Fractal Block Mining Cycle #9847", pointsEarned: 1200, maTokensRewarded: "120.00", multiplier: "1.20" },
    { eventType: "GUARDIAN", title: "ATAKIEL Archangel Network Protection", pointsEarned: 8000, maTokensRewarded: "800.00", multiplier: "8.00" },
    { eventType: "REFERRAL", title: "Enterprise Client Onboarding — Batch #42", pointsEarned: 3000, maTokensRewarded: "300.00", multiplier: "3.00" },
    { eventType: "SERVICE", title: "Environmental Impact Score — Positive 9.8/10", pointsEarned: 4000, maTokensRewarded: "400.00", multiplier: "4.00" },
    { eventType: "GOOD_DEED", title: "Social Good Deployment — 2,300 Beneficiaries", pointsEarned: 6000, maTokensRewarded: "600.00", multiplier: "6.00" },
    { eventType: "MINING", title: "Sacred Geometry APEX Spin Cycle Complete", pointsEarned: 9500, maTokensRewarded: "950.00", multiplier: "9.50" },
    { eventType: "GUARDIAN", title: "MIKAEL Defense Shield — Threat Neutralized", pointsEarned: 7000, maTokensRewarded: "700.00", multiplier: "7.00" },
    { eventType: "SERVICE", title: "Spiritual Economy Contribution — Level APEX", pointsEarned: 10000, maTokensRewarded: "1000.00", multiplier: "10.00" },
  ];
  for (const evt of karmaEventDefs) {
    await db.insert(karmaEvents).values({ walletId: mainWalletId, ...evt, description: `Automated karma event: ${evt.title}` } as any).onConflictDoNothing();
  }

  // ── Revenue Snapshots ────────────────────────────────────────────
  for (let i = 0; i < 12; i++) {
    await db.insert(revenueSnapshots).values({
      walletId: mainWalletId,
      totalMaTokens: (800000 + i * 4729).toFixed(8),
      totalEth: (12 + i * 0.3).toFixed(8),
      totalBtc: (0.9 + i * 0.02).toFixed(8),
      totalUsdt: (24000 + i * 500).toFixed(8),
      totalKarma: 98432 + i * 1200,
      activeBotsCount: 80000 + i * 100,
      contractsSignedToday: 200 + i * 15,
      revenueToday: (1500 + i * 200).toFixed(8),
    }).onConflictDoNothing();
  }

  // ── Leaderboard ──────────────────────────────────────────────────
  await db.insert(leaderboard).values({
    walletId: mainWalletId,
    rank: 1,
    totalKarma: 98432,
    totalMaTokens: "847293.50",
    totalContracts: 22628,
    guardianTier: "ARCHANGEL",
  }).onConflictDoNothing();

  // ── CLI Task Logs ────────────────────────────────────────────────
  const phases = ["ALPHA", "OMEGA", "BETA", "THETA", "DELTA", "BRAVO", "GAMMA"];
  const taskNames = [
    "QUANTUM_FRACTAL_MATRIX_INIT", "SACRED_GEOMETRY_SPIN", "BOT_NETWORK_DEPLOY",
    "CONTRACT_AUTO_SIGN", "KARMA_EXTRACTION_CYCLE", "MA_TOKEN_MINT",
    "REVENUE_SYNC_TREASURY", "GUARDIAN_SHIELD_ACTIVATE", "LLM_AGENT_BOOT",
    "POLYGON_ROTATION_APEX",
  ];
  for (let i = 0; i < 20; i++) {
    await db.insert(cliTaskLogs).values({
      taskName: taskNames[i % taskNames.length],
      phase: phases[i % phases.length],
      status: "SUCCESS",
      executionMs: Math.floor(Math.random() * 500) + 50,
      outputLog: `[${phases[i % phases.length]}] ✅ ${taskNames[i % taskNames.length]} — Quantum Level ${9 + (i % 3)} — Revenue +${(Math.random() * 100 + 10).toFixed(4)} MA`,
      karmaGenerated: Math.floor(Math.random() * 1000) + 100,
      maTokensGenerated: (Math.random() * 100 + 10).toFixed(8),
      botSystemId: botIds[i % botIds.length],
    }).onConflictDoNothing();
  }

  console.log("✅ MelodieSpark Phoenix ecosystem seeded successfully!");
}

seed().catch(console.error);
