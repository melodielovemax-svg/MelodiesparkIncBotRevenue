import {
  pgTable,
  text,
  integer,
  bigint,
  boolean,
  timestamp,
  decimal,
  serial,
  uuid,
  jsonb,
  varchar,
  index,
} from "drizzle-orm/pg-core";

// ── Wallet / Users ──────────────────────────────────────────────────
export const wallets = pgTable("wallets", {
  id: uuid("id").primaryKey().defaultRandom(),
  address: varchar("address", { length: 64 }).notNull().unique(),
  label: varchar("label", { length: 128 }).notNull().default("MetaMello Wallet"),
  maTokenBalance: decimal("ma_token_balance", { precision: 28, scale: 8 }).notNull().default("0"),
  ethBalance: decimal("eth_balance", { precision: 28, scale: 8 }).notNull().default("0"),
  btcBalance: decimal("btc_balance", { precision: 28, scale: 8 }).notNull().default("0"),
  usdtBalance: decimal("usdt_balance", { precision: 28, scale: 8 }).notNull().default("0"),
  karmaPoints: integer("karma_points").notNull().default(0),
  level: integer("level").notNull().default(1),
  totalRevenue: decimal("total_revenue", { precision: 28, scale: 8 }).notNull().default("0"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ── MA Token Transactions ──────────────────────────────────────────
export const transactions = pgTable("transactions", {
  id: uuid("id").primaryKey().defaultRandom(),
  walletId: uuid("wallet_id").references(() => wallets.id).notNull(),
  txHash: varchar("tx_hash", { length: 128 }).notNull().unique(),
  type: varchar("type", { length: 32 }).notNull(), // MINE, SWAP, SEND, RECEIVE, REWARD, BOT_REVENUE
  fromAddress: varchar("from_address", { length: 64 }),
  toAddress: varchar("to_address", { length: 64 }),
  amount: decimal("amount", { precision: 28, scale: 8 }).notNull(),
  currency: varchar("currency", { length: 16 }).notNull().default("MA"),
  gasFee: decimal("gas_fee", { precision: 28, scale: 8 }).notNull().default("0"),
  status: varchar("status", { length: 16 }).notNull().default("CONFIRMED"), // PENDING, CONFIRMED, FAILED
  blockNumber: bigint("block_number", { mode: "number" }),
  blockHash: varchar("block_hash", { length: 128 }),
  karmaEarned: integer("karma_earned").notNull().default(0),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Bot Revenue Systems ────────────────────────────────────────────
export const botSystems = pgTable("bot_systems", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 128 }).notNull(),
  codename: varchar("codename", { length: 64 }).notNull(),
  category: varchar("category", { length: 64 }).notNull(), // SALES, MINING, KARMA, GUARDIAN, CLI
  status: varchar("status", { length: 16 }).notNull().default("ACTIVE"),
  botCount: integer("bot_count").notNull().default(0),
  tasksExecuted: bigint("tasks_executed", { mode: "number" }).notNull().default(0),
  revenueGenerated: decimal("revenue_generated", { precision: 28, scale: 8 }).notNull().default("0"),
  maTokensMined: decimal("ma_tokens_mined", { precision: 28, scale: 8 }).notNull().default("0"),
  contractsSigned: integer("contracts_signed").notNull().default(0),
  successRate: decimal("success_rate", { precision: 5, scale: 2 }).notNull().default("99.97"),
  quantumLevel: integer("quantum_level").notNull().default(1),
  description: text("description"),
  features: jsonb("features"),
  lastCycleAt: timestamp("last_cycle_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ── Products & Services ────────────────────────────────────────────
export const products = pgTable("products", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 256 }).notNull(),
  slug: varchar("slug", { length: 256 }).notNull().unique(),
  category: varchar("category", { length: 64 }).notNull(),
  tier: varchar("tier", { length: 32 }).notNull().default("STANDARD"), // STANDARD, PRO, ELITE, APEX
  description: text("description"),
  priceUsdt: decimal("price_usdt", { precision: 18, scale: 2 }).notNull(),
  priceMaToken: decimal("price_ma_token", { precision: 18, scale: 2 }).notNull(),
  karmaReward: integer("karma_reward").notNull().default(0),
  maTokenReward: decimal("ma_token_reward", { precision: 18, scale: 8 }).notNull().default("0"),
  salesCount: integer("sales_count").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  features: jsonb("features"),
  tags: jsonb("tags"),
  releaseVersion: varchar("release_version", { length: 32 }).notNull().default("v1.0.0"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ── Karma Gamification ─────────────────────────────────────────────
export const karmaEvents = pgTable("karma_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  walletId: uuid("wallet_id").references(() => wallets.id).notNull(),
  eventType: varchar("event_type", { length: 64 }).notNull(), // GOOD_DEED, SERVICE, MINING, REFERRAL, GUARDIAN
  title: varchar("title", { length: 256 }).notNull(),
  description: text("description"),
  pointsEarned: integer("points_earned").notNull().default(0),
  maTokensRewarded: decimal("ma_tokens_rewarded", { precision: 18, scale: 8 }).notNull().default("0"),
  multiplier: decimal("multiplier", { precision: 5, scale: 2 }).notNull().default("1.00"),
  verified: boolean("verified").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Revenue Snapshots (live sync) ──────────────────────────────────
export const revenueSnapshots = pgTable("revenue_snapshots", {
  id: uuid("id").primaryKey().defaultRandom(),
  walletId: uuid("wallet_id").references(() => wallets.id).notNull(),
  totalMaTokens: decimal("total_ma_tokens", { precision: 28, scale: 8 }).notNull().default("0"),
  totalEth: decimal("total_eth", { precision: 28, scale: 8 }).notNull().default("0"),
  totalBtc: decimal("total_btc", { precision: 28, scale: 8 }).notNull().default("0"),
  totalUsdt: decimal("total_usdt", { precision: 28, scale: 8 }).notNull().default("0"),
  totalKarma: integer("total_karma").notNull().default(0),
  activeBotsCount: integer("active_bots_count").notNull().default(0),
  contractsSignedToday: integer("contracts_signed_today").notNull().default(0),
  revenueToday: decimal("revenue_today", { precision: 28, scale: 8 }).notNull().default("0"),
  snapshotAt: timestamp("snapshot_at").defaultNow().notNull(),
});

// ── CLI Task Executions ────────────────────────────────────────────
export const cliTaskLogs = pgTable("cli_task_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  taskName: varchar("task_name", { length: 256 }).notNull(),
  phase: varchar("phase", { length: 32 }).notNull(), // ALPHA, OMEGA, BETA, THETA, DELTA, BRAVO, GAMMA
  status: varchar("status", { length: 16 }).notNull().default("SUCCESS"),
  executionMs: integer("execution_ms").notNull().default(0),
  outputLog: text("output_log"),
  karmaGenerated: integer("karma_generated").notNull().default(0),
  maTokensGenerated: decimal("ma_tokens_generated", { precision: 18, scale: 8 }).notNull().default("0"),
  botSystemId: uuid("bot_system_id").references(() => botSystems.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Leaderboard ────────────────────────────────────────────────────
export const leaderboard = pgTable("leaderboard", {
  id: uuid("id").primaryKey().defaultRandom(),
  walletId: uuid("wallet_id").references(() => wallets.id).notNull(),
  rank: integer("rank").notNull().default(1),
  totalKarma: integer("total_karma").notNull().default(0),
  totalMaTokens: decimal("total_ma_tokens", { precision: 28, scale: 8 }).notNull().default("0"),
  totalContracts: integer("total_contracts").notNull().default(0),
  guardianTier: varchar("guardian_tier", { length: 32 }).notNull().default("INITIATE"), // INITIATE, GUARDIAN, ARCHANGEL, APEX
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Types
export type Wallet = typeof wallets.$inferSelect;
export type InsertWallet = typeof wallets.$inferInsert;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;
export type BotSystem = typeof botSystems.$inferSelect;
export type InsertBotSystem = typeof botSystems.$inferInsert;
export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;
export type KarmaEvent = typeof karmaEvents.$inferSelect;
export type InsertKarmaEvent = typeof karmaEvents.$inferInsert;
export type RevenueSnapshot = typeof revenueSnapshots.$inferSelect;
export type CliTaskLog = typeof cliTaskLogs.$inferSelect;
export type LeaderboardEntry = typeof leaderboard.$inferSelect;
