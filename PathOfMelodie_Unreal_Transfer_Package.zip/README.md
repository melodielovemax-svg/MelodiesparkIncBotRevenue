# Path of Melodie Unreal Transfer Package

This package is the authoritative transfer scaffold for converting the existing Path of Melodie concept/Godot prototype into Unreal Engine.

It contains:
- Master game transfer specification
- Unreal architecture and implementation transfer document
- 30,000-image artwork production specification
- Deterministic 30,000-row artwork manifest

The manifest is a production plan, not evidence that 30,000 images already exist.

Next engineering step: create the actual Unreal `.uproject`, C++ modules, Build.cs files, source tree, test project and first playable vertical slice; verify compilation and packaged runtime before labeling Unreal systems operational.
